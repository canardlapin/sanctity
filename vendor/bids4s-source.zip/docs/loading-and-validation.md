# Loading and validation

bids4s keeps filesystem failures separate from BIDS content diagnostics. Choose
the loader method according to whether invalid content should remain usable.

## Loader policies

| Method | Result | Use it when |
| --- | --- | --- |
| `load` | `Either[BidsError, BidsProject]` | Existing code needs the permissive compatibility behavior. |
| `loadChecked` | `Either[BidsError, BidsValidationReport[BidsProject]]` | The application should inspect every detectable issue and may still use the project. |
| `loadStrict` | `Either[BidsProjectLoadError, BidsProject]` | Structural errors must reject the project, but the complete issue report must be retained. |

The signatures compile as ordinary public API calls:

```scala mdoc:compile-only
import bids4s.*
import bids4s.io.*

import java.nio.file.Path

val root = Path.of("/data/study")

val permissive: Either[BidsError, BidsProject] =
  BidsProjectLoader.load(root)

val checked: Either[BidsError, BidsValidationReport[BidsProject]] =
  BidsProjectLoader.loadChecked(root)

val strict: Either[BidsProjectLoadError, BidsProject] =
  BidsProjectLoader.loadStrict(root)
```

## Inspect a checked result

`BidsValidationReport` contains the usable value, all ordered issues, and
convenience views for errors and warnings:

```scala mdoc:compile-only
import bids4s.*

def summarize(report: BidsValidationReport[BidsProject]) =
  (
    report.value,
    report.errors,
    report.warnings,
    report.hasErrors
  )
```

`report.enforce(BidsValidationPolicy.Strict)` converts a checked report into an
`Either[BidsIssueReport, BidsValidationReport[BidsProject]]`. The issue report
is non-empty by construction and keeps deterministic diagnostic ordering.

## Operational failures

`loadChecked` returns `Left(BidsError.Io(...))` when discovery cannot complete,
for example because the root does not exist or a file cannot be read. Content
issues such as an invalid sidecar, missing required metadata, or inconsistent
entities belong in `BidsValidationReport`.

`loadStrict` wraps the same distinction:

- `BidsProjectLoadError.Operation(error)` contains the operational
  `BidsError`.
- `BidsProjectLoadError.Validation(report)` contains content diagnostics.

## Effectful applications

`BidsProjectLoaderF[F]` provides `load`, `loadChecked`, and `loadStrict` at the
JVM boundary for Cats Effect applications. It returns the same domain result
types inside `F`; it does not choose a runtime or call `unsafeRun*`.

The portable parser, validation, query, metadata, table, and confound APIs do
not require Cats Effect and remain available to Scala.js.

## Explain inherited metadata

`project.resolveMetadata(path)` returns effective JSON, ordered contributing
documents, the final document supplying each top-level field, and field history.
Applications that already have an inventory can reuse an immutable
`BidsMetadataResolver` without constructing a filesystem loader.

```scala mdoc:compile-only
import bids4s.*

def explain(project: BidsProject, path: BidsPath) =
  project.resolveMetadata(path).map { resolved =>
    (
      resolved.metadata,
      resolved.datasetRoot,
      resolved.sources,
      resolved.origins.get("RepetitionTime"),
      resolved.history("RepetitionTime")
    )
  }
```

The resolver indexes candidates by directory and suffix once. It limits
inheritance to the deepest declared derivative root or inventoried nested
`dataset_description.json` boundary. All paths are project-relative; a
`datasetRoot` of `None` means the project dataset root.

Multiple applicable JSON documents in one directory produce
`BidsError.AmbiguousMetadata`; an applicable inventoried document with no
decoded content produces `BidsError.MissingMetadata`. Checked loaders retain
these failures as ordered content diagnostics, strict loaders reject them, and
permissive loading still returns the project. Metadata queries on ambiguous
content return the typed failure.

### Inheritance corrections

Inherited JSON now follows top-level key replacement: a lower-level object
value replaces the entire value for that key. The general-purpose
`JsonValue.merge` helper retains its existing recursive behavior.
Root-dataset sidecars no longer contribute to nested derivative datasets.
Ambiguous same-directory sidecars are no longer resolved by specificity or
lexicographic order. These are semantic corrections in the pre-release API;
existing valid, unambiguous scalar inheritance keeps its result.

This API explains JSON inheritance only. Non-JSON nearest-file associations,
schema-aware relationship resolution, complete metadata placement validation,
and filesystem preservation are separate contracts.

## Explicit fieldmap relationships

`BidsFieldmapResolver` interprets explicit declarations on NIfTI images. It is a
pure, portable operation over a manifest and metadata resolver:

```scala mdoc:compile-only
import bids4s.*

def declaredFieldmaps(project: BidsProject): BidsFieldmapReport =
  BidsFieldmapResolver.resolve(
    project.manifest,
    BidsMetadataResolver(project.manifest, project.sidecars, project.derivatives)
  )
```

For applications already computing inheritance in a batch, `fromResolved`
accepts the resulting `Map[BidsPath, BidsMetadataResolution]`. Callers retain
their own metadata-resolution diagnostics for targets absent from that map.

Each association identifies the target acquisition, all source images belonging
to one estimation group, its mechanism, an optional identifier, and the exact
metadata documents/fields providing the evidence. A shared `B0FieldIdentifier`
forms a group within one participant's dataset tree, including its sessions.
A `B0FieldSource` array retains separate group records. Self-reference is valid.
When both mechanisms are present, both are retained; this API does not rank
them or infer an algorithm choice.

Current-dataset `bids::` URIs resolve within the selected dataset boundary.
Deprecated participant-relative `IntendedFor` paths resolve with a warning.
Named external datasets need a pinned composition adapter and produce an
explicit unsupported finding. Missing identifiers/targets, malformed fields,
noncanonical paths, scope mismatch, and metadata failures remain inspectable.
Use `report.issues.exists(_.isError)` to distinguish an incomplete/invalid
report from a successful empty graph. Results and evidence order deterministically.

This bounded profile allows at most 1024 values per declaration field, 4096
characters per value, 100000 declaration references, and 100000 expanded
source members. Exceeding a budget produces a blocking finding; partial
relationships must not be treated as a complete graph.

This API does not infer unnamed fieldmaps or phase/magnitude companions,
qualify geometry or distortion-correction suitability, select a processing
algorithm, or implement DWI/event companion resolution. Existing loaders keep
their prior behavior; the caller explicitly invokes this new assessment.

Semantics follow the explicit declaration sections of the
[BIDS MRI specification, version 1.11.2](https://bids-specification.readthedocs.io/en/v1.11.2/modality-specific-files/magnetic-resonance-imaging-data.html#expressing-the-mr-protocol-intent-for-fieldmaps).

## MRI gradient and event companions

`BidsCompanionResolver` indexes a manifest once and resolves non-JSON companions without reading their contents. The current profile supports NIfTI DWI `bval`/`bvec` files and NIfTI BOLD `events.tsv` files. The two gradient extensions resolve independently; repository consumers can then require both as one dependency group.

```scala mdoc:compile-only
import bids4s.*

val companionManifest = BidsManifest.fromRelativePaths(Vector(
  "task-memory_events.tsv",
  "sub-01/func/sub-01_task-memory_run-01_bold.nii.gz",
  "sub-01/func/sub-01_task-memory_run-1_events.tsv"
))
val companionResolver = BidsCompanionResolver(companionManifest)
val companionResult = companionResolver.resolve(
  BidsPath("sub-01/func/sub-01_task-memory_run-01_bold.nii.gz"),
  BidsCompanionKind.Events
)
val companionEvidence = companionResult.map(r => (r.applicable, r.outcome))
```

The result retains the dataset boundary, all applicable candidates in root-to-file order, and matched filename entities. `Selected` chooses the lowest applicable file; rows and gradient vectors are never merged. `Missing`, `Ambiguous`, `Unsupported` and `LimitExceeded` are distinct outcomes. Invalid target paths/names return a typed `BidsError`.

Candidates must lie in an ancestor directory within the same dataset and have a matching role and entity subset. Run indices use the existing numeric equivalence (`1` and `01`); participant labels remain lexical. Events match BOLD by entities with the explicit events-to-BOLD suffix mapping, so one table can serve multiple echoes. More than one applicable candidate at any directory level is ambiguous, even if a lower file exists. Nested descriptions and explicitly supplied derivative roots stop inheritance.

A resolution examines at most 10,000 indexed candidates by default (configurable downward or upward through `candidateLimit`); exceeding the bound yields no selected result. Reordering or duplicating inventory entries does not change evidence. Missing companions are observations: the consumer's admission profile decides whether they are required.

This API does not validate gradient values, image dimensions, event rows, stimulus references, all BIDS placement restrictions, or non-MRI event associations. It does not replace full BIDS validation. The rules follow [BIDS inheritance](https://bids-specification.readthedocs.io/en/v1.11.2/common-principles.html#the-inheritance-principle), [DWI gradient files](https://bids-specification.readthedocs.io/en/v1.11.2/modality-specific-files/magnetic-resonance-imaging-data.html#required-gradient-orientation-information), and [event inheritance](https://bids-specification.readthedocs.io/en/v1.11.2/modality-agnostic-files/events.html), inspected at version 1.11.2.

## DWI gradient and header consistency

These portable APIs inspect supplied text and header bytes; they perform no I/O and do not change loader behavior.

```scala mdoc
import bids4s.*
val bvals = BValues.parse("0 1000\n")
val bvecs = BVectors.parse("0 1\n0 0\n0 0\n")
val gradientCounts = for
  values <- bvals
  vectors <- bvecs
yield (values.values.size, vectors.values.size)

def assessDwi(headerBytes: Array[Byte], values: BValues, vectors: BVectors)
    : Either[DwiIssue, Vector[DwiIssue]] =
  NiftiHeaderFacts.parse(headerBytes).map(DwiConsistency.check(_, values, vectors))
```

`BValues` accepts one row; `BVectors` accepts three equal-length rows, with one volume per column. Values must be finite decimals, b-values nonnegative. Numeric overflow and nonzero underflow are rejected. Parsing accepts spaces/tabs and CRLF, preserves values, and never transposes, pads or normalizes. Limits are 4 MiB characters, 100,000 columns, 128 characters per numeric token and 64 reported numeric issues. Each issue identifies its input, code and available row/column.

`NiftiHeaderFacts` supports single-file NIfTI-1 and NIfTI-2, both byte orders and declared scalar datatypes. Supply up to 540 header bytes (348 for NIfTI-1); `headerSize` can determine the needed size from the first four bytes. Checks cover magic, active dimensions, datatype/bitpix, data offset and overflow-safe minimum file size. Paired/Analyze headers and complex/RGB datatypes are outside this profile. No voxel array is allocated or inspected. Acquisition, decompression, full-file length/digest checks and operational errors belong to the caller.

`DwiConsistency.check` requires 3D or 4D data and compares gradient counts with volume count. Its `bids-dwi-consistency-v1` policy permits unit vectors within 0.01 and, for b ≤ 50 s/mm², zero vectors within 1e-6. These thresholds are policy choices, not BIDS constants. It does not verify handedness or reorient FSL image-axis components.

The reference layouts are [NIfTI-1](https://github.com/NIFTI-Imaging/nifti_clib/blob/master/niftilib/nifti1.h) and [NIfTI-2](https://github.com/NIFTI-Imaging/nifti_clib/blob/master/nifti2/nifti2.h). The [BIDS gradient convention](https://bids-specification.readthedocs.io/en/stable/modality-specific-files/magnetic-resonance-imaging-data.html#required-gradient-orientation-information) defines the table layout and image-axis convention. These bounded checks do not establish anatomical orientation correctness, full image validity or BIDS conformance.

## Strict task-event assessment

`CheckedEvents.assess` is an opt-in profile alongside the existing permissive `BidsEvents` and `EventsTable` readers. It returns a checked table only when there are no errors, plus deterministic typed findings with physical source row and column numbers. Warnings retain the checked table.

```scala mdoc
import bids4s.*
val checkedTaskEvents = CheckedEvents.assess(
  "onset\tduration\ttrial_type\n-1\t2\tpractice\n0\t0\tgo\nn/a\tn/a\tunknown\n"
)
val acquisitionTiming = EventTiming.assess(
  Some(20L),
  Map("RepetitionTime" -> JsonValue.Num(1.5))
)
val timingFindings = checkedTaskEvents.table.toVector.flatMap(
  EventTiming.compare(_, acquisitionTiming.context)
)
val eventRows = checkedTaskEvents.table.map(_.table.nrows)
```

The `bids-events-content-v1` profile requires actual tab separators, unique nonblank column names, `onset` first and `duration` second. It supports UTF-8 BOM after decoding, LF/CRLF, quoted embedded tabs/newlines and doubled quotes. Empty cells are errors; `n/a` is the explicit missing value. Custom values and column order are retained. Strict headers cannot have surrounding whitespace. Existing readers keep their prior whitespace-delimiter and missing-token behavior.

Onset, duration and optional response time use exact `BigDecimal` seconds, preserving decimal/scientific notation without binary rounding. Negative onsets, overlap, zero duration and negative response times are supported; duration must be nonnegative. Unsorted known onsets warn without sorting the table. Unknown onset/duration values remain absent and do not acquire invented values.

Limits: 4 MiB characters, 100,000 event rows, 256 columns, 128 characters/128 significant digits per numeric token, and absolute decimal scale at most 308. At most 64 findings are returned per assessment/comparison. Diagnostic truncation preserves warning-only status and cannot hide a subsequent error.

`EventTiming.assess` consumes the stored image's volume count and effective metadata. Its `bids-events-timing-v1` profile distinguishes regular, variable and unavailable context:

- Regular timing records the nominal comparison end `volumeCount * RepetitionTime`. This includes inter-volume gaps and is not a measured physical acquisition end.
- Variable timing validates the length, finite nonnegative values and increasing order of `VolumeTiming`. Starts are expressed relative to the first stored volume. The final end is available when `FrameAcquisitionDuration` is supplied.
- With only `SliceTiming`, the final volume end remains unavailable; this profile does not extrapolate it or compute a median TR.
- Conflicting/invalid supplied timing is an error. Missing timing or missing volume count is an explicit unavailable-context warning. Discarded-volume counts never shift event onsets.
- `compare` emits warnings for known event starts/ends beyond the comparison window. A missing duration can still have a known start; a missing onset cannot establish an end.

The profile follows the [event rules](https://bids-specification.readthedocs.io/en/stable/modality-agnostic-files/events.html), [TSV conventions](https://bids-specification.readthedocs.io/en/stable/common-principles.html#tabular-files) and [functional MRI timing definitions](https://bids-specification.readthedocs.io/en/stable/modality-specific-files/magnetic-resonance-imaging-data.html#required-fields). Window exceedance is a profile review warning, not a BIDS prohibition. HED, stimulus resolution, arbitrary column dictionaries, all timing-field combinations and acquisition timing against NIfTI time units remain outside this assessment.

## Strict quoted TSV projection

`CheckedTsv.parse` exposes the same bounded quoted-TSV scanner used by strict event assessment, without imposing event column names or numeric semantics. It returns a typed `TsvIssue` or a checked table with physical row positions. Headers must be unique, nonblank and free of surrounding whitespace/control characters; rows must have the header's width, and empty cells must use `n/a`. Values such as `NA` and exact decimal strings remain lexical values. Limits are 4 MiB characters, 100,000 rows and 256 columns.

```scala mdoc
val sourceSummary = CheckedTsv.parse("session_id\tnote\tprivate\nses-a\tapproved\tsecret\n")
val publicSummary = for
  checked <- sourceSummary.left.map(_.message)
  projected <- checked.table.select(Vector("session_id", "note")).left.map(_.message)
yield CheckedTsv.render(projected)
```

`render` uses LF and quotes embedded tabs/newlines/quotes. Projection preserves retained cell spellings and missingness; it does not reproduce original whitespace or quoting. Preserve source bytes separately when an unchanged full table must be exported exactly. This API supplies TSV syntax; table-specific key constraints, row selection, BIDS relationships and disclosure rules belong to their respective profiles. Existing permissive table readers are unchanged.

## Explicit interpretation contexts

A checked `BidsContext` binds the ordered datatype registry, optional target BIDS
version, coverage statement and named rule versions. Default constructors and
loaders still use `BidsContext.Default`. A target version describes intended
coverage; it does not load the official schema or assert complete conformance.
The authored dataset `BIDSVersion` is independent.

```scala mdoc:compile-only
import bids4s.*
import bids4s.io.*

val configured = for
  kind <- BidsKind.from("light", Vector("opt.bin", "json"))
  context <- BidsContext.from("optical-v1", BidsRegistry.Builtin.withDatatype(
    BidsDatatypeSpec("optical", "optical", DatatypeScope.Raw,
      Vector(EntityRule(EntityKey.Subject, required = true)), Vector(kind))),
    Some("1.10.0"), "Experimental optical filename support")
yield
  val manifest = BidsManifest.fromRelativePathsChecked(
    Vector("sub-01/optical/sub-01_light.opt.bin"), context = context)
  (manifest.value.context, manifest.value.files.head.role,
    BidsLoadConfig(context = context), context.registryTokens, context.ruleVersions)
```

Manifest parsing, file roles, entity queries, metadata inheritance and explicit
MRI association resolvers use the manifest's context. Compound extensions can be
registered. Generic syntax remains available for inherited sidecars and preserved
unsupported roles; syntactic parsing alone does not establish scientific support.
Metadata resolutions carry their context, and the fieldmap batch seam rejects
mixed contexts. Loader `load`, `loadChecked`, `loadStrict` and their effectful/store
counterparts accept the same `BidsLoadConfig.context`.

`registryTokens` preserves registry priority, entity patterns, kinds, extensions,
scopes and derivative markers. Consumers can hash length-framed tokens; neither
`hashCode` nor map iteration order is a durable scientific identifier. Contexts
check duplicate descriptors, malformed patterns and descriptor budgets.

`BidsManifest` now has controlled construction. Its public `apply`, `unapply` and
`copy` entry points remain available; changing context reparses attached files.
It is no longer a `Product`/case class. This pre-release source change is not a
binary-compatibility promise. Full official-schema interpretation, reconstruction
of arbitrary plugin code from descriptors and arbitrary modality qualification
remain outside this context API.


## Phase-difference families and MRI header observations

`BidsPhaseDifferenceResolver` groups a `phasediff` image with required `magnitude1`
and optional `magnitude2` images. The bounded profile matches the same directory
and sub/ses/acq/run entities, treating numeric run padding equivalently. It never
borrows a magnitude from another session or participant. Duplicate representations,
missing required members, unresolved metadata and invalid echo ordering produce
stable issues. `EchoTime1` and `EchoTime2` must be finite, positive and ordered.
The separate explicit fieldmap resolver still identifies the consumer; a family
alone does not select an acquisition or prove distortion-correction suitability.

```scala mdoc
import bids4s.*
def phaseFamily(manifest: BidsManifest, metadata: Map[BidsPath, BidsMetadataResolution]) =
  BidsPhaseDifferenceResolver.fromResolved(manifest, metadata)
def mriHeader(bytes: Array[Byte], suffix: String, metadata: JsonValue.Obj) =
  NiftiHeaderFacts.parse(bytes).map(h => MriHeaderConsistency.check(h, suffix, metadata))
```

`NiftiHeaderFacts` v2 retains pixel dimensions, unit codes, qform/sform codes,
quaternion/offset parameters and sform rows in both NIfTI versions and byte orders.
These are raw observations: uncoded transform fields can contain nonfinite unused
values. No affine is preferred, no registration is inferred, and no fallback
orientation is invented. Existing scalar-header parse checks retain their behavior.

`MriHeaderConsistency` assesses supported T1w/T2w, BOLD, DWI, EPI, phasediff and
magnitude1/2 headers separately. It rejects invalid spatial sizes, unsupported
ranks, negative transform codes, malformed coded quaternions and singular/nonfinite
coded sforms. Unspecified spatial units or transforms warn. Regular BOLD TR is
compared in seconds only when the header supplies a supported time unit; the
explicit discrepancy policy warns at max(1 microsecond, 1e-5 × TR). Invalid declared
time spacing blocks this comparison profile. Variable `VolumeTiming` never acquires
an inferred uniform TR. Other metadata validity belongs to its existing checks.

These are partial structural and contextual rules, not full BIDS conformance,
geometry agreement between images, anatomical orientation or scanner qualification.
Rules follow [BIDS 1.11.1 MRI](https://bids-specification.readthedocs.io/en/v1.11.1/modality-specific-files/magnetic-resonance-imaging-data.html)
and the [NIfTI field definitions](https://nifti.nimh.nih.gov/nifti-1/documentation/nifti1fields/index_html.html).

### Scalar scaling observations

`NiftiScaling.parse` reads the effective scalar scaling from a checked header
prefix for either NIfTI version and byte order. Zero or NaN slope means identity;
the intercept is ignored in that case. Active scaling requires finite slope and
intercept. Infinite slope is explicitly rejected by this bounded policy.

```scala mdoc
val identityScaling = NiftiScaling.from(0, Double.NaN).toOption.get
assert(identityScaling.slope == 1 && identityScaling.intercept == 0)
val activeScaling = NiftiScaling.from(2.5, -7).toOption.get
assert(activeScaling.active)
assert(NiftiScaling.from(2, Double.NaN).isLeft)
```

The caller remains responsible for decoding supported scalar datatypes, applying
scaling without overflow, checking finite values, and verifying the complete
array and compressed stream. This API does not change header-only validation.


### Multi-echo BOLD and local event stimuli

`BidsMultiEchoResolver.fromResolved` resolves same-directory BOLD families using
all filename entities except `echo`. Numeric run and echo indices compare by
value; participant, session and acquisition labels remain lexical. This bounded
profile permits 2–16 magnitude BOLD files per family, requires positive finite
`EchoTime` increasing with echo index, and requires equal authored timing/task
and supported acquisition metadata. These are named consistency policies, not
claims that every rejected collection violates BIDS. Missing or duplicate echo
indices, indexed/unindexed mixtures, unsupported entities, placement errors and
metadata context mismatches have typed findings. Inventory is bounded at 10,000
BOLD files. Completeness means the supplied inventory, not unavailable scanner
acquisition evidence. No echo combination, registration or inferred anatomy occurs.

```scala mdoc
def echoFamilies(manifest: BidsManifest, resolved: Map[BidsPath, BidsMetadataResolution]) =
  BidsMultiEchoResolver.fromResolved(manifest, resolved)
val stimulusInventory = Set(BidsPath("stimuli/images/red.ppm"))
val localStimuli = BidsStimulusResolver.resolve(
  "onset\tduration\tstim_file\n0\t1\timages/red.ppm\n2\t1\tn/a\n", stimulusInventory)
assert(localStimuli.issues.isEmpty)
assert(localStimuli.paths == Vector(BidsPath("stimuli/images/red.ppm")))
assert(BidsStimulusResolver.path("../private.txt").isLeft)
```

`BidsStimulusResolver` parses strict TSV and resolves literal `stim_file` values
relative to dataset-root `stimuli/`. Missing `n/a` cells imply no asset; repeated
references deduplicate. Unicode filenames are retained. URLs, traversal, absolute
paths, backslashes, encoded paths and missing files fail explicitly. The named
profile permits 1,000 assets per table, bounds diagnostics at 64 plus a limit
finding, and retains the strict TSV size/row limits. It does not read asset bytes,
interpret HED, resolve external databases, or supply filesystem/network access.

Rules follow [BIDS 1.11.1 MRI multi-echo data](https://bids-specification.readthedocs.io/en/v1.11.1/modality-specific-files/magnetic-resonance-imaging-data.html)
and [event stimulus references](https://bids-specification.readthedocs.io/en/v1.11.1/modality-agnostic-files/events.html).
