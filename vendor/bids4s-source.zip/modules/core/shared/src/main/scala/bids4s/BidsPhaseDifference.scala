package bids4s

enum BidsPhaseDifferenceIssueCode:
  case Context, Placement, UnsupportedEntities, MissingMagnitude1, AmbiguousMember, Metadata, EchoTimes, LimitExceeded

final case class BidsPhaseDifferenceIssue(code: BidsPhaseDifferenceIssueCode, path: BidsPath, message: String)
final case class BidsPhaseDifferenceGroup(phase: BidsPath, magnitude1: BidsPath, magnitude2: Option[BidsPath],
    datasetRoot: Option[BidsPath], entities: Map[String, String]):
  def magnitudes: Vector[BidsPath] = Vector(magnitude1) ++ magnitude2
final case class BidsPhaseDifferenceReport(groups: Vector[BidsPhaseDifferenceGroup], issues: Vector[BidsPhaseDifferenceIssue])

/** Bounded same-directory, same-entity phasediff family. Magnitude2 is optional.
  * This does not infer a consumer, geometry suitability or a phase1/phase2 family.
  */
object BidsPhaseDifferenceResolver:
  val Version: String = "bids-phasediff-family-v1"
  private val roles = Set("phasediff", "magnitude1", "magnitude2")
  private val entities = Set("sub", "ses", "acq", "run")

  def fromResolved(manifest: BidsManifest, metadata: Map[BidsPath, BidsMetadataResolution]): BidsPhaseDifferenceReport =
    if metadata.exists((p, m) => p != m.target || m.context != manifest.context) then
      return BidsPhaseDifferenceReport(Vector.empty, Vector(BidsPhaseDifferenceIssue(BidsPhaseDifferenceIssueCode.Context,
        BidsPath("dataset_description.json"), "metadata and manifest contexts or targets differ")))
    val issues = Vector.newBuilder[BidsPhaseDifferenceIssue]
    val groups = Vector.newBuilder[BidsPhaseDifferenceGroup]
    def issue(code: BidsPhaseDifferenceIssueCode, path: BidsPath, message: String): Unit =
      val _ = issues += BidsPhaseDifferenceIssue(code, path, message)
    def normalized(n: BidsName): Map[String, String] = n.entities.values.map { (k, v) =>
      k.short -> (if k.short == "run" && v.forall(_.isDigit) then v.dropWhile(_ == '0') else v)
    }.toMap
    val images = manifest.files.flatMap { f =>
      manifest.context.parseGeneric(f.fileName).toOption.filter(n => roles(n.kind) && Set("nii", "nii.gz")(n.extension))
        .map(n => (f.path, n))
    }.distinct.sortBy(_._1.value)
    if images.size > 10000 then
      return BidsPhaseDifferenceReport(Vector.empty, Vector(BidsPhaseDifferenceIssue(BidsPhaseDifferenceIssueCode.LimitExceeded,
        images.head._1, "phase/magnitude inventory exceeds 10000 images")))
    val indexed = images.groupBy((p, n) => (p.parent, normalized(n), n.kind))
    images.filter(_._2.kind == "phasediff").foreach { (path, name) =>
      val keys = normalized(name)
      val local = metadata.get(path).flatMap(_.datasetRoot).fold(path.value)(r => path.value.stripPrefix(r.value + "/"))
      val expected = keys.get("sub").map(s => "sub-" + s + keys.get("ses").fold("")(v => "/ses-" + v) + "/fmap")
      if !expected.contains(local.split('/').dropRight(1).mkString("/")) then
        issue(BidsPhaseDifferenceIssueCode.Placement, path, "phasediff requires matching participant/session fmap placement")
      else if !keys.keySet.subsetOf(entities) then
        issue(BidsPhaseDifferenceIssueCode.UnsupportedEntities, path, "this phasediff family supports sub, ses, acq and run entities")
      else
        def member(role: String, required: Boolean): Option[BidsPath] =
          indexed.getOrElse((path.parent, keys, role), Vector.empty).map(_._1) match
            case Vector(p) => Some(p)
            case Vector() =>
              if required then issue(BidsPhaseDifferenceIssueCode.MissingMagnitude1, path, "required magnitude1 image is absent")
              None
            case _ =>
              issue(BidsPhaseDifferenceIssueCode.AmbiguousMember, path, s"multiple $role images match this family")
              None
        val phase = member("phasediff", true)
        val first = member("magnitude1", true)
        val second = member("magnitude2", false)
        val selected = Vector(path) ++ first ++ second
        val resolved = selected.flatMap(metadata.get)
        if resolved.size != selected.size || resolved.map(_.datasetRoot).distinct.size != 1 then
          issue(BidsPhaseDifferenceIssueCode.Metadata, path, "family members need resolved metadata in the same dataset")
        else
          val fields = metadata(path).metadata.fields
          val times = Vector("EchoTime1", "EchoTime2").map(k => fields.get(k).collect { case JsonValue.Num(v) if v.isFinite && v > 0 => v })
          if times.exists(_.isEmpty) || !times(0).zip(times(1)).exists((a, b) => a < b) then
            issue(BidsPhaseDifferenceIssueCode.EchoTimes, path, "phasediff requires positive EchoTime1 < EchoTime2, in seconds")
          if phase.contains(path) && first.nonEmpty && indexed.getOrElse((path.parent, keys, "magnitude2"), Vector.empty).size <= 1 then
            val _ = groups += BidsPhaseDifferenceGroup(path, first.get, second, metadata(path).datasetRoot,
              name.entities.values.map((k, v) => k.short -> v).toMap)
    }
    BidsPhaseDifferenceReport(groups.result(), issues.result().distinct.sortBy(i => (i.path.value, i.code.ordinal, i.message)))
