package bids4s

enum EventTimingMode:
  case Unavailable, Regular, Variable

/** A comparison window is context for warnings, not a scientific validity boundary. */
final class EventTiming private (
    val mode: EventTimingMode, val volumeCount: Option[Long],
    val lastVolumeOnset: Option[BigDecimal], val comparisonEnd: Option[BigDecimal],
    val originShift: Option[BigDecimal], val endBasis: String
)
final case class EventTimingAssessment(context: EventTiming, issues: Vector[EventIssue])

object EventTiming:
  val Version: String = "bids-events-timing-v1"
  val Fields: Set[String] = Set("RepetitionTime", "VolumeTiming", "FrameAcquisitionDuration", "SliceTiming", "DelayTime",
    "NumberOfVolumesDiscardedByScanner", "NumberOfVolumesDiscardedByUser")
  val MaxVolumes: Int = 100000

  def assess(volumeCount: Option[Long], fields: Map[String, JsonValue]): EventTimingAssessment =
    val issues = new EventIssueBuffer
    def error(field: String, message: String, code: EventIssueCode = EventIssueCode.TimingMetadata): Unit =
      issues.add(EventIssue(code, BidsIssueSeverity.Error, message, field = Some(field)))
    def numeric(value: JsonValue): Option[BigDecimal] = value match
      case JsonValue.Num(n) if n.isFinite => CheckedEvents.number(n.toString)
      case _ => None
    def positive(name: String): Option[BigDecimal] =
      fields.get(name).flatMap { v =>
        val n = numeric(v).filter(_ > 0)
        if n.isEmpty then error(name, "expected a finite positive number of seconds")
        n
      }
    def series(name: String): Option[Vector[BigDecimal]] =
      fields.get(name).flatMap {
        case JsonValue.Arr(values) if values.size <= MaxVolumes && values.nonEmpty =>
          val parsed = values.map(numeric)
          if parsed.exists(_.isEmpty) || parsed.flatten.exists(_ < 0) then
            error(name, "expected nonnegative finite seconds")
            None
          else Some(parsed.flatten)
        case JsonValue.Arr(values) if values.size > MaxVolumes =>
          error(name, "timing series exceeds 100000 values", EventIssueCode.LimitExceeded)
          None
        case _ =>
          error(name, "expected a nonempty array of seconds")
          None
      }
    if volumeCount.exists(_ <= 0) then error("volumeCount", "volume count must be positive", EventIssueCode.VolumeCount)
    val tr = positive("RepetitionTime")
    val times = series("VolumeTiming")
    val frame = positive("FrameAcquisitionDuration")
    if fields.contains("RepetitionTime") && fields.contains("VolumeTiming") then
      error("VolumeTiming", "RepetitionTime and VolumeTiming are mutually exclusive")
    if fields.contains("VolumeTiming") && fields.contains("DelayTime") then
      error("DelayTime", "DelayTime and VolumeTiming are mutually exclusive")
    times.foreach { ts =>
      if ts.sliding(2).exists(v => v.size == 2 && v(1) <= v(0)) then
        error("VolumeTiming", "volume onsets must be strictly increasing")
      if volumeCount.exists(_ != ts.size.toLong) then
        error("VolumeTiming", s"${ts.size} volume onsets disagree with image volume count", EventIssueCode.VolumeCount)
      if !fields.contains("FrameAcquisitionDuration") && !fields.contains("SliceTiming") then
        error("VolumeTiming", "VolumeTiming requires FrameAcquisitionDuration or SliceTiming")
    }
    if fields.contains("VolumeTiming") && fields.contains("SliceTiming") then
      val _ = series("SliceTiming")
    val findings = issues.result()
    def unavailable(reason: String): EventTimingAssessment =
      EventTimingAssessment(new EventTiming(EventTimingMode.Unavailable, volumeCount, None, None, None, reason),
        findings :+ EventIssue(EventIssueCode.TimingUnavailable, BidsIssueSeverity.Warning, reason))
    if findings.exists(_.severity == BidsIssueSeverity.Error) then unavailable("timing metadata is invalid")
    else volumeCount match
      case None => unavailable("image volume count is unavailable")
      case Some(n) => (tr, times) match
        case (Some(interval), None) =>
          EventTimingAssessment(new EventTiming(EventTimingMode.Regular, Some(n), Some(interval * (n - 1)),
            Some(interval * n), Some(BigDecimal(0)), "nominal volumeCount * RepetitionTime"), findings)
        case (None, Some(ts)) =>
          val last = ts.last - ts.head
          val end = frame.map(last + _)
          val basis = if end.nonEmpty then "last relative VolumeTiming + FrameAcquisitionDuration"
            else "final volume duration unavailable; SliceTiming does not establish its end in this profile"
          EventTimingAssessment(new EventTiming(EventTimingMode.Variable, Some(n), Some(last), end, Some(ts.head), basis),
            findings ++ Option.when(end.isEmpty)(EventIssue(EventIssueCode.TimingUnavailable, BidsIssueSeverity.Warning, basis)).toVector)
        case _ => unavailable("RepetitionTime and VolumeTiming are absent")

  def compare(events: CheckedEvents, timing: EventTiming): Vector[EventIssue] =
    val findings = new EventIssueBuffer
    timing.comparisonEnd.foreach { end =>
      events.onsets.indices.foreach { i =>
        val outside = events.onsets(i).exists(start =>
          start >= end || events.durations(i).exists(duration => start + duration > end))
        if outside then findings.add(EventIssue(EventIssueCode.OutsideWindow, BidsIssueSeverity.Warning,
          s"event extends beyond the recorded comparison window ending at ${end.bigDecimal.toPlainString} s; review timing alignment",
          Some(events.sourceRows(i)), Some(1)))
      }
    }
    findings.result()
