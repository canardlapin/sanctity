package bids4s

enum NiftiByteOrder:
  case LittleEndian, BigEndian

/** Header observations only. Coded transforms are retained separately; no preferred affine or anatomical alignment is inferred. */
final class NiftiHeaderFacts private (
    val version: Int, val byteOrder: NiftiByteOrder, val dimensions: Vector[Long],
    val datatype: Int, val bitsPerVoxel: Int, val dataOffset: Long, val minimumFileBytes: Long,
    val pixelDimensions: Vector[Double], val unitsCode: Int,
    val qformCode: Int, val sformCode: Int,
    val quaternion: Vector[Double], val qoffset: Vector[Double], val sformRows: Vector[Vector[Double]]
)

object NiftiHeaderFacts:
  val Version: String = "nifti-header-observations-v2"
  val MaxHeaderBytes: Int = 540
  private val scalarBits = Map(2 -> 8, 4 -> 16, 8 -> 32, 16 -> 32, 64 -> 64,
    256 -> 8, 512 -> 16, 768 -> 32, 1024 -> 64, 1280 -> 64)

  def headerSize(prefix: Array[Byte]): Either[DwiIssue, Int] =
    if prefix.length < 4 then Left(DwiIssue(DwiIssueCode.Header, "image", "truncated NIfTI size field"))
    else
      def size(little: Boolean): Int = (0 until 4).foldLeft(0)((n, i) =>
        n | ((prefix(if little then i else 3 - i) & 255) << (i * 8)))
      Vector(size(true), size(false)).find(n => n == 348 || n == 540)
        .toRight(DwiIssue(DwiIssueCode.Header, "image", "unsupported NIfTI header size"))

  /** Accepts a header prefix; never allocates according to image dimensions. */
  def parse(bytes: Array[Byte]): Either[DwiIssue, NiftiHeaderFacts] =
    def fail(code: DwiIssueCode, message: String) = Left(DwiIssue(code, "image", message))
    def number(offset: Int, width: Int, little: Boolean): Long =
      (0 until width).foldLeft(0L) { (value, i) =>
        val index = if little then offset + i else offset + width - 1 - i
        value | ((bytes(index).toLong & 255L) << (8 * i))
      }
    if bytes.length < 4 then fail(DwiIssueCode.Header, "truncated NIfTI size field")
    else
      val little = Set(348L, 540L)(number(0, 4, true))
      val size = number(0, 4, little)
      if !Set(348L, 540L)(size) then fail(DwiIssueCode.Header, "unsupported NIfTI header size")
      else if bytes.length < size then fail(DwiIssueCode.Header, s"truncated $size-byte NIfTI header")
      else
        val v1 = size == 348
        def real(offset: Int): Double =
          if v1 then java.lang.Float.intBitsToFloat(number(offset, 4, little).toInt).toDouble
          else java.lang.Double.longBitsToDouble(number(offset, 8, little))
        val width = if v1 then 4 else 8
        def reals(offset: Int, count: Int): Vector[Double] = Vector.tabulate(count)(i => real(offset + width * i))
        def signedCode(offset: Int): Int =
          if v1 then number(offset, 2, little).toShort.toInt else number(offset, 4, little).toInt
        val magic = if v1 then Vector(110, 43, 49, 0) else Vector(110, 43, 50, 0, 13, 10, 26, 10)
        val magicOffset = if v1 then 344 else 4
        val rank = if v1 then number(40, 2, little) else number(16, 8, little)
        val datatype = number(if v1 then 70 else 12, 2, little).toInt
        val bits = number(if v1 then 72 else 14, 2, little).toInt
        val floatOffset = if v1 then java.lang.Float.intBitsToFloat(number(108, 4, little).toInt).toDouble else 0.0
        val offset = if v1 then floatOffset.toLong else number(168, 8, little)
        if !magic.indices.forall(i => (bytes(magicOffset + i) & 255) == magic(i)) then
          fail(DwiIssueCode.Header, "expected single-file NIfTI magic; paired/Analyze files are unsupported")
        else if rank < 1 || rank > 7 then fail(DwiIssueCode.Dimensions, "NIfTI rank must be between 1 and 7")
        else if !scalarBits.contains(datatype) || scalarBits(datatype) != bits then
          fail(DwiIssueCode.Datatype, "unsupported scalar datatype or inconsistent bitpix")
        else if offset < size + 4 || (v1 && (!floatOffset.isFinite || floatOffset != offset.toDouble)) then
          fail(DwiIssueCode.Offset, "invalid single-file voxel offset")
        else
          val dims = (1 to rank.toInt).map(i => if v1 then number(40 + 2 * i, 2, little).toShort.toLong else number(16 + 8 * i, 8, little)).toVector
          val minimum = dims.foldLeft(BigInt(bits / 8))((acc, d) => acc * d) + offset
          if dims.exists(_ <= 0) then fail(DwiIssueCode.Dimensions, "active dimensions must be positive")
          else if !minimum.isValidLong then fail(DwiIssueCode.Dimensions, "array byte size exceeds supported 64-bit range")
          else Right(new NiftiHeaderFacts(if v1 then 1 else 2,
            if little then NiftiByteOrder.LittleEndian else NiftiByteOrder.BigEndian,
            dims, datatype, bits, offset, minimum.toLong,
            reals(if v1 then 76 else 104, 8), number(if v1 then 123 else 500, if v1 then 1 else 4, little).toInt,
            signedCode(if v1 then 252 else 344), signedCode(if v1 then 254 else 348),
            reals(if v1 then 256 else 352, 3), reals(if v1 then 268 else 376, 3),
            Vector.tabulate(3)(i => reals((if v1 then 280 else 400) + i * width * 4, 4))))
