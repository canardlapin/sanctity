package bids4s

enum BidsStimulusIssueCode:
  case Table, UnsafePath, MissingFile, LimitExceeded
final case class BidsStimulusIssue(code: BidsStimulusIssueCode, row: Int, message: String)
final case class BidsStimulusReport(paths: Vector[BidsPath], issues: Vector[BidsStimulusIssue])

/** Literal local paths beneath dataset-root stimuli/. No decoding, URLs or external lookups. */
object BidsStimulusResolver:
  val Version: String = "bids-stimuli-v1"
  def path(value: String): Either[String, BidsPath] =
    val parts = value.split("/", -1).toVector
    Either.cond(value.nonEmpty && value.length <= 4096 && value == value.trim &&
      !value.exists(c => c.isControl || c == '\\' || c == ':' || c == '%' || c == '?' || c == '#') &&
      parts.forall(p => p.nonEmpty && p != "." && p != ".."), BidsPath("stimuli/" + value), "stim_file requires a literal safe path relative to stimuli/")

  def resolve(text: String, inventory: Set[BidsPath]): BidsStimulusReport =
    CheckedTsv.parse(text) match
      case Left(error) => BidsStimulusReport(Vector.empty, Vector(BidsStimulusIssue(BidsStimulusIssueCode.Table, error.row, error.message)))
      case Right(checked) =>
        val column = checked.table.columns.indexOf("stim_file")
        if column < 0 then BidsStimulusReport(Vector.empty, Vector.empty)
        else
          val paths = Vector.newBuilder[BidsPath]
          val issues = Vector.newBuilder[BidsStimulusIssue]
          var failures = 0
          checked.table.rows.zipWithIndex.foreach { (row, i) =>
            row(column).foreach { value =>
              val result = path(value).left.map(m => BidsStimulusIssue(BidsStimulusIssueCode.UnsafePath, checked.sourceRows(i), m))
                .flatMap(p => Either.cond(inventory(p), p, BidsStimulusIssue(BidsStimulusIssueCode.MissingFile, checked.sourceRows(i), "referenced stimulus is absent: " + p.value)))
              result match
                case Right(p) => val _ = paths += p
                case Left(issue) =>
                  if failures < 64 then { val _ = issues += issue }
                  failures += 1
            }
          }
          val members = paths.result().distinct.sortBy(_.value)
          if failures > 64 || members.size > 1000 then
            BidsStimulusReport(Vector.empty, issues.result() :+ BidsStimulusIssue(BidsStimulusIssueCode.LimitExceeded, 0, "stimulus profile exceeds 64 findings or 1000 assets per table"))
          else BidsStimulusReport(members, issues.result())
