package bids4s

import cats.syntax.all.*
import scala.util.control.NonFatal

enum BidsScope:
  case All
  case Raw
  case Derivatives

enum MatchMode:
  case Regex
  case Exact
  case Glob

enum EntityPresence:
  case Present
  case Absent
  case Optional

enum QueryPattern:
  case Regex(pattern: String)
  case Exact(value: String)
  case Glob(pattern: String)

  def asFilenameRegex: String =
    this match
      case QueryPattern.Regex(pattern) => pattern
      case QueryPattern.Exact(value) => "^" + Matching.quoteRegex(value) + "$"
      case QueryPattern.Glob(pattern) => Matching.globToRegex(pattern)

object QueryPattern:
  def regex(pattern: String): Either[BidsError, QueryPattern] =
    Matching.validateRegex(pattern).map(QueryPattern.Regex(_))

  def exact(value: String): Either[BidsError, QueryPattern] =
    checkedPatternValue(value, "exact query value").map(QueryPattern.Exact(_))

  def glob(pattern: String): Either[BidsError, QueryPattern] =
    checkedPatternValue(pattern, "glob query pattern").map(QueryPattern.Glob(_))

  private def checkedPatternValue(value: String, label: String): Either[BidsError, String] =
    val clean = value.trim
    if clean.isEmpty then Left(BidsError.InvalidQuery(s"$label must be non-empty"))
    else Right(clean)

private[bids4s] enum EntitySelection:
  case Values(values: Vector[String])
  case Presence(value: EntityPresence)

final class EntityFilter private (
    val key: EntityKey,
    private[bids4s] val selection: EntitySelection
):
  def values: Vector[String] =
    selection match
      case EntitySelection.Values(values) => values
      case EntitySelection.Presence(_)    => Vector.empty

  def presence: Option[EntityPresence] =
    selection match
      case EntitySelection.Values(_)         => None
      case EntitySelection.Presence(presence) => Some(presence)

  def nonEmpty: Boolean = true

  override def equals(other: Any): Boolean =
    other match
      case that: EntityFilter => key == that.key && selection == that.selection
      case _                  => false

  override def hashCode(): Int =
    (key, selection).##

  override def toString: String =
    selection match
      case EntitySelection.Values(values) =>
        s"EntityFilter($key,$values)"
      case EntitySelection.Presence(presence) =>
        s"EntityFilter($key,$presence)"

object EntityFilter:
  def from(key: EntityKey, value: String): Either[BidsError, EntityFilter] =
    from(key, Vector(value))

  def from(key: EntityKey, values: Vector[String]): Either[BidsError, EntityFilter] =
    if values.isEmpty then Left(BidsError.InvalidQuery("EntityFilter requires at least one value"))
    else if values.exists(_.trim.isEmpty) then Left(BidsError.InvalidQuery("EntityFilter values must be non-empty"))
    else Right(new EntityFilter(key, EntitySelection.Values(values.map(_.trim))))

  def present(key: EntityKey): EntityFilter =
    new EntityFilter(key, EntitySelection.Presence(EntityPresence.Present))

  def absent(key: EntityKey): EntityFilter =
    new EntityFilter(key, EntitySelection.Presence(EntityPresence.Absent))

  def optional(key: EntityKey): EntityFilter =
    new EntityFilter(key, EntitySelection.Presence(EntityPresence.Optional))

  private[bids4s] def unsafe(key: EntityKey, value: String): EntityFilter =
    unsafe(key, Vector(value))

  private[bids4s] def unsafe(key: EntityKey, values: Vector[String]): EntityFilter =
    require(values.nonEmpty, "EntityFilter requires at least one value")
    require(values.forall(_.trim.nonEmpty), "EntityFilter values must be non-empty")
    new EntityFilter(key, EntitySelection.Values(values.map(_.trim)))

final class BidsQuery private (
    val filename: Vector[String],
    val filters: Vector[EntityFilter],
    val matchMode: MatchMode,
    val requireEntity: Boolean,
    val scope: BidsScope,
    val pipeline: Option[PipelineName],
    val strict: Boolean
):
  override def equals(other: Any): Boolean =
    other match
      case that: BidsQuery =>
        filename == that.filename &&
          filters == that.filters &&
          matchMode == that.matchMode &&
          requireEntity == that.requireEntity &&
          scope == that.scope &&
          pipeline == that.pipeline &&
          strict == that.strict
      case _ => false

  override def hashCode(): Int =
    (filename, filters, matchMode, requireEntity, scope, pipeline, strict).##

  override def toString: String =
    s"BidsQuery($filename,$filters,$matchMode,$requireEntity,$scope,$pipeline,$strict)"

object BidsQuery:
  val All: BidsQuery = unsafe()

  def present(
      key: EntityKey,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None
  ): BidsQuery =
    unsafe(
      filters = Vector(EntityFilter.present(key)),
      scope = scope,
      pipeline = pipeline
    )

  def absent(
      key: EntityKey,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None
  ): BidsQuery =
    unsafe(
      filters = Vector(EntityFilter.absent(key)),
      scope = scope,
      pipeline = pipeline
    )

  def run(
      index: Int,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None
  ): Either[BidsError, BidsQuery] =
    if index < 0 then Left(BidsError.InvalidQuery("run index must be nonnegative"))
    else exact(EntityKey.Run, index.toString, scope, pipeline)

  def exact(
      key: EntityKey,
      value: String,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None
  ): Either[BidsError, BidsQuery] =
    exact(Vector(key -> value), scope, pipeline)

  def exact(filters: Vector[(EntityKey, String)]): Either[BidsError, BidsQuery] =
    exact(filters, BidsScope.All, None)

  def exact(
      filters: Vector[(EntityKey, String)],
      scope: BidsScope
  ): Either[BidsError, BidsQuery] =
    exact(filters, scope, None)

  def exact(
      filters: Vector[(EntityKey, String)],
      scope: BidsScope,
      pipeline: Option[PipelineName]
  ): Either[BidsError, BidsQuery] =
    if filters.isEmpty then Left(BidsError.InvalidQuery("exact query requires at least one entity filter"))
    else
      BidsEither
        .traverse(filters) { case (key, value) => EntityFilter.from(key, value) }
        .flatMap { checkedFilters =>
          from(
            filters = checkedFilters,
            matchMode = MatchMode.Exact,
            scope = scope,
            pipeline = pipeline
          )
        }

  def from(
      filename: Vector[String] = Vector(".*"),
      filters: Vector[EntityFilter] = Vector.empty,
      matchMode: MatchMode = MatchMode.Regex,
      requireEntity: Boolean = false,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None,
      strict: Boolean = true
  ): Either[BidsError, BidsQuery] =
    fromChecked(filename, filters, matchMode, requireEntity, scope, pipeline, strict)
      .left
      .map(report => BidsError.InvalidQuery(report.primary.message))

  def fromChecked(
      filename: Vector[String] = Vector(".*"),
      filters: Vector[EntityFilter] = Vector.empty,
      matchMode: MatchMode = MatchMode.Regex,
      requireEntity: Boolean = false,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None,
      strict: Boolean = true
  ): Either[BidsIssueReport, BidsQuery] =
    val filenamePresence =
      if filename.nonEmpty then BidsValidation.valid(())
      else
        BidsValidation.invalid(
          BidsIssue.error(
            BidsIssueCode.InvalidQuery,
            None,
            Some("filename"),
            "BidsQuery.filename requires at least one pattern"
          )
        )
    val filenameChecks =
      BidsValidation.all(
        filename.zipWithIndex.flatMap { case (pattern, index) =>
          Matching.validateRegex(pattern).left.toOption.map { error =>
            BidsValidation.invalid(
              BidsIssue.error(
                BidsIssueCode.InvalidQuery,
                None,
                Some(s"filename[$index]"),
                error.message
              )
            )
          }
        }
      )
    val filterPresenceChecks =
      BidsValidation.all(
        filters.zipWithIndex.collect { case (filter, index) if !filter.nonEmpty =>
          BidsValidation.invalid(
            BidsIssue.error(
              BidsIssueCode.InvalidQuery,
              None,
              Some(s"filters[$index]"),
              s"EntityFilter '${filter.key.short}' requires at least one value"
            )
          )
        }
      )
    val filterPatternChecks =
      if matchMode != MatchMode.Regex then BidsValidation.valid(())
      else
        BidsValidation.all(
          filters.zipWithIndex.flatMap { case (filter, filterIndex) =>
            filter.values.zipWithIndex.flatMap { case (pattern, valueIndex) =>
              Matching.validateRegex(pattern).left.toOption.map { error =>
                BidsValidation.invalid(
                  BidsIssue.error(
                    BidsIssueCode.InvalidQuery,
                    None,
                    Some(s"filters[$filterIndex].values[$valueIndex]"),
                    error.message
                  )
                )
              }
            }
          }
        )

    BidsValidation.toEither(
      (filenamePresence, filenameChecks, filterPresenceChecks, filterPatternChecks).mapN { (_, _, _, _) =>
        new BidsQuery(
          filename = filename,
          filters = filters,
          matchMode = matchMode,
          requireEntity = requireEntity,
          scope = scope,
          pipeline = pipeline,
          strict = strict
        )
      }
    )

  private[bids4s] def unsafe(
      filename: Vector[String] = Vector(".*"),
      filters: Vector[EntityFilter] = Vector.empty,
      matchMode: MatchMode = MatchMode.Regex,
      requireEntity: Boolean = false,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None,
      strict: Boolean = true
  ): BidsQuery =
    require(filename.nonEmpty, "BidsQuery.filename requires at least one pattern")
    require(filters.forall(_.nonEmpty), "EntityFilter requires at least one value")
    new BidsQuery(filename, filters, matchMode, requireEntity, scope, pipeline, strict)

  def fromPatterns(
      filename: Vector[QueryPattern],
      filters: Vector[EntityFilter] = Vector.empty,
      matchMode: MatchMode = MatchMode.Regex,
      requireEntity: Boolean = false,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None,
      strict: Boolean = true
  ): Either[BidsError, BidsQuery] =
    if filename.isEmpty then Left(BidsError.InvalidQuery("BidsQuery.filename requires at least one pattern"))
    else
      from(
        filename = filename.map(_.asFilenameRegex),
        filters = filters,
        matchMode = matchMode,
        requireEntity = requireEntity,
        scope = scope,
        pipeline = pipeline,
        strict = strict
      )

private[bids4s] object Matching:
  def validateRegexPatterns(patterns: Vector[String]): Either[BidsError, Vector[String]] =
    BidsEither.traverse(patterns)(validateRegex)

  def validateRegex(pattern: String): Either[BidsError, String] =
    val clean = pattern.trim
    if clean.isEmpty then Left(BidsError.InvalidQuery("regex pattern must be non-empty"))
    else
      try
        val _ = clean.r
        Right(clean)
      catch
        case NonFatal(ex) => Left(BidsError.InvalidQuery(s"invalid regex '$pattern': ${ex.getMessage}"))

  def filenameMatches(value: String, patterns: Vector[String]): Boolean =
    patterns.exists(regexFind(value, _))

  def entityMatches(value: String, filter: EntityFilter, mode: MatchMode): Boolean =
    mode match
      case MatchMode.Regex =>
        filter.values.exists(regexFind(value, _))
      case MatchMode.Exact =>
        val canonicalValue = canonicalExactValue(filter.key, value)
        filter.values.exists(expected => canonicalExactValue(filter.key, expected) == canonicalValue)
      case MatchMode.Glob =>
        filter.values.exists(pattern => value.matches(globToRegex(pattern)))

  def canonicalExactValue(key: EntityKey, value: String): String =
    if key == EntityKey.Run && value.nonEmpty && value.forall(char => char >= '0' && char <= '9')
    then
      val unpadded = value.dropWhile(_ == '0')
      if unpadded.isEmpty then "0" else unpadded
    else value

  def isWildcard(filter: EntityFilter, mode: MatchMode): Boolean =
    (mode == MatchMode.Regex && filter.values == Vector(".*")) ||
      (mode == MatchMode.Glob && filter.values == Vector("*"))

  def globToRegex(glob: String): String =
    val out = new StringBuilder("^")
    glob.foreach {
      case '*' => out.append(".*")
      case '?' => out.append(".")
      case c if "\\.[]{}()+-^$|".contains(c) => out.append('\\').append(c)
      case c => out.append(c)
    }
    out.append("$").toString

  def quoteRegex(value: String): String =
    val out = new StringBuilder
    value.foreach {
      case c if "\\.[]{}()+-^$|*?".contains(c) => out.append('\\').append(c)
      case c => out.append(c)
    }
    out.toString

  private def regexFind(value: String, pattern: String): Boolean =
    try pattern.r.findFirstIn(value).isDefined
    catch case NonFatal(_) => false
