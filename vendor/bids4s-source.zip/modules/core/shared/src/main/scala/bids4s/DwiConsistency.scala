package bids4s

enum DwiIssueCode:
  case Shape, Number, NegativeBValue, LimitExceeded, Header, Dimensions, Datatype, Offset
  case BvalCount, BvecCount, VectorNorm, UnsupportedDimensions

final case class DwiIssue(code: DwiIssueCode, input: String, message: String,
    row: Option[Int] = None, column: Option[Int] = None)

final class BValues private (val values: Vector[Double])
object BValues:
  def parse(text: String): Either[Vector[DwiIssue], BValues] =
    GradientText.parse(text, "bval", 1).flatMap { rows =>
      val values = rows.head
      val errors = values.zipWithIndex.collect { case (v, i) if v < 0 =>
        DwiIssue(DwiIssueCode.NegativeBValue, "bval", "b-values must be nonnegative", Some(1), Some(i + 1))
      }.take(GradientText.MaxIssues)
      Either.cond(errors.isEmpty, new BValues(values), errors)
    }

final case class GradientVector(x: Double, y: Double, z: Double):
  def norm: Double = math.sqrt(x * x + y * y + z * z)

final class BVectors private (val values: Vector[GradientVector])
object BVectors:
  def parse(text: String): Either[Vector[DwiIssue], BVectors] =
    GradientText.parse(text, "bvec", 3).map { rows =>
      new BVectors(rows.head.indices.map(i => GradientVector(rows(0)(i), rows(1)(i), rows(2)(i))).toVector)
    }

/** Strict bounded FSL text parsing. Blank outer lines, CRLF, spaces and tabs are accepted.
  * Invalid/transposed tables are never silently repaired. At most MaxIssues are reported.
  */
object GradientText:
  val MaxCharacters: Int = 4 * 1024 * 1024
  val MaxVolumes: Int = 100000
  val MaxIssues: Int = 64
  private val Decimal = "[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?".r

  private[bids4s] def parse(text: String, input: String, expectedRows: Int): Either[Vector[DwiIssue], Vector[Vector[Double]]] =
    def error(code: DwiIssueCode, message: String) = Left(Vector(DwiIssue(code, input, message)))
    if text.length > MaxCharacters then error(DwiIssueCode.LimitExceeded, "gradient text exceeds 4 MiB characters")
    else
      val lines = text.replace("\r\n", "\n").split("\n", -1).toVector.dropWhile(_.trim.isEmpty).reverse.dropWhile(_.trim.isEmpty).reverse
      if lines.size != expectedRows || lines.exists(_.trim.isEmpty) then
        error(DwiIssueCode.Shape, s"expected $expectedRows nonempty row(s)")
      else
        val cells = lines.map(_.trim.split("[ \\t]+", -1).toVector)
        if cells.exists(_.size > MaxVolumes) then error(DwiIssueCode.LimitExceeded, "gradient count exceeds 100000")
        else if cells.map(_.size).distinct.size != 1 then error(DwiIssueCode.Shape, "gradient rows have different column counts")
        else
          val issues = Vector.newBuilder[DwiIssue]
          var count = 0
          val rows = cells.zipWithIndex.map { (row, r) =>
            row.zipWithIndex.map { (token, c) =>
              val value = Option.when(token.length <= 128 && Decimal.pattern.matcher(token).matches())(token.toDoubleOption).flatten.filter(n => n.isFinite &&
                (n != 0.0 || !token.takeWhile(c => c != 'e' && c != 'E').exists(c => c >= '1' && c <= '9')))
              value match
                case Some(n) => n
                case None =>
                  if count < MaxIssues then
                    issues += DwiIssue(DwiIssueCode.Number, input, "expected a finite decimal number", Some(r + 1), Some(c + 1))
                  count += 1
                  0.0
            }
          }
          val errors = issues.result()
          Either.cond(errors.isEmpty, rows, errors)

/** Versioned numeric policy; these tolerances are repository choices, not BIDS constants. */
object DwiConsistency:
  val Version: String = "bids-dwi-consistency-v1"
  val LowBMaximum: Double = 50.0
  val UnitNormTolerance: Double = 0.01
  val ZeroNormTolerance: Double = 0.000001

  def check(header: NiftiHeaderFacts, bvals: BValues, bvecs: BVectors): Vector[DwiIssue] =
    val findings = Vector.newBuilder[DwiIssue]
    if !Set(3, 4)(header.dimensions.size) then
      findings += DwiIssue(DwiIssueCode.UnsupportedDimensions, "image", "DWI profile requires a 3D or 4D scalar image")
    else
      val volumes = header.dimensions.lift(3).getOrElse(1L)
      if bvals.values.size.toLong != volumes then
        findings += DwiIssue(DwiIssueCode.BvalCount, "bval", s"${bvals.values.size} b-values for $volumes image volumes")
      if bvecs.values.size.toLong != volumes then
        findings += DwiIssue(DwiIssueCode.BvecCount, "bvec", s"${bvecs.values.size} vectors for $volumes image volumes")
      if bvals.values.size == bvecs.values.size then
        val norms = bvals.values.zip(bvecs.values).zipWithIndex.collect {
          case ((b, vector), i) if !validNorm(b, vector.norm) =>
            DwiIssue(DwiIssueCode.VectorNorm, "bvec",
              "expected unit norm within 0.01, or zero within 1e-6 when b <= 50 s/mm^2", column = Some(i + 1))
        }
        findings ++= norms.take(GradientText.MaxIssues)
    findings.result()

  private def validNorm(b: Double, norm: Double): Boolean =
    norm.isFinite && (math.abs(norm - 1.0) <= UnitNormTolerance ||
      (b <= LowBMaximum && norm <= ZeroNormTolerance))
