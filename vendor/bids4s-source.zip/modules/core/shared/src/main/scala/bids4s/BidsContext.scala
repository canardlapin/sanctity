package bids4s

import scala.util.Try

/** Explicit interpretation configuration. A target specification version is a
  * declaration of intent, not a claim of complete schema coverage.
  * Registry order is significant: the first accepting specification wins.
  */
final class BidsContext private (
    val name: String, val registry: BidsRegistry,
    val specificationVersion: Option[String], val coverage: String
):
  val ruleVersions: Map[String, String] = Map(
    "names" -> "bids-registry-names-v1", "manifest" -> "bids-manifest-diagnostics-v1",
    "metadata" -> "bids-json-inheritance-v1", "metadata-validation" -> "bids-metadata-checks-v1",
    "query" -> "bids-entity-selection-v1", "fieldmaps" -> BidsFieldmapResolver.Version,
    "companions" -> BidsCompanionResolver.Version, "phasediff" -> BidsPhaseDifferenceResolver.Version)
  val registryTokens: Vector[String] = BidsContext.describe(registry)
  val tokens: Vector[String] = Vector("bids-context-v1", name, specificationVersion.getOrElse(""), coverage,
    registryTokens.size.toString) ++ registryTokens ++ ruleVersions.toVector.sortBy(_._1).flatMap((k, v) => Vector(k, v))
  def parse(filename: String): Either[BidsError, BidsName] = registry.parse(filename)
  def parseGeneric(filename: String): Either[BidsError, BidsName] = registry.parseGeneric(filename)
  def parsePath(path: BidsPath, scope: BidsScope = BidsScope.All): Either[BidsError, BidsName] = registry.parsePath(path, scope)
  def extensions: Vector[String] = registry.extensions
  override def equals(other: Any): Boolean = other match
    case c: BidsContext => tokens == c.tokens
    case _ => false
  override def hashCode(): Int = tokens.hashCode()
  override def toString: String = s"BidsContext($name,${specificationVersion.getOrElse("unversioned")})"

object BidsContext:
  val Default: BidsContext = new BidsContext("bids4s-builtins-v1", BidsRegistry.Builtin, None,
    "Partial MRI/raw and derivative registry; JSON inheritance, entity queries and explicit MRI companions/fieldmaps. Not full BIDS schema validation.")

  def from(name: String, registry: BidsRegistry, specificationVersion: Option[String] = None,
      coverage: String = "Custom registry; coverage must be qualified by the consumer."): Either[BidsError, BidsContext] =
    def label(s: String): Boolean = s.nonEmpty && s.length <= 200 && !s.exists(_.isControl)
    def token(s: String): Boolean = s.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,99}")
    val valid = label(name) && coverage.nonEmpty && coverage.length <= 4096 &&
      specificationVersion.forall(v => v.length <= 32 && v.matches("[0-9]+\\.[0-9]+\\.[0-9]+")) &&
      registry.specs.nonEmpty && registry.specs.size <= 256 && registry.specs.map(_.name).distinct.size == registry.specs.size &&
      registry.specs.forall { s =>
        token(s.name) && token(s.folder) && s.entities.size <= 128 && s.kinds.nonEmpty && s.kinds.size <= 256 &&
          s.entities.map(_.key).distinct.size == s.entities.size &&
          s.entities.forall(r => token(r.key.short) && r.pattern.forall(p => p.length <= 1024 && Try(p.r).isSuccess)) &&
          s.kinds.map(_.name).distinct.size == s.kinds.size && s.kinds.forall(k => token(k.name) && k.extensions.nonEmpty && k.extensions.size <= 32 && k.extensions.distinct.size == k.extensions.size && k.extensions.forall(token)) &&
          s.derivativeMarkers.distinct.size == s.derivativeMarkers.size && s.derivativeMarkers.forall(k => s.entities.exists(_.key == k)) &&
          s.derivativeKinds.distinct.size == s.derivativeKinds.size && s.derivativeKinds.forall(k => s.kinds.exists(_.name == k))
      }
    val descriptor = if valid then describe(registry) else Vector.empty
    if valid && descriptor.size <= 100000 && descriptor.foldLeft(0L)(_ + _.length) <= 1024 * 1024 then
      Right(new BidsContext(name, registry, specificationVersion, coverage))
    else Left(BidsError.InvalidContext("invalid, duplicate or oversized registry descriptor, version or regular expression"))

  /** Portable canonical descriptor; consumers may hash these framed tokens with
    * their chosen digest algorithm. Nothing depends on JVM hashCode or map order.
    */
  private def describe(registry: BidsRegistry): Vector[String] =
    Vector("bids-registry-v1", registry.specs.size.toString) ++ registry.specs.flatMap { s =>
      Vector(s.name, s.folder, s.scope.toString, s.entities.size.toString) ++
        s.entities.flatMap(r => Vector(r.key.short, r.required.toString, r.pattern.fold("absent")(_ => "present")) ++ r.pattern.toVector) ++
        Vector(s.kinds.size.toString) ++ s.kinds.flatMap(k => Vector(k.name, k.extensions.size.toString) ++ k.extensions) ++
        Vector(s.derivativeMarkers.size.toString) ++ s.derivativeMarkers.map(_.short) ++
        Vector(s.derivativeKinds.size.toString) ++ s.derivativeKinds
    }
