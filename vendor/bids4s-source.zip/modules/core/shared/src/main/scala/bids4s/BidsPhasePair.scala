package bids4s

enum BidsPhasePairIssueCode:
  case Context, Placement, UnsupportedEntities, MissingMember, AmbiguousMember, MixedRepresentation, Metadata, EchoTimes, LimitExceeded

final case class BidsPhasePairIssue(code: BidsPhasePairIssueCode, path: BidsPath, message: String)
final case class BidsPhasePairGroup(phase1: BidsPath, phase2: BidsPath, magnitude1: BidsPath, magnitude2: BidsPath,
    datasetRoot: Option[BidsPath], entities: Map[String, String], evidence: Vector[BidsAssociationEvidence]):
  def members: Vector[BidsPath] = Vector(phase1, phase2, magnitude1, magnitude2)
final case class BidsPhasePairReport(groups: Vector[BidsPhasePairGroup], issues: Vector[BidsPhasePairIssue])

/** Bounded same-directory two-phase/two-magnitude family; no inferred consumers or phase physics. */
object BidsPhasePairResolver:
  val Version: String = "bids-phase-pair-family-v1"
  private val required = Vector("phase1", "phase2", "magnitude1", "magnitude2")
  private val roles = required.toSet + "phasediff"
  private val allowedEntities = Set("sub", "ses", "acq", "run")

  def fromResolved(manifest: BidsManifest, metadata: Map[BidsPath, BidsMetadataResolution]): BidsPhasePairReport =
    if metadata.exists((p, m) => p != m.target || m.context != manifest.context) then
      return BidsPhasePairReport(Vector.empty, Vector(BidsPhasePairIssue(BidsPhasePairIssueCode.Context,
        BidsPath("dataset_description.json"), "metadata and manifest contexts or targets differ")))
    def normalized(n: BidsName): Map[String, String] = n.entities.values.map { (k, v) =>
      k.short -> (if k.short == "run" && v.forall(_.isDigit) then v.dropWhile(_ == '0') else v)
    }.toMap
    val images = manifest.files.flatMap { f =>
      manifest.context.parseGeneric(f.fileName).toOption.filter(n => roles(n.kind) && Set("nii", "nii.gz")(n.extension))
        .map(n => f.path -> n)
    }.distinct.sortBy(_._1.value)
    if images.size > 10000 then
      return BidsPhasePairReport(Vector.empty, Vector(BidsPhasePairIssue(BidsPhasePairIssueCode.LimitExceeded,
        images.head._1, "phase-family inventory exceeds 10000 images")))
    val index = images.groupBy((p, n) => (p.parent, normalized(n), n.kind))
    val anchors = images.filter((_, n) => Set("phase1", "phase2")(n.kind))
      .distinctBy((p, n) => (p.parent, normalized(n)))
    val groups = Vector.newBuilder[BidsPhasePairGroup]
    val issues = Vector.newBuilder[BidsPhasePairIssue]
    anchors.foreach { (anchor, name) =>
      var valid = true
      def issue(code: BidsPhasePairIssueCode, message: String): Unit =
        valid = false
        val _ = issues += BidsPhasePairIssue(code, anchor, message)
      val keys = normalized(name)
      if !keys.keySet.subsetOf(allowedEntities) then
        issue(BidsPhasePairIssueCode.UnsupportedEntities, "phase-pair families support only sub, ses, acq and run entities")
      def paths(role: String): Vector[BidsPath] = index.getOrElse((anchor.parent, keys, role), Vector.empty).map(_._1)
      if paths("phasediff").nonEmpty then
        issue(BidsPhasePairIssueCode.MixedRepresentation, "phasediff and separate-phase representations share the same family entities")
      val members = required.flatMap { role =>
        paths(role) match
          case Vector(p) => Some(role -> p)
          case Vector() =>
            issue(BidsPhasePairIssueCode.MissingMember, s"required $role image is absent")
            None
          case _ =>
            issue(BidsPhasePairIssueCode.AmbiguousMember, s"multiple $role images match this family")
            None
      }.toMap
      val resolved = members.values.toVector.flatMap(metadata.get)
      if resolved.size != members.size || resolved.map(_.datasetRoot).distinct.size != 1 then
        issue(BidsPhasePairIssueCode.Metadata, "family members need resolved metadata in the same dataset")
      resolved.foreach { m =>
        val local = m.datasetRoot.fold(m.target.value)(r => m.target.value.stripPrefix(r.value + "/"))
        val expected = keys.get("sub").map(s => "sub-" + s + keys.get("ses").fold("")(v => "/ses-" + v) + "/fmap")
        if !expected.contains(local.split('/').dropRight(1).mkString("/")) then
          issue(BidsPhasePairIssueCode.Placement, "phase-pair members require matching participant/session fmap placement")
      }
      def field(role: String): Option[JsonValue] = members.get(role).flatMap(metadata.get).flatMap(_.metadata.fields.get("EchoTime"))
      def time(role: String): Option[Double] = field(role).collect { case JsonValue.Num(v) if v.isFinite && v > 0 => v }
      if members.size == required.size && resolved.size == required.size then
        if !time("phase1").zip(time("phase2")).exists((a, b) => a < b) then
          issue(BidsPhasePairIssueCode.EchoTimes, "phase images require positive finite EchoTime with phase1 < phase2, in seconds")
        Vector(1, 2).foreach { n =>
          if field(s"magnitude$n").nonEmpty && (time(s"magnitude$n").isEmpty || time(s"magnitude$n") != time(s"phase$n")) then
            issue(BidsPhasePairIssueCode.EchoTimes, s"magnitude$n EchoTime must equal phase$n EchoTime when supplied")
        }
      if valid && members.size == required.size then
        val proof = resolved.flatMap(m => m.origins.get("EchoTime").map(d => BidsAssociationEvidence(m.target, d, "EchoTime")))
          .distinct.sortBy(e => (e.artifact.value, e.document.value, e.field))
        val _ = groups += BidsPhasePairGroup(members("phase1"), members("phase2"), members("magnitude1"), members("magnitude2"),
          metadata(members("phase1")).datasetRoot, name.entities.values.map((k, v) => k.short -> v).toMap, proof)
    }
    BidsPhasePairReport(groups.result().sortBy(_.phase1.value), issues.result().distinct.sortBy(i => (i.path.value, i.code.ordinal, i.message)))
