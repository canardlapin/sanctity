package bids4s

import scala.util.Try

enum EventIssueCode:
  case Syntax, Header, Width, MissingValue, Number, Duration, Order, LimitExceeded
  case TimingMetadata, VolumeCount, TimingUnavailable, OutsideWindow

final case class EventIssue(code: EventIssueCode, severity: BidsIssueSeverity, message: String,
    row: Option[Int] = None, column: Option[Int] = None, field: Option[String] = None)

final case class EventTableAssessment(table: Option[CheckedEvents], issues: Vector[EventIssue])

/** Strict, bounded event assessment. Existing permissive BidsTable/EventsTable APIs are unchanged.
  * Decimal seconds are exact; authored text remains the caller's source of export bytes.
  */
final class CheckedEvents private (
    val table: BidsTable, val onsets: Vector[Option[BigDecimal]],
    val durations: Vector[Option[BigDecimal]], val sourceRows: Vector[Int]
)

object CheckedEvents:
  val Version: String = "bids-events-content-v1"
  val MaxCharacters: Int = 4 * 1024 * 1024
  val MaxRows: Int = 100000
  val MaxColumns: Int = 256
  val MaxIssues: Int = 64
  private val decimal = "[+-]?(?:[0-9]+(?:\\.[0-9]*)?|\\.[0-9]+)(?:[eE][+-]?[0-9]+)?".r

  private[bids4s] def number(token: String): Option[BigDecimal] =
    Option.when(token.length <= 128 && decimal.pattern.matcher(token).matches())(token)
      .flatMap(s => Try(BigDecimal(s, java.math.MathContext.UNLIMITED)).toOption)
      .filter(n => math.abs(n.scale.toLong) <= 308 && n.precision <= 128)

  def assess(text: String): EventTableAssessment =
    CheckedTsv.records(text).left.map { issue =>
      val code = issue.code match
        case TsvIssueCode.Syntax => EventIssueCode.Syntax
        case TsvIssueCode.Header => EventIssueCode.Header
        case TsvIssueCode.Width => EventIssueCode.Width
        case TsvIssueCode.MissingValue => EventIssueCode.MissingValue
        case TsvIssueCode.LimitExceeded => EventIssueCode.LimitExceeded
      EventIssue(code, BidsIssueSeverity.Error,
        issue.message, Some(issue.row), Some(issue.column))
    } match
      case Left(issue) => EventTableAssessment(None, Vector(issue))
      case Right(records) =>
        val issues = new EventIssueBuffer
        val header = records.head._2
        def error(code: EventIssueCode, message: String, row: Int, col: Option[Int] = None): Unit =
          issues.add(EventIssue(code, BidsIssueSeverity.Error, message, Some(row), col))
        header.zipWithIndex.foreach { (name, i) =>
          if name != name.trim then error(EventIssueCode.Header, "column name has surrounding whitespace", 1, Some(i + 1))
          if name.trim.isEmpty then error(EventIssueCode.Header, "column name is blank", 1, Some(i + 1))
          if header.take(i).contains(name) then error(EventIssueCode.Header, s"duplicate column '$name'", 1, Some(i + 1))
        }
        Vector("onset", "duration").zipWithIndex.foreach { (name, i) =>
          if !header.lift(i).contains(name) then error(EventIssueCode.Header, s"$name must be column ${i + 1}", 1, Some(i + 1))
        }
        val onsetIndex = header.indexOf("onset")
        val durationIndex = header.indexOf("duration")
        val responseIndex = header.indexOf("response_time")
        val onsets = Vector.newBuilder[Option[BigDecimal]]
        val durations = Vector.newBuilder[Option[BigDecimal]]
        val rows = Vector.newBuilder[Vector[Option[String]]]
        var previous: Option[BigDecimal] = None
        records.tail.foreach { (line, cells) =>
          if cells.size != header.size then
            error(EventIssueCode.Width, s"row has ${cells.size} cells; expected ${header.size}", line)
          cells.zipWithIndex.foreach { (cell, i) =>
            if cell.isEmpty then error(EventIssueCode.MissingValue, "empty cell; use n/a for unavailable values", line, Some(i + 1))
          }
          def numeric(index: Int): Option[BigDecimal] =
            cells.lift(index).filter(s => s.nonEmpty && s != "n/a").flatMap { token =>
              val parsed = number(token)
              if parsed.isEmpty then error(EventIssueCode.Number, "expected bounded decimal seconds or n/a", line, Some(index + 1))
              parsed
            }
          val onset = if onsetIndex < 0 then None else numeric(onsetIndex)
          val duration = if durationIndex < 0 then None else numeric(durationIndex)
          if responseIndex >= 0 then
            val _ = numeric(responseIndex)
          if duration.exists(_ < 0) then error(EventIssueCode.Duration, "duration must be nonnegative or n/a", line, Some(durationIndex + 1))
          if onset.exists(n => previous.exists(_ > n)) then
            issues.add(EventIssue(EventIssueCode.Order, BidsIssueSeverity.Warning, "known onsets are not sorted", Some(line), Some(onsetIndex + 1)))
          if onset.nonEmpty then previous = onset
          onsets += onset
          durations += duration
          rows += cells.map(s => Option.when(s != "n/a")(s))
        }
        val findings = issues.result()
        if findings.exists(_.severity == BidsIssueSeverity.Error) then EventTableAssessment(None, findings)
        else
          // Structure is checked above; this conversion preserves custom values and explicit n/a.
          BidsTable.fromRows(header, rows.result()) match
            case Left(error) => EventTableAssessment(None, Vector(EventIssue(EventIssueCode.Header, BidsIssueSeverity.Error, error.message)))
            case Right(table) => EventTableAssessment(Some(new CheckedEvents(table, onsets.result(), durations.result(),
              records.tail.map(_._1))), findings)


private[bids4s] final class EventIssueBuffer:
  private var issues = Vector.empty[EventIssue]
  def add(issue: EventIssue): Unit =
    if issues.size < CheckedEvents.MaxIssues - 1 then issues = issues :+ issue
    else if issues.size == CheckedEvents.MaxIssues - 1 then
      issues = issues :+ EventIssue(EventIssueCode.LimitExceeded, issue.severity, "further event findings omitted after diagnostic limit")
    else if issue.severity == BidsIssueSeverity.Error then
      issues = issues.updated(issues.size - 1, issues.last.copy(severity = BidsIssueSeverity.Error))
  def result(): Vector[EventIssue] = issues
