package bids4s

/** Strict portable TSV syntax. Permissive BidsTable readers retain their existing behavior. */
enum TsvIssueCode:
  case Syntax, Header, Width, MissingValue, LimitExceeded
final case class TsvIssue(code: TsvIssueCode, message: String, row: Int, column: Int)
final class CheckedTsv private (val table: BidsTable, val sourceRows: Vector[Int])

object CheckedTsv:
  val Version: String = "bids-quoted-tsv-v1"
  val MaxCharacters: Int = 4 * 1024 * 1024
  val MaxRows: Int = 100000
  val MaxColumns: Int = 256

  def parse(text: String): Either[TsvIssue, CheckedTsv] =
    records(text).flatMap { rows =>
      val header = rows.head._2
      val headerIssue = header.zipWithIndex.collectFirst {
        case (name, i) if name.isEmpty || name != name.trim || name.exists(_.isControl) || header.take(i).contains(name) =>
          TsvIssue(TsvIssueCode.Header, "columns must be nonblank, unique and free of surrounding whitespace/control characters", 1, i + 1)
      }
      val rowIssue = rows.tail.iterator.flatMap { (line, cells) =>
        if cells.size != header.size then Iterator.single(TsvIssue(TsvIssueCode.Width, "row width differs from header", line, 1))
        else cells.zipWithIndex.collect {
          case (cell, i) if cell.isEmpty => TsvIssue(TsvIssueCode.MissingValue, "empty cell; use n/a", line, i + 1)
        }.iterator
      }.take(1).toVector.headOption
      headerIssue.orElse(rowIssue) match
        case Some(issue) => Left(issue)
        case None => BidsTable.fromRows(header, rows.tail.map(_._2.map(s => Option.when(s != "n/a")(s))))
          .left.map(e => TsvIssue(TsvIssueCode.Header, e.message, 1, 1))
          .map(t => new CheckedTsv(t, rows.tail.map(_._1)))
    }

  /** Deterministic LF serialization; lexical cell values and n/a survive projection. */
  def render(table: BidsTable): String =
    def cell(value: String): String =
      if value.exists(c => c == '\t' || c == '\r' || c == '\n' || c == '"') then
        "\"" + value.replace("\"", "\"\"") + "\""
      else value
    (table.columns +: table.rows.map(_.map(_.getOrElse("n/a")))).map(_.map(cell).mkString("\t")).mkString("", "\n", "\n")

  /** RFC-style quoted TSV, including escaped quotes and embedded tabs/newlines. No whitespace fallback. */
  private[bids4s] def records(text: String): Either[TsvIssue, Vector[(Int, Vector[String])]] =
    def fail(code: TsvIssueCode, message: String, row: Int, col: Int) =
      Left(TsvIssue(code, message, row, col))
    if text.length > MaxCharacters then fail(TsvIssueCode.LimitExceeded, "table exceeds 4 MiB characters", 1, 1)
    else if text.isEmpty then fail(TsvIssueCode.Header, "table is empty", 1, 1)
    else
      val result = Vector.newBuilder[(Int, Vector[String])]
      var cells = Vector.empty[String]
      val cell = new StringBuilder
      var quoted = false
      var closed = false
      var i = if text.head == '\ufeff' then 1 else 0
      var line = 1
      var start = 1
      var count = 0
      var failure: Option[TsvIssue] = None
      def reject(code: TsvIssueCode, message: String): Unit =
        failure = Some(TsvIssue(code, message, line, cells.size + 1))
      def finishCell(): Unit =
        cells = cells :+ cell.result()
        cell.clear()
        closed = false
        if cells.size > MaxColumns then reject(TsvIssueCode.LimitExceeded, "table exceeds 256 columns")
      def finishRow(): Unit =
        finishCell()
        count += 1
        if count > MaxRows + 1 then reject(TsvIssueCode.LimitExceeded, "table exceeds 100000 rows")
        else result += start -> cells
        cells = Vector.empty
      while i < text.length && failure.isEmpty do
        val c = text(i)
        if c == '\u0000' then reject(TsvIssueCode.Syntax, "NUL is not supported in table text")
        else if quoted then
          if c == '"' then
            if i + 1 < text.length && text(i + 1) == '"' then
              cell.append('"')
              i += 1
            else
              quoted = false
              closed = true
          else
            cell.append(c)
            if c == '\n' then line += 1
        else if c == '\t' then finishCell()
        else if c == '\n' || (c == '\r' && i + 1 < text.length && text(i + 1) == '\n') then
          finishRow()
          if c == '\r' then i += 1
          line += 1
          start = line
        else if closed then reject(TsvIssueCode.Syntax, "unexpected character after closing quote")
        else if c == '"' then
          if cell.nonEmpty then reject(TsvIssueCode.Syntax, "quote inside an unquoted cell")
          else quoted = true
        else if c == '\r' then reject(TsvIssueCode.Syntax, "use LF or CRLF line endings")
        else cell.append(c)
        i += 1
      if failure.isEmpty && quoted then reject(TsvIssueCode.Syntax, "unterminated quoted cell")
      if failure.isEmpty && (cell.nonEmpty || cells.nonEmpty || closed) then finishRow()
      failure match
        case Some(issue) => Left(issue)
        case None =>
          val rows = result.result()
          if rows.isEmpty then fail(TsvIssueCode.Header, "table is empty", 1, 1) else Right(rows)
