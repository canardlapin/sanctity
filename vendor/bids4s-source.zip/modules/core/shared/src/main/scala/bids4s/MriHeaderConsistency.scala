package bids4s

enum MriHeaderIssueCode:
  case Dimensions, VoxelSize, Units, TransformCode, Quaternion, Sform, TransformUnavailable
  case RepetitionTimeMismatch, TemporalSpacing, TimingUnavailable

final case class MriHeaderIssue(code: MriHeaderIssueCode, field: String, message: String, isError: Boolean)

/** Structural MRI profile, separate from parsing and from scientific registration/qualification. */
object MriHeaderConsistency:
  val Version: String = "bids-mri-header-consistency-v1"
  val SupportedSuffixes: Set[String] = Set("T1w", "T2w", "bold", "dwi", "epi", "phasediff", "magnitude1", "magnitude2")
  val RepetitionTimeRelativeTolerance: Double = 1e-5
  val RepetitionTimeAbsoluteTolerance: Double = 1e-6

  def spatialUnit(header: NiftiHeaderFacts): String = (header.unitsCode & 7) match
    case 0 => "unknown"
    case 1 => "meter"
    case 2 => "millimeter"
    case 3 => "micrometer"
    case _ => "unsupported"

  def temporalUnit(header: NiftiHeaderFacts): String = (header.unitsCode & 56) match
    case 0 => "unknown"
    case 8 => "second"
    case 16 => "millisecond"
    case 24 => "microsecond"
    case 32 => "hertz"
    case 40 => "ppm"
    case 48 => "radian-per-second"
    case _ => "unsupported"

  def temporalSpacingSeconds(header: NiftiHeaderFacts): Option[Double] =
    val scale = (header.unitsCode & 56) match
      case 8 => Some(1.0)
      case 16 => Some(0.001)
      case 24 => Some(0.000001)
      case _ => None
    scale.filter(_ => header.dimensions.lift(3).exists(_ > 1)).map(_ * header.pixelDimensions(4)).filter(v => v.isFinite && v > 0)

  def check(header: NiftiHeaderFacts, suffix: String, metadata: JsonValue.Obj): Vector[MriHeaderIssue] =
    val issues = Vector.newBuilder[MriHeaderIssue]
    def issue(code: MriHeaderIssueCode, field: String, message: String, error: Boolean = true): Unit =
      val _ = issues += MriHeaderIssue(code, field, message, error)
    val rank = header.dimensions.size
    val static = Set("T1w", "T2w", "phasediff", "magnitude1", "magnitude2")(suffix)
    if rank < 3 || rank > 4 || (static && rank == 4 && header.dimensions(3) != 1) then
      issue(MriHeaderIssueCode.Dimensions, "dim", "profile requires three spatial dimensions; static images may have only a singleton fourth dimension")
    if header.pixelDimensions.slice(1, 4).exists(v => !v.isFinite || v <= 0) then
      issue(MriHeaderIssueCode.VoxelSize, "pixdim", "spatial voxel sizes must be finite and positive")
    if (header.unitsCode & ~63) != 0 || spatialUnit(header) == "unsupported" || temporalUnit(header) == "unsupported" then
      issue(MriHeaderIssueCode.Units, "xyzt_units", "unrecognized spatial/temporal unit encoding")
    else if spatialUnit(header) == "unknown" then
      issue(MriHeaderIssueCode.Units, "xyzt_units", "spatial units are unspecified", false)
    Vector("qform_code" -> header.qformCode, "sform_code" -> header.sformCode).foreach { (field, code) =>
      if code < 0 then issue(MriHeaderIssueCode.TransformCode, field, "negative transform code")
      else if code > 5 then issue(MriHeaderIssueCode.TransformCode, field, "transform code is outside this profile's vocabulary", false)
    }
    if header.qformCode == 0 && header.sformCode == 0 then
      issue(MriHeaderIssueCode.TransformUnavailable, "qform_code/sform_code", "neither transform is declared; orientation is unavailable", false)
    if header.qformCode > 0 then
      val sum = header.quaternion.map(v => v * v).sum
      if !header.quaternion.forall(_.isFinite) || !header.qoffset.forall(_.isFinite) || !sum.isFinite || sum > 1.000001 ||
          !Set(-1.0, 0.0, 1.0)(header.pixelDimensions.head) then
        issue(MriHeaderIssueCode.Quaternion, "qform", "nonfinite or invalid coded quaternion, offset or qfac")
    if header.sformCode > 0 then
      val rows = header.sformRows
      // Scale each row first so determinant testing does not overflow for finite coefficients.
      val scaled = rows.map { r =>
        val scale = r.take(3).map(math.abs).max
        r.take(3).map(_ / scale)
      }
      val a = scaled(0); val b = scaled(1); val c = scaled(2)
      val determinant = a(0) * (b(1) * c(2) - b(2) * c(1)) - a(1) * (b(0) * c(2) - b(2) * c(0)) + a(2) * (b(0) * c(1) - b(1) * c(0))
      if !rows.flatten.forall(_.isFinite) || !determinant.isFinite || determinant == 0 then
        issue(MriHeaderIssueCode.Sform, "sform", "coded sform must be finite and nonsingular")
    if suffix == "bold" && !metadata.fields.contains("VolumeTiming") then
      metadata.fields.get("RepetitionTime") match
        case Some(JsonValue.Num(tr)) if tr.isFinite && tr > 0 =>
          temporalSpacingSeconds(header) match
            case Some(spacing) if math.abs(spacing - tr) > math.max(RepetitionTimeAbsoluteTolerance, math.abs(tr) * RepetitionTimeRelativeTolerance) =>
              // A curation correction may intentionally supersede a stale header; keep the discrepancy visible.
              issue(MriHeaderIssueCode.RepetitionTimeMismatch, "RepetitionTime", "authored TR differs from header spacing converted to seconds", false)
            case Some(_) => ()
            case None if !header.dimensions.lift(3).exists(_ > 1) =>
              issue(MriHeaderIssueCode.TimingUnavailable, "dim[4]", "image has no multi-volume time axis for TR comparison", false)
            case None if Set(8, 16, 24)(header.unitsCode & 56) =>
              issue(MriHeaderIssueCode.TemporalSpacing, "pixdim[4]", "declared temporal spacing must be finite and positive")
            case None => issue(MriHeaderIssueCode.TimingUnavailable, "xyzt_units", "header has no supported time unit for TR comparison", false)
        case _ => () // Authored metadata validity is assessed by the metadata rules.
    issues.result()
