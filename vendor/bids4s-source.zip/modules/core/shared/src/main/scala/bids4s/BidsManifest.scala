package bids4s

final case class DerivativeRoot(root: BidsPath, pipeline: PipelineName)

final case class BidsFile(
    path: BidsPath,
    parsed: Option[BidsName],
    scope: BidsScope,
    pipeline: Option[PipelineName] = None,
    size: Option[Long] = None,
    context: BidsContext = BidsContext.Default
):
  def fileName: String = path.fileName
  def directory: String = path.parent.map(_.value).getOrElse("")
  def datatype: Option[String] = parsed.flatMap(_.datatype)
  def role: Option[BidsFileRole] =
    parsed.flatMap(context.registry.roleFor(_, scope))
  def entities: BidsEntities = parsed.map(_.entities).getOrElse(BidsEntities.Empty)
  def extension: String =
    parsed.map(_.extension).getOrElse {
      context.extensions.find(e => fileName.endsWith("." + e)).getOrElse("")
    }

  def matches(query: BidsQuery): Boolean =
    val scopeMatches =
      query.scope match
        case BidsScope.Raw => scope == BidsScope.Raw
        case BidsScope.Derivatives => scope == BidsScope.Derivatives
        case BidsScope.All => true

    val pipelineMatches =
      query.pipeline.forall(p => pipeline.exists(_.value == p.value))

    Matching.filenameMatches(fileName, query.filename) &&
      scopeMatches &&
      pipelineMatches &&
      query.filters.forall { filter =>
        filter.selection match
          case EntitySelection.Presence(EntityPresence.Present) =>
            entities.get(filter.key).isDefined
          case EntitySelection.Presence(EntityPresence.Absent) =>
            entities.get(filter.key).isEmpty
          case EntitySelection.Presence(EntityPresence.Optional) =>
            true
          case EntitySelection.Values(_) =>
            entities.get(filter.key) match
              case Some(value) => Matching.entityMatches(value, filter, query.matchMode)
              case None =>
                if query.requireEntity then false
                else if Matching.isWildcard(filter, query.matchMode) then true
                else !query.strict
      }

final class BidsManifest private (val files: Vector[BidsFile], val context: BidsContext):
  def copy(files: Vector[BidsFile] = this.files, context: BidsContext = this.context): BidsManifest =
    BidsManifest(files, context)
  override def equals(other: Any): Boolean = other match
    case m: BidsManifest => files == m.files && context == m.context
    case _ => false
  override def hashCode(): Int = (files, context).hashCode()

  private lazy val filesByExactEntity: Map[(EntityKey, String), Vector[BidsFile]] =
    files
      .flatMap { file =>
        file.entities.keys.map { key =>
          (key -> file.entities(key)) -> file
        }
      }
      .groupMap(_._1)(_._2)

  private lazy val filesByEntity: Map[EntityKey, Vector[BidsFile]] =
    files
      .flatMap { file =>
        file.entities.keys.map(_ -> file)
      }
      .groupMap(_._1)(_._2)

  private lazy val filesByCanonicalRun: Map[String, Vector[BidsFile]] =
    files
      .flatMap { file =>
        file.entities
          .get(EntityKey.Run)
          .map(value => Matching.canonicalExactValue(EntityKey.Run, value) -> file)
      }
      .groupMap(_._1)(_._2)

  def query(query: BidsQuery = BidsQuery.All): Vector[BidsFile] =
    exactCandidates(query)
      .getOrElse(files)
      .filter(_.matches(query))
      .sortBy(_.path.value)

  def paths(query: BidsQuery = BidsQuery.All): Vector[BidsPath] =
    this.query(query).map(_.path)

  def entityValues(
      key: EntityKey,
      scope: BidsScope = BidsScope.All,
      pipeline: Option[PipelineName] = None
  ): Vector[String] =
    filesByExactEntity.iterator
      .collect {
        case ((indexedKey, value), matchingFiles)
            if indexedKey == key && matchingFiles.exists(file => inScope(file, scope, pipeline)) =>
          value
      }
      .toVector
      .sorted

  private def exactCandidates(query: BidsQuery): Option[Vector[BidsFile]] =
    query.filters
      .flatMap { filter =>
        filter.selection match
          case EntitySelection.Presence(EntityPresence.Present) =>
            Some(filesByEntity.getOrElse(filter.key, Vector.empty))
          case EntitySelection.Values(_)
              if query.matchMode == MatchMode.Exact &&
                (query.strict || query.requireEntity) =>
            Some(
              filter.values
                .flatMap { value =>
                  if filter.key == EntityKey.Run then
                    filesByCanonicalRun.getOrElse(
                      Matching.canonicalExactValue(EntityKey.Run, value),
                      Vector.empty
                    )
                  else
                    filesByExactEntity.getOrElse(filter.key -> value, Vector.empty)
                }
                .distinct
            )
          case _ =>
            None
      }
      .minByOption(_.length)

  private def inScope(
      file: BidsFile,
      scope: BidsScope,
      pipeline: Option[PipelineName]
  ): Boolean =
    val scopeMatches =
      scope match
        case BidsScope.Raw         => file.scope == BidsScope.Raw
        case BidsScope.Derivatives => file.scope == BidsScope.Derivatives
        case BidsScope.All         => true
    val pipelineMatches =
      pipeline.forall(expected => file.pipeline.exists(_.value == expected.value))
    scopeMatches && pipelineMatches

object BidsManifest:
  def apply(files: Vector[BidsFile], context: BidsContext = BidsContext.Default): BidsManifest =
    new BidsManifest(files.map { f =>
      if f.context == context then f
      else f.copy(parsed = context.parsePath(f.path, f.scope).toOption, context = context)
    }, context)
  def unapply(manifest: BidsManifest): Some[Vector[BidsFile]] = Some(manifest.files)

  private val AuxiliaryNames: Set[String] =
    Set("dataset_description.json", "participants.tsv", "participants.json", "README", "CHANGES", "LICENSE", ".bidsignore")
  private val AuxiliarySuffixes: Vector[String] =
    Vector("_scans.tsv", "_scans.json", "_sessions.tsv", "_sessions.json", "_channels.tsv", "_electrodes.tsv", "_coordsystem.json")

  def fromRelativePaths(
      paths: IterableOnce[String],
      derivatives: Vector[DerivativeRoot] = Vector.empty,
      context: BidsContext = BidsContext.Default
  ): BidsManifest =
    val files =
      paths.iterator.toVector.distinct.map { rawPath =>
        val path = BidsPath(rawPath)
        val derivative = derivatives.find(d => path.startsWithPath(d.root))
        val scope = if derivative.isDefined then BidsScope.Derivatives else BidsScope.Raw
        val parsed = context.registry.parsePath(path, scope).toOption
        BidsFile(
          path = path,
          parsed = parsed,
          scope = scope,
          pipeline = derivative.map(_.pipeline),
          context = context
        )
      }
    BidsManifest(files, context)

  def fromRelativePathsChecked(
      paths: IterableOnce[String],
      derivatives: Vector[DerivativeRoot] = Vector.empty,
      context: BidsContext = BidsContext.Default
  ): BidsValidationReport[BidsManifest] =
    val files = Vector.newBuilder[BidsFile]
    val issues = Vector.newBuilder[BidsIssue]
    val seen = scala.collection.mutable.HashSet.empty[String]

    paths.iterator.foreach { rawPath =>
      BidsPath.relative(rawPath) match
        case Left(error) =>
          issues += BidsIssue.error(
            code = BidsIssueCode.InvalidPath,
            path = BidsPath.from(rawPath).toOption,
            field = Some("path"),
            message = error.message
          )
        case Right(path) if seen.add(path.value) =>
          val derivative = derivatives.find(d => path.startsWithPath(d.root))
          val scope = if derivative.isDefined then BidsScope.Derivatives else BidsScope.Raw
          context.registry.parsePath(path, scope) match
            case Right(parsed) =>
              files += BidsFile(
                path = path,
                parsed = Some(parsed),
                scope = scope,
                pipeline = derivative.map(_.pipeline),
                context = context
              )
            case Left(error) =>
              files += BidsFile(
                path = path,
                parsed = None,
                scope = scope,
                pipeline = derivative.map(_.pipeline),
                context = context
              )
              issues ++= rejectedPathIssues(path, scope, error, context)
        case Right(_) => ()
    }

    BidsValidationReport.from(BidsManifest(files.result(), context), issues.result())

  private def rejectedPathIssues(path: BidsPath, scope: BidsScope, registryError: BidsError, context: BidsContext): Vector[BidsIssue] =
    if isKnownAuxiliary(path) then Vector.empty
    else context.parseGeneric(path.fileName) match
      case Left(parseError) =>
        if looksLikeBidsCandidate(path, context) then
          Vector(BidsIssue.error(BidsIssueCode.InvalidName, Some(path), None, parseError.message))
        else
          Vector(BidsIssue.warning(
            BidsIssueCode.UnrecognizedFile,
            Some(path),
            None,
            s"file is not recognized as a registered BIDS file: ${parseError.message}"
          ))
      case Right(generic) =>
        if !looksLikeBidsCandidate(path, context) then
          Vector(BidsIssue.warning(
            BidsIssueCode.UnrecognizedFile,
            Some(path),
            None,
            s"file role '${generic.kind}.${generic.extension}' is not registered as BIDS data"
          ))
        else if isKnownRole(path, generic, scope, context) && isInheritedMetadataSidecar(path, generic, context) then
          Vector.empty
        else if isKnownRole(path, generic, scope, context) then
          detailedValidationIssues(path, generic, scope, context).getOrElse(
            Vector(BidsIssue.error(BidsIssueCode.InvalidName, Some(path), None, registryError.message))
          )
        else
          Vector(BidsIssue.warning(
            BidsIssueCode.UnsupportedFileRole,
            Some(path),
            None,
            s"BIDS-like file role '${generic.kind}.${generic.extension}' is not supported by the registered datatype specifications"
          ))

  private def looksLikeBidsCandidate(path: BidsPath, context: BidsContext): Boolean =
    val name = path.fileName
    !isKnownAuxiliary(path) &&
      (
        context.registry.datatypeFolder(path).nonEmpty ||
          name.startsWith("sub-") ||
          name.startsWith("ses-") ||
          (name.contains('_') && context.extensions.exists(extension => name.endsWith("." + extension)))
      )

  private def isKnownAuxiliary(path: BidsPath): Boolean =
    val name = path.fileName
    AuxiliaryNames(name) || AuxiliarySuffixes.exists(name.endsWith)

  private def isKnownRole(path: BidsPath, name: BidsName, scope: BidsScope, context: BidsContext): Boolean =
    val observedFolder = context.registry.datatypeFolder(path)
    candidateSpecs(observedFolder, scope, context).exists { spec =>
      spec.kinds.exists(kind => kind.name == name.kind && kind.extensions.contains(name.extension))
    }

  private def isInheritedMetadataSidecar(path: BidsPath, name: BidsName, context: BidsContext): Boolean =
    (name.extension == "json" || (name.kind == "dwi" && Set("bval", "bvec")(name.extension)) ||
      (name.kind == "events" && name.extension == "tsv")) && context.registry.datatypeFolder(path).isEmpty

  private def detailedValidationIssues(
      path: BidsPath,
      name: BidsName,
      scope: BidsScope,
      context: BidsContext
  ): Option[Vector[BidsIssue]] =
    val observedFolder = context.registry.datatypeFolder(path)
    candidateSpecs(observedFolder, scope, context)
      .filter(_.kinds.exists(kind => kind.name == name.kind && kind.extensions.contains(name.extension)))
      .flatMap { spec =>
        spec.validateAll(name).left.toOption.map(report => spec.name -> report)
      }
      .sortBy { case (specName, report) => (report.issues.length, specName) }
      .headOption
      .map { case (_, report) => report.issues.map(issueAt(path, _)) }

  private def issueAt(path: BidsPath, issue: BidsIssue): BidsIssue =
    issue.severity match
      case BidsIssueSeverity.Error =>
        BidsIssue.error(issue.code, Some(path), issue.field, issue.message)
      case BidsIssueSeverity.Warning =>
        BidsIssue.warning(issue.code, Some(path), issue.field, issue.message)

  private def candidateSpecs(observedFolder: Option[String], scope: BidsScope, context: BidsContext): Vector[BidsDatatypeSpec] =
    context.registry.specs.filter { spec =>
      val folderMatches = observedFolder.forall(_ == spec.folder)
      val scopeMatches =
        scope match
          case BidsScope.All => true
          case BidsScope.Raw => spec.scope == DatatypeScope.Raw || spec.scope == DatatypeScope.Both
          case BidsScope.Derivatives => spec.scope == DatatypeScope.Derivative || spec.scope == DatatypeScope.Both
      folderMatches && scopeMatches
    }
