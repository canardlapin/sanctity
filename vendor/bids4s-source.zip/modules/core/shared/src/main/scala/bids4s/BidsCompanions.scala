package bids4s

/** Non-JSON companions supported by this MRI selection profile. Contents are not validated here. */
enum BidsCompanionKind(val suffix: String, val extension: String, val targetSuffix: String):
  case Bval extends BidsCompanionKind("dwi", "bval", "dwi")
  case Bvec extends BidsCompanionKind("dwi", "bvec", "dwi")
  case Events extends BidsCompanionKind("events", "tsv", "bold")

final case class BidsCompanionCandidate(path: BidsPath, matchedEntities: Map[String, String])

enum BidsCompanionOutcome:
  case Selected(candidate: BidsCompanionCandidate)
  case Missing
  case Ambiguous(candidates: Vector[BidsPath])
  case Unsupported(detail: String)
  case LimitExceeded(detail: String)

/** Applicable candidates are ordered from dataset root to target directory.
  * Selection never merges table/gradient contents or breaks a same-level tie.
  */
final case class BidsCompanionResolution(
    target: BidsPath, kind: BidsCompanionKind, datasetRoot: Option[BidsPath],
    applicable: Vector[BidsCompanionCandidate], outcome: BidsCompanionOutcome
)

/** Reusable directory/role index. No filesystem reads or nearest-file heuristic. */
final class BidsCompanionResolver private (
    inventory: Set[BidsPath],
    index: Map[(String, String, String), Vector[(BidsPath, BidsName)]],
    roots: Vector[BidsPath],
    candidateLimit: Int,
    val context: BidsContext
):
  def resolve(path: BidsPath, kind: BidsCompanionKind): Either[BidsError, BidsCompanionResolution] =
    for
      target <- BidsPath.relative(path.value)
      _ <- Either.cond(target == path && !path.value.contains('\\') && !path.value.exists(_.isControl),
        (), BidsError.InvalidPath(path.value, "companion target must be canonical"))
      name <- context.parseGeneric(target.fileName)
    yield
      val root = roots.filter(target.startsWithPath).maxByOption(_.value.length)
      def result(outcome: BidsCompanionOutcome, candidates: Vector[BidsCompanionCandidate] = Vector.empty) =
        BidsCompanionResolution(target, kind, root, candidates, outcome)
      if !inventory(target) then result(BidsCompanionOutcome.Unsupported("target is absent from the inventory"))
      else if name.kind != kind.targetSuffix || !Set("nii", "nii.gz")(name.extension) then
        result(BidsCompanionOutcome.Unsupported("this profile resolves gradients for DWI and events for BOLD NIfTI"))
      else if kind == BidsCompanionKind.Events && name.entities.get(EntityKey.Task).isEmpty then
        result(BidsCompanionOutcome.Unsupported("BOLD event selection requires a task entity"))
      else
        val directory = target.parent.map(_.value).getOrElse("")
        val parts = directory.split('/').toVector.filter(_.nonEmpty)
        val ancestors = Vector("") ++ parts.indices.map(i => parts.take(i + 1).mkString("/"))
        val local = root.fold(ancestors)(r => ancestors.dropWhile(_ != r.value))
        // Bound examined candidates, including inapplicable ones, before materializing evidence.
        val count = local.map(d => index.getOrElse((d, kind.suffix, kind.extension), Vector.empty).size.toLong).sum
        if count > candidateLimit then result(BidsCompanionOutcome.LimitExceeded("companion candidate budget exceeded"))
        else
          val levels = local.map { d =>
            index.getOrElse((d, kind.suffix, kind.extension), Vector.empty).collect {
              case (p, n) if n.entities.keys.forall(k =>
                  name.entities.get(k).exists(v => Matching.canonicalExactValue(k, v) == Matching.canonicalExactValue(k, n.entities(k)))) =>
                BidsCompanionCandidate(p, n.entities.values.map((k, v) => k.short -> v).toMap)
            }
          }
          val applicable = levels.flatten
          levels.find(_.size > 1) match
            case Some(ambiguous) => result(BidsCompanionOutcome.Ambiguous(ambiguous.map(_.path)), applicable)
            case None => applicable.lastOption match
              case Some(selected) => result(BidsCompanionOutcome.Selected(selected), applicable)
              case None => result(BidsCompanionOutcome.Missing)

object BidsCompanionResolver:
  val Version: String = "bids-mri-companions-v1"
  val CandidateLimit: Int = 10000

  def apply(manifest: BidsManifest, derivatives: Vector[DerivativeRoot] = Vector.empty,
      candidateLimit: Int = CandidateLimit): BidsCompanionResolver =
    val roles = BidsCompanionKind.values.map(k => k.suffix -> k.extension).toSet
    val files = manifest.files.distinctBy(_.path)
    val index = files.flatMap { f =>
      manifest.context.parseGeneric(f.fileName).toOption.filter(n => roles(n.kind -> n.extension))
        .map(n => (f.directory, n.kind, n.extension) -> (f.path -> n))
    }.sortBy(_._2._1.value).groupMap(_._1)(_._2)
    val roots = (derivatives.map(_.root) ++ files.filter(_.fileName == "dataset_description.json").flatMap(_.path.parent))
      .distinct.sortBy(_.value)
    new BidsCompanionResolver(files.map(_.path).toSet, index, roots, candidateLimit.max(0), manifest.context)
