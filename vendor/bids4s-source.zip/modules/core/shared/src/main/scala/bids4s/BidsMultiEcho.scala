package bids4s

enum BidsMultiEchoIssueCode:
  case Context, Placement, UnsupportedEntities, MissingMember, AmbiguousMember, MixedRepresentation, Metadata, EchoTimes, Timing, LimitExceeded
final case class BidsMultiEchoIssue(code: BidsMultiEchoIssueCode, path: BidsPath, message: String)
final case class BidsMultiEchoGroup(members: Vector[BidsPath], datasetRoot: Option[BidsPath],
    entities: Map[String, String], evidence: Vector[BidsAssociationEvidence])
final case class BidsMultiEchoReport(groups: Vector[BidsMultiEchoGroup], issues: Vector[BidsMultiEchoIssue])

/** Same-directory magnitude BOLD families. Completeness refers only to the supplied inventory. */
object BidsMultiEchoResolver:
  val Version: String = "bids-multiecho-v1"
  val MaxMembers: Int = 16
  val TimingFields: Set[String] = EventTiming.Fields ++ Set("TaskName", "SliceTiming", "PhaseEncodingDirection", "TotalReadoutTime")
  private val allowed = Set("sub", "ses", "task", "acq", "ce", "rec", "dir", "run", "echo")

  def fromResolved(manifest: BidsManifest, metadata: Map[BidsPath, BidsMetadataResolution]): BidsMultiEchoReport =
    def failed(code: BidsMultiEchoIssueCode, path: BidsPath, message: String) =
      BidsMultiEchoReport(Vector.empty, Vector(BidsMultiEchoIssue(code, path, message)))
    if metadata.exists((p, m) => p != m.target || m.context != manifest.context) then
      return failed(BidsMultiEchoIssueCode.Context, BidsPath("dataset_description.json"), "metadata target or context mismatch")
    def entities(n: BidsName) = n.entities.values.map((k, v) => k.short -> v).toMap
    def normalized(n: BidsName) = entities(n).removed("echo").map { (k, v) =>
      val value = if k == "run" && v.forall(_.isDigit) then v.dropWhile(_ == '0') else v
      k -> (if value.isEmpty then "0" else value)
    }
    val images = manifest.files.flatMap(f => manifest.context.parseGeneric(f.fileName).toOption
      .filter(n => n.kind == "bold" && Set("nii", "nii.gz")(n.extension)).map(n => f.path -> n)).distinct.sortBy(_._1.value)
    if images.size > 10000 then return failed(BidsMultiEchoIssueCode.LimitExceeded, images.head._1, "BOLD inventory exceeds 10000 images")
    val groups = Vector.newBuilder[BidsMultiEchoGroup]
    val issues = Vector.newBuilder[BidsMultiEchoIssue]
    images.groupBy((p, n) => (p.parent, normalized(n))).toVector.sortBy(_._2.head._1.value).foreach { (_, family) =>
      if family.exists((_, n) => entities(n).contains("echo")) then
        val anchor = family.head._1
        var valid = true
        def issue(code: BidsMultiEchoIssueCode, message: String): Unit =
          valid = false
          val _ = issues += BidsMultiEchoIssue(code, anchor, message)
        if family.size > MaxMembers then issue(BidsMultiEchoIssueCode.LimitExceeded, "echo family exceeds 16 images")
        else
          if family.size < 2 then issue(BidsMultiEchoIssueCode.MissingMember, "bounded family profile requires at least two recorded echoes")
          if family.exists((_, n) => !entities(n).keySet.subsetOf(allowed)) then
            issue(BidsMultiEchoIssueCode.UnsupportedEntities, "unsupported BOLD collection entities")
          val indexed = family.flatMap { (p, n) =>
            entities(n).get("echo").filter(v => v.nonEmpty && v.length <= 32 && v.forall(_.isDigit)).map(v => (BigInt(v), p))
          }.sortBy((index, p) => (index, p.value))
          if indexed.size != family.size then issue(BidsMultiEchoIssueCode.MixedRepresentation, "all family members need bounded numeric echo indices")
          if indexed.map(_._1).distinct.size != indexed.size then issue(BidsMultiEchoIssueCode.AmbiguousMember, "duplicate numeric echo index")
          val resolved = indexed.flatMap((_, p) => metadata.get(p))
          if resolved.size != family.size || resolved.map(_.datasetRoot).distinct.size != 1 then
            issue(BidsMultiEchoIssueCode.Metadata, "all echo metadata must resolve in one dataset")
          resolved.foreach { m =>
            val keys = normalized(family.head._2)
            val local = m.datasetRoot.fold(m.target.value)(r => m.target.value.stripPrefix(r.value + "/"))
            val expected = keys.get("sub").map(s => "sub-" + s + keys.get("ses").fold("")(v => "/ses-" + v) + "/func")
            if !expected.contains(local.split('/').dropRight(1).mkString("/")) then issue(BidsMultiEchoIssueCode.Placement, "echo placement must match participant/session func directory")
          }
          val times = resolved.flatMap(_.metadata.fields.get("EchoTime").collect { case JsonValue.Num(n) if n.isFinite && n > 0 => n })
          if times.size != family.size || times.sliding(2).exists(v => v.size == 2 && v(0) >= v(1)) then
            issue(BidsMultiEchoIssueCode.EchoTimes, "profile requires positive finite EchoTime increasing with numeric echo index")
          if resolved.map(_.metadata.fields.filter((k, _) => TimingFields(k))).distinct.size > 1 then
            issue(BidsMultiEchoIssueCode.Timing, "family members disagree in authored timing/task/acquisition fields")
          if valid then
            val evidence = resolved.flatMap(m => (TimingFields + "EchoTime").toVector.sorted.flatMap(k =>
              m.origins.get(k).map(d => BidsAssociationEvidence(m.target, d, k))))
            val _ = groups += BidsMultiEchoGroup(indexed.map(_._2), resolved.head.datasetRoot, normalized(family.head._2), evidence)
    }
    BidsMultiEchoReport(groups.result(), issues.result().distinct.sortBy(i => (i.path.value, i.code.ordinal, i.message)))
