package bids4s

/** Effective scalar scaling. Undefined/zero slope means identity; active scaling must be finite. */
final class NiftiScaling private (val slope: Double, val intercept: Double, val active: Boolean)

object NiftiScaling:
  val Version = "nifti-scalar-scaling-v1"
  def from(slope: Double, intercept: Double): Either[DwiIssue, NiftiScaling] =
    if slope == 0 || slope.isNaN then Right(new NiftiScaling(1, 0, false))
    else if !slope.isFinite || !intercept.isFinite then
      Left(DwiIssue(DwiIssueCode.Header, "image", "active NIfTI scaling requires finite slope and intercept"))
    else Right(new NiftiScaling(slope, intercept, true))

  def parse(bytes: Array[Byte]): Either[DwiIssue, NiftiScaling] = NiftiHeaderFacts.parse(bytes).flatMap { h =>
    val width = if h.version == 1 then 4 else 8
    def real(offset: Int): Double =
      val bits = (0 until width).foldLeft(0L) { (n, i) =>
        val index = if h.byteOrder == NiftiByteOrder.LittleEndian then offset + i else offset + width - 1 - i
        n | ((bytes(index).toLong & 255L) << (8 * i))
      }
      if width == 4 then java.lang.Float.intBitsToFloat(bits.toInt).toDouble else java.lang.Double.longBitsToDouble(bits)
    from(real(if h.version == 1 then 112 else 176), real(if h.version == 1 then 116 else 184))
  }
