package bids4s

import munit.FunSuite

final class CheckedTsvSuite extends FunSuite:
  test("quoted TSV preserves lexical numbers, Unicode, explicit missingness and physical rows") {
    val text = "\ufeffid\tvalue\tnote\r\na\t9007199254740993.0001\t\"line1\nline2\"\r\nb\tn/a\tNA\r\nc\t-0.000\télève\r\n"
    val parsed = CheckedTsv.parse(text).toOption.get
    assertEquals(parsed.sourceRows, Vector(2, 4, 5))
    assertEquals(parsed.table.rows(0)(1), Some("9007199254740993.0001"))
    assertEquals(parsed.table.rows(1), Vector(Some("b"), None, Some("NA")))
    assertEquals(CheckedTsv.parse(CheckedTsv.render(parsed.table)).toOption.get.table, parsed.table)
  }
  test("column projection quotes tabs, newlines and quotes without touching lexical values") {
    val parsed = CheckedTsv.parse("id\tnote\tprivate\na\t\"a\tb\"\tsecret\nb\t\"say \"\"yes\"\"\"\thidden\n").toOption.get
    val projected = parsed.table.select(Vector("id", "note")).toOption.get
    val rendered = CheckedTsv.render(projected)
    assertEquals(rendered, "id\tnote\na\t\"a\tb\"\nb\t\"say \"\"yes\"\"\"\n")
    assertEquals(CheckedTsv.parse(rendered).toOption.get.table, projected)
  }
  test("strict table parsing rejects duplicate/blank headers, ragged rows and empty cells") {
    Vector("id\tid\na\tb\n", "id\t\na\tb\n", " id\nx\n", "id\tx\na\n", "id\tx\na\t\n", "id value\na b\nextra\tx\n")
      .foreach(t => assert(CheckedTsv.parse(t).isLeft, t))
    assertEquals(CheckedTsv.parse("id\nx\n").toOption.get.table.nrows, 1)
    assertEquals(CheckedTsv.parse("id\n").toOption.get.table.nrows, 0)
  }
  test("malformed quotes and control separators return typed positions") {
    Vector("id\n\"open", "id\na\"b\n", "id\n\"a\"x\n", "id\na\rb", "id\na\u0000b")
      .foreach(t => assertEquals(CheckedTsv.parse(t).left.toOption.get.code, TsvIssueCode.Syntax))
    assertEquals(CheckedTsv.parse("id\n\"a\nb\"x\n").left.toOption.get.row, 3)
  }
  test("strict table size, row and column limits are enforced") {
    Vector("id\n" + ("x" * CheckedTsv.MaxCharacters), "id\n" + ("x\n" * (CheckedTsv.MaxRows + 1)),
      (0 to CheckedTsv.MaxColumns).map(i => s"c$i").mkString("\t") + "\n")
      .foreach(t => assertEquals(CheckedTsv.parse(t).left.toOption.get.code, TsvIssueCode.LimitExceeded))
  }
