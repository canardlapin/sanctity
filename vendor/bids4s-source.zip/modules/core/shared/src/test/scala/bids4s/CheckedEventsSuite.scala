package bids4s

class CheckedEventsSuite extends munit.FunSuite:
  private def assessed(text: String): CheckedEvents =
    val result = CheckedEvents.assess(text)
    result.table.getOrElse(fail(result.issues.toString))
  private def codes(text: String) = CheckedEvents.assess(text).issues.map(_.code)

  test("negative onsets, overlaps, impulses, n/a and negative response times are legal"):
    val e = assessed("onset\tduration\tresponse_time\ttrial_type\n-1\t2\t-.1\tpractice\n0\t0\tn/a\tgo\nn/a\tn/a\t1e-3\tNA\n")
    assertEquals(e.onsets, Vector(Some(BigDecimal(-1)), Some(BigDecimal(0)), None))
    assertEquals(e.durations, Vector(Some(BigDecimal(2)), Some(BigDecimal(0)), None))
    assertEquals(e.table.rows.last.last, Some("NA"))

  test("decimal seconds are exact even beyond binary and decimal128 precision"):
    val token = "9007199254740993.123456789012345678901234567890123456789"
    val e = assessed(s"onset\tduration\n$token\t1e-30\n")
    assertEquals(e.onsets.head.get.bigDecimal.toPlainString, token)
    assertEquals(e.durations.head.get, BigDecimal("1e-30"))

  test("quoted tabs, escaped quotes, unicode and multiline custom values retain their content"):
    val e = assessed("\ufeffonset\tduration\tnote\r\n0\t1\t\"a\tb \"\"quoted\"\" 中国\r\nnext\"\r\n2\t0\tend\r\n")
    assertEquals(e.table.rows.head.last, Some("a\tb \"quoted\" 中国\r\nnext"))
    assertEquals(e.sourceRows, Vector(2, 4))

  test("required columns must be first and second and headers cannot be blank or duplicated"):
    Vector("duration\tonset\n0\t1", "onset\tnote\n0\t1", "onset\tduration\tonset\n0\t1\t2",
      "onset\tduration\t\n0\t1\tn/a", "onset\tduration\t note\n0\t1\tx").foreach { s =>
      assert(codes(s).contains(EventIssueCode.Header))
    }

  test("strict TSV has no whitespace delimiter or blank-line fallback"):
    assert(codes("onset duration\n0 1").contains(EventIssueCode.Header))
    assert(codes("onset\tduration\n\n0\t1").contains(EventIssueCode.Width))
    assert(codes("onset\tduration\n0\t1\textra").contains(EventIssueCode.Width))
    assert(CheckedEvents.assess("onset duration\n0 1").table.isEmpty)
    assert(BidsEvents.readEventsTable("onset duration\n0 1").isRight)

  test("missing values are explicit and numeric spellings are strict"):
    Vector("", "NA", "N/A", "NaN", "Infinity", "0x1p0", "1,2", " 1", "1e309", "1e-9999").foreach { token =>
      val result = CheckedEvents.assess(s"onset\tduration\n0\t$token\n")
      assert(result.table.isEmpty, token)
      assert(result.issues.exists(i => i.row.contains(2) && i.column.contains(2)), token)
    }

  test("independent row and column errors accumulate deterministically"):
    val result = CheckedEvents.assess("onset\tduration\tresponse_time\nwrong\t-2\tNaN\n1\tbad\t0\n")
    assertEquals(result.issues.map(i => (i.code, i.row, i.column)), Vector(
      (EventIssueCode.Number, Some(2), Some(1)), (EventIssueCode.Number, Some(2), Some(3)),
      (EventIssueCode.Duration, Some(2), Some(2)), (EventIssueCode.Number, Some(3), Some(2))))
    assert(result.table.isEmpty)

  test("unsorted known onsets warn without reordering or blocking"):
    val result = CheckedEvents.assess("onset\tduration\n2\t0\nn/a\t1\n1\t0\n")
    assertEquals(result.issues.map(_.severity), Vector(BidsIssueSeverity.Warning))
    assertEquals(result.table.get.onsets, Vector(Some(BigDecimal(2)), None, Some(BigDecimal(1))))

  test("malformed quoting is a syntax error"):
    Vector("0\t1\t\"unterminated", "0\t1\t\"ok\"junk", "0\t1\ta\"b", "0\t1\ta\u0000b").foreach { row =>
      assertEquals(codes("onset\tduration\tnote\n" + row), Vector(EventIssueCode.Syntax))
    }

  test("header-only tables and a final newline are represented without a spurious row"):
    assertEquals(assessed("onset\tduration\n").table.nrows, 0)
    assertEquals(assessed("onset\tduration\n0\t1\n").table.nrows, 1)

  test("character, row and column limits bound work"):
    assertEquals(codes("x" * (CheckedEvents.MaxCharacters + 1)), Vector(EventIssueCode.LimitExceeded))
    assertEquals(codes("onset\tduration\n" + "0\t0\n" * (CheckedEvents.MaxRows + 1)), Vector(EventIssueCode.LimitExceeded))
    assertEquals(codes(Vector.fill(CheckedEvents.MaxColumns + 1)("x").mkString("\t")), Vector(EventIssueCode.LimitExceeded))

  test("diagnostic limits preserve warning-only status but never hide a later error"):
    val rows = (100 to 1 by -1).map(n => s"$n\t0").mkString("\n")
    val warnings = CheckedEvents.assess("onset\tduration\n" + rows)
    assertEquals(warnings.issues.size, CheckedEvents.MaxIssues)
    assert(warnings.table.nonEmpty)
    assert(warnings.issues.forall(_.severity == BidsIssueSeverity.Warning))
    val error = CheckedEvents.assess("onset\tduration\n" + rows + "\n0\t-1")
    assertEquals(error.issues.size, CheckedEvents.MaxIssues)
    assert(error.table.isEmpty)
    assertEquals(error.issues.last.severity, BidsIssueSeverity.Error)

class EventTimingSuite extends munit.FunSuite:
  private def n(v: Double): JsonValue = JsonValue.Num(v)
  private def arr(vs: Double*): JsonValue = JsonValue.Arr(vs.toVector.map(n))
  private def regular = EventTiming.assess(Some(3), Map("RepetitionTime" -> n(2)))
  private def events(s: String) = CheckedEvents.assess("onset\tduration\n" + s).table.get

  test("regular timing records a nominal window from stored volumes"):
    val r = regular
    assertEquals(r.issues, Vector.empty)
    assertEquals(r.context.mode, EventTimingMode.Regular)
    assertEquals(r.context.lastVolumeOnset, Some(BigDecimal(4)))
    assertEquals(r.context.comparisonEnd, Some(BigDecimal(6)))

  test("nonuniform timing retains its own model and normalizes to the first stored volume"):
    val r = EventTiming.assess(Some(3), Map("VolumeTiming" -> arr(10, 11.5, 14), "FrameAcquisitionDuration" -> n(.25)))
    assertEquals(r.context.mode, EventTimingMode.Variable)
    assertEquals(r.context.originShift, Some(BigDecimal(10)))
    assertEquals(r.context.lastVolumeOnset, Some(BigDecimal(4)))
    assertEquals(r.context.comparisonEnd, Some(BigDecimal("4.25")))
    assertEquals(r.issues, Vector.empty)

  test("slice timing does not invent the final volume end"):
    val r = EventTiming.assess(Some(3), Map("VolumeTiming" -> arr(0, 1.5, 4), "SliceTiming" -> arr(0, .1)))
    assertEquals(r.context.mode, EventTimingMode.Variable)
    assertEquals(r.context.comparisonEnd, None)
    assertEquals(r.issues.map(_.code), Vector(EventIssueCode.TimingUnavailable))
    assertEquals(EventTiming.compare(events("100\t1"), r.context), Vector.empty)

  test("unknown metadata or header count is explicit and warning-only"):
    Vector(EventTiming.assess(Some(3), Map.empty), EventTiming.assess(None, Map("RepetitionTime" -> n(2)))).foreach { r =>
      assertEquals(r.context.mode, EventTimingMode.Unavailable)
      assert(r.issues.forall(_.severity == BidsIssueSeverity.Warning))
      assertEquals(r.context.comparisonEnd, None)
    }

  test("conflicting, negative, nonfinite and wrong-shaped timing metadata are errors"):
    Vector(
      Map("RepetitionTime" -> n(2), "VolumeTiming" -> arr(0, 2, 4)),
      Map("RepetitionTime" -> n(-2)),
      Map("RepetitionTime" -> n(Double.PositiveInfinity)),
      Map("RepetitionTime" -> JsonValue.Str("2")),
      Map("VolumeTiming" -> arr(0, -1, 2)),
      Map("VolumeTiming" -> arr(0, 1, 1)),
      Map("VolumeTiming" -> arr(0, 1, 2), "DelayTime" -> n(1)),
      Map("VolumeTiming" -> arr(0, 1, 2), "FrameAcquisitionDuration" -> n(0))
    ).foreach { fields =>
      val r = EventTiming.assess(Some(3), fields)
      assert(r.issues.exists(_.severity == BidsIssueSeverity.Error))
      assertEquals(r.context.mode, EventTimingMode.Unavailable)
    }

  test("volume timing length is checked against the image rather than a inferred median TR"):
    val r = EventTiming.assess(Some(3), Map("VolumeTiming" -> arr(0, 1), "FrameAcquisitionDuration" -> n(.5)))
    assert(r.issues.exists(_.code == EventIssueCode.VolumeCount))
    assertEquals(r.context.comparisonEnd, None)

  test("window exceedance warns but negative onsets, overlap and n/a do not fail"):
    val r = EventTiming.compare(events("-2\t3\n0\t3\n2\t4\n6\t0\n5\t2\nn/a\t100\n1\tn/a"), regular.context)
    assertEquals(r.map(_.row), Vector(Some(5), Some(6)))
    assert(r.forall(i => i.severity == BidsIssueSeverity.Warning && i.code == EventIssueCode.OutsideWindow))

  test("discarded volumes do not shift the event origin or inflate duration"):
    val r = EventTiming.assess(Some(3), Map("RepetitionTime" -> n(2), "NumberOfVolumesDiscardedByUser" -> n(10)))
    assertEquals(r.context.comparisonEnd, regular.context.comparisonEnd)
    assertEquals(r.context.originShift, Some(BigDecimal(0)))

  test("one stored volume can have one explicit onset"):
    val r = EventTiming.assess(Some(1), Map("VolumeTiming" -> arr(2), "FrameAcquisitionDuration" -> n(.5)))
    assertEquals(r.issues, Vector.empty)
    assertEquals(r.context.comparisonEnd, Some(BigDecimal(".5")))

  test("sidecar validation permits a single stored volume but rejects negative volume times"):
    val path = BidsPath("sub-01_task-test_bold.nii")
    assertEquals(BidsMetadataValidation.resolvedSidecar(path, JsonValue.Obj(Map("VolumeTiming" -> arr(0)))), Vector.empty)
    assert(BidsMetadataValidation.resolvedSidecar(path, JsonValue.Obj(Map("VolumeTiming" -> arr(-1, 1)))).nonEmpty)

  test("unbounded timing series are refused before interpretation"):
    val r = EventTiming.assess(Some(100001), Map("VolumeTiming" -> JsonValue.Arr(Vector.fill(100001)(n(0)))))
    assert(r.issues.exists(_.code == EventIssueCode.LimitExceeded))
