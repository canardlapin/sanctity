package bids4s

class AnalysisInputSuite extends munit.FunSuite:
  private val paths = Vector(1, 2, 3).map(i => s"sub-01/func/sub-01_task-test_run-01_echo-${i}_bold.nii")
  private def report(images: Vector[String] = paths, times: Vector[Double] = Vector(.01, .02, .03), tr: Vector[Double] = Vector(2, 2, 2)): BidsMultiEchoReport =
    val docs: Map[BidsPath, JsonValue.Obj] = images.zipWithIndex.map { (p, i) =>
      val obj: JsonValue.Obj = JsonValue.Obj(Map("EchoTime" -> JsonValue.Num(times(i % times.size)), "RepetitionTime" -> JsonValue.Num(tr(i % tr.size))))
      BidsPath(p.stripSuffix(".gz").stripSuffix(".nii") + ".json") -> obj
    }.toMap
    val manifest = BidsManifest.fromRelativePaths(images ++ docs.keys.map(_.value))
    val resolver = BidsMetadataResolver(manifest, docs)
    val metadata = images.flatMap(p => resolver.resolve(BidsPath(p)).toOption.map(BidsPath(p) -> _)).toMap
    BidsMultiEchoResolver.fromResolved(manifest, metadata)

  test("echo family uses numeric ordering and retains exact metadata origins"):
    val r = report()
    assertEquals(r.issues, Vector.empty)
    assertEquals(r.groups.head.members.map(_.value), paths)
    assertEquals(r.groups.head.evidence.count(_.field == "EchoTime"), 3)
    assertEquals(report(paths.reverse, Vector(.03, .02, .01)), r)
  test("run padding is equivalent and participant/session/acquisition labels remain lexical"):
    assertEquals(report(paths.updated(1, paths(1).replace("run-01", "run-1"))).issues, Vector.empty)
    val r = report(paths.updated(1, paths(1).replace("sub-01", "sub-1")))
    assert(r.issues.exists(_.code == BidsMultiEchoIssueCode.MissingMember))
    assertEquals(r.groups.head.members.size, 2)
  test("zero indices remain nonempty evidence values and do not require one-based contiguous echoes"):
    val zero = paths.map(_.replace("run-01", "run-00")).updated(1, paths(1).replace("run-01", "run-0"))
    val r = report(zero.map(_.replace("echo-1", "echo-0").replace("echo-3", "echo-9")))
    assertEquals(r.issues, Vector.empty)
    assertEquals(r.groups.head.entities("run"), "0")
    assertEquals(r.groups.head.members.size, 3)
  test("duplicate padded echo indices are ambiguous"):
    assert(report(paths.updated(2, paths(2).replace("echo-3", "echo-02"))).issues.exists(_.code == BidsMultiEchoIssueCode.AmbiguousMember))
  test("indexed and unindexed files never silently form a family"):
    assert(report(paths.updated(2, paths(2).replace("_echo-3", ""))).issues.exists(_.code == BidsMultiEchoIssueCode.MixedRepresentation))
  test("singleton and over-budget families are explicit"):
    assert(report(paths.take(1)).issues.exists(_.code == BidsMultiEchoIssueCode.MissingMember))
    assert(report((1 to 17).map(i => paths.head.replace("echo-1", s"echo-$i")).toVector).issues.exists(_.code == BidsMultiEchoIssueCode.LimitExceeded))
  test("invalid or unordered echo times and conflicting timing block groups"):
    Vector(Vector(.01, .01, .03), Vector(.02, .01, .03), Vector(.01, 0, .03), Vector(.01, Double.NaN, .03)).foreach { times =>
      assert(report(times = times).issues.exists(_.code == BidsMultiEchoIssueCode.EchoTimes))
      assertEquals(report(times = times).groups, Vector.empty)
    }
    assert(report(tr = Vector(2, 3, 2)).issues.exists(_.code == BidsMultiEchoIssueCode.Timing))
  test("unsupported collection entities and placement block groups"):
    assert(report(paths.map(_.replace("_bold", "_part-phase_bold"))).issues.exists(_.code == BidsMultiEchoIssueCode.UnsupportedEntities))
    assert(report(paths.map(_.replace("/func/", "/anat/"))).issues.exists(_.code == BidsMultiEchoIssueCode.Placement))
  test("missing resolution and mismatched context fail explicitly"):
    val manifest = BidsManifest.fromRelativePaths(paths)
    assert(BidsMultiEchoResolver.fromResolved(manifest, Map.empty).issues.exists(_.code == BidsMultiEchoIssueCode.Metadata))
    val other = BidsManifest.fromRelativePathsChecked(paths, context = BidsContext.from("other", BidsRegistry.Builtin).toOption.get).value
    val resolution = BidsMetadataResolver(other, Map.empty).resolve(BidsPath(paths.head)).toOption.get
    assertEquals(BidsMultiEchoResolver.fromResolved(manifest, Map(BidsPath(paths.head) -> resolution)).issues.head.code, BidsMultiEchoIssueCode.Context)
  test("ordinary single-echo data creates no family"):
    assertEquals(report(Vector(paths.head.replace("_echo-1", ""))).groups, Vector.empty)
    assertEquals(report(Vector(paths.head.replace("_echo-1", ""))).issues, Vector.empty)

  private def stimuli(cells: Vector[String], inventory: Set[BidsPath] = Set(BidsPath("stimuli/images/cat.png"), BidsPath("stimuli/é.wav"))) =
    BidsStimulusResolver.resolve("onset\tduration\tstim_file\n" + cells.map(v => s"0\t1\t$v\n").mkString, inventory)
  test("stimuli use local paths, preserve Unicode and deduplicate repeated assets"):
    val r = stimuli(Vector("images/cat.png", "n/a", "é.wav", "images/cat.png"))
    assertEquals(r.issues, Vector.empty)
    assertEquals(r.paths.map(_.value), Vector("stimuli/images/cat.png", "stimuli/é.wav"))
  test("unsafe or external stimulus references are rejected literally"):
    Vector("../x", "/x", "images/../x", "images//x", "./x", "https://x", "bids::x", "a\\x", "%2e%2e/x", "x?y", "x#y").foreach { value =>
      assertEquals(stimuli(Vector(value)).issues.head.code, BidsStimulusIssueCode.UnsafePath)
    }
  test("absent stimulus files and malformed tables report bounded issues"):
    assertEquals(stimuli(Vector("absent.txt")).issues.head.code, BidsStimulusIssueCode.MissingFile)
    assertEquals(stimuli(Vector("")).issues.head.code, BidsStimulusIssueCode.Table)
    assertEquals(stimuli(Vector.fill(100)("../x")).issues.size, 65)
  test("absent stim_file and missing cells imply no assets"):
    assertEquals(stimuli(Vector("n/a")).paths, Vector.empty)
    assertEquals(BidsStimulusResolver.resolve("onset\tduration\n0\t1\n", Set.empty).issues, Vector.empty)
