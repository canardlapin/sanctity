package bids4s

class NiftiScalingSuite extends munit.FunSuite:
  test("disabled scaling ignores intercept; active scaling is checked"):
    for slope <- Vector(0.0, -0.0, Double.NaN) do
      val s = NiftiScaling.from(slope, Double.PositiveInfinity).toOption.get
      assertEquals((s.slope, s.intercept, s.active), (1.0, 0.0, false))
    assert(NiftiScaling.from(Double.PositiveInfinity, 0).isLeft)
    assert(NiftiScaling.from(2, Double.NaN).isLeft)
    val s = NiftiScaling.from(-2, 10).toOption.get
    assertEquals((s.slope, s.intercept, s.active), (-2.0, 10.0, true))

  test("scaling fields decode in both NIfTI versions and byte orders"):
    for v <- Vector(1, 2); little <- Vector(true, false) do
      val bytes = NiftiTestBytes.header(v, little)
      def put(offset: Int, d: Double): Unit = NiftiTestBytes.integer(bytes, offset, if v == 1 then 4 else 8,
        if v == 1 then java.lang.Float.floatToRawIntBits(d.toFloat).toLong else java.lang.Double.doubleToRawLongBits(d), little)
      put(if v == 1 then 112 else 176, 2.5)
      put(if v == 1 then 116 else 184, -7)
      val s = NiftiScaling.parse(bytes).toOption.get
      assertEquals((s.slope, s.intercept), (2.5, -7.0))
    assert(NiftiScaling.parse(Array.emptyByteArray).isLeft)
