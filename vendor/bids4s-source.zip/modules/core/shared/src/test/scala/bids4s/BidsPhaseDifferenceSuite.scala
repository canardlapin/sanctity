package bids4s

class BidsPhaseDifferenceSuite extends munit.FunSuite:
  private val phase = "sub-01/ses-cal/fmap/sub-01_ses-cal_run-01_phasediff.nii.gz"
  private val mag1 = phase.replace("phasediff", "magnitude1")
  private val mag2 = phase.replace("phasediff", "magnitude2")
  private val echo: JsonValue.Obj = JsonValue.Obj(Map("EchoTime1" -> JsonValue.Num(0.006), "EchoTime2" -> JsonValue.Num(0.00746)))
  private def report(paths: Vector[String], obj: JsonValue.Obj = echo): BidsPhaseDifferenceReport =
    val sidecar = phase.stripSuffix(".nii.gz") + ".json"
    val manifest = BidsManifest.fromRelativePaths(paths :+ sidecar)
    val resolver = BidsMetadataResolver(manifest, Map(BidsPath(sidecar) -> obj))
    val resolved = paths.flatMap(p => resolver.resolve(BidsPath(p)).toOption.map(BidsPath(p) -> _)).toMap
    BidsPhaseDifferenceResolver.fromResolved(manifest, resolved)

  test("required magnitude1 and optional magnitude2 retain the precise family"):
    val one = report(Vector(phase, mag1))
    assertEquals(one.issues, Vector.empty)
    assertEquals(one.groups.head.magnitudes.map(_.value), Vector(mag1))
    val two = report(Vector(phase, mag1, mag2))
    assertEquals(two.issues, Vector.empty)
    assertEquals(two.groups.head.magnitudes.map(_.value), Vector(mag1, mag2))

  test("run padding is equivalent but subject and session labels are lexical"):
    assertEquals(report(Vector(phase, mag1.replace("run-01", "run-1"))).issues, Vector.empty)
    Vector(mag1.replace("sub-01", "sub-1"), mag1.replace("ses-cal", "ses-other"), mag1.replace("run-01", "run-2")).foreach { other =>
      assert(report(Vector(phase, other)).issues.exists(_.code == BidsPhaseDifferenceIssueCode.MissingMagnitude1))
    }

  test("duplicate compressed/uncompressed members are ambiguous, including optional magnitude2"):
    for role <- Vector(phase, mag1, mag2) do
      val r = report(Vector(phase, mag1, mag2, role.stripSuffix(".gz")))
      assert(r.issues.exists(_.code == BidsPhaseDifferenceIssueCode.AmbiguousMember))
      assertEquals(r.groups, Vector.empty)

  test("missing, nonpositive and reversed echo times fail explicitly"):
    Vector[JsonValue.Obj](JsonValue.Obj(Map.empty), JsonValue.Obj(Map("EchoTime1" -> JsonValue.Num(0), "EchoTime2" -> JsonValue.Num(1))),
      JsonValue.Obj(Map("EchoTime1" -> JsonValue.Num(2), "EchoTime2" -> JsonValue.Num(1)))).foreach { obj =>
      assert(report(Vector(phase, mag1), obj).issues.exists(_.code == BidsPhaseDifferenceIssueCode.EchoTimes))
    }

  test("nested dataset companions cannot fill a missing source family"):
    assert(report(Vector(phase, "derivatives/other/" + mag1, "derivatives/other/dataset_description.json"))
      .issues.exists(_.code == BidsPhaseDifferenceIssueCode.MissingMagnitude1))

  test("unrelated phase1/phase2 families are outside this resolver"):
    val r = report(Vector(phase.replace("phasediff", "phase1"), phase.replace("phasediff", "phase2"), mag1, mag2))
    assertEquals(r.groups, Vector.empty)
    assertEquals(r.issues, Vector.empty)

  test("missing resolved metadata and mixed contexts are rejected"):
    val m = BidsManifest.fromRelativePaths(Vector(phase, mag1))
    assert(BidsPhaseDifferenceResolver.fromResolved(m, Map.empty).issues.exists(_.code == BidsPhaseDifferenceIssueCode.Metadata))
    val custom = BidsContext.from("other", BidsRegistry.Builtin).toOption.get
    val other = BidsManifest.fromRelativePathsChecked(Vector(phase, mag1), context = custom).value
    val metadata = BidsMetadataResolver(other, Map.empty).resolve(BidsPath(phase)).toOption.get
    assertEquals(BidsPhaseDifferenceResolver.fromResolved(m, Map(BidsPath(phase) -> metadata)).issues.head.code, BidsPhaseDifferenceIssueCode.Context)

  test("families are deterministic under inventory and metadata order"):
    val paths = Vector(phase, mag1, mag2)
    assertEquals(report(paths), report(paths.reverse))
