package bids4s

class BidsContextSuite extends munit.FunSuite:
  private def value[A](e: Either[BidsError, A]): A = e.fold(error => fail(error.message), identity)
  private val spec = BidsDatatypeSpec("optical", "optical", DatatypeScope.Raw,
    Vector(EntityRule(EntityKey.Subject, required = true), EntityRule(EntityKey.Task, required = false)),
    Vector(value(BidsKind.from("light", Vector("opt.bin", "json")))))
  private val context = value(BidsContext.from("optical-v1", BidsRegistry.Builtin.withDatatype(spec), Some("1.10.0"), "Experimental optical names"))
  private val target = BidsPath("sub-01/optical/sub-01_task-rest_light.opt.bin")

  test("one context drives parsing, role classification, manifests, queries and metadata origins"):
    assert(BidsName.parse(target.fileName).isLeft)
    assertEquals(value(BidsName.parse(target.fileName, context)).extension, "opt.bin")
    val report = BidsManifest.fromRelativePathsChecked(Vector(target.value, "task-rest_light.json"), context = context)
    assertEquals(report.errors, Vector.empty)
    val manifest = report.value
    assertEquals(manifest.context, context)
    val hits = manifest.query(value(BidsQuery.exact(EntityKey.Subject, "01")))
    assertEquals(hits.map(_.path), Vector(target))
    assertEquals(hits.head.role.map(_.datatypeName), Some("optical"))
    val resolved = value(BidsMetadataResolver(manifest, Map(BidsPath("task-rest_light.json") ->
      JsonValue.Obj(Map("Wavelength" -> JsonValue.Num(750))))).resolve(target))
    assertEquals(resolved.context, context)
    assertEquals(resolved.metadata.fields("Wavelength"), JsonValue.Num(750))
    assertEquals(resolved.origins("Wavelength"), BidsPath("task-rest_light.json"))

  test("manifest copy and construction normalize file contexts without global registry fallback"):
    val custom = BidsManifest.fromRelativePaths(Vector(target.value), context = context)
    val default = custom.copy(context = BidsContext.Default)
    assertEquals(default.files.head.context, BidsContext.Default)
    assertEquals(default.files.head.role, None)
    assertEquals(default.query(value(BidsQuery.exact(EntityKey.Subject, "01"))), Vector.empty)
    assertEquals(BidsManifest(default.files, context).files.head.role.map(_.datatypeName), Some("optical"))
    assertEquals(custom.copy(), custom)

  test("descriptor includes ordered registry rules, patterns, extensions and declared coverage"):
    def changed(s: BidsDatatypeSpec): BidsContext = value(BidsContext.from("optical-v1", BidsRegistry.Builtin.withDatatype(s), Some("1.10.0"), "Experimental optical names"))
    val variants = Vector(spec.copy(folder = "optics"), spec.copy(scope = DatatypeScope.Both),
      spec.copy(entities = spec.entities.map(_.copy(pattern = Some("[0-9]+")))),
      spec.copy(entities = spec.entities.map(_.copy(required = false))),
      spec.copy(kinds = Vector(value(BidsKind.from("light", Vector("opt.bin", "json", "nii"))))))
    variants.foreach(s => assertNotEquals(changed(s).registryTokens, context.registryTokens))
    val reordered = value(BidsContext.from(context.name, BidsRegistry(context.registry.specs.reverse), context.specificationVersion, context.coverage))
    assertNotEquals(reordered.tokens, context.tokens)
    assertEquals(changed(spec), context)
    assertNotEquals(value(BidsContext.from("other", context.registry)).tokens, context.tokens)

  test("checked contexts reject duplicate specs, rules, malformed patterns and invalid versions"):
    val invalid = Vector(BidsRegistry(Vector(spec, spec)), BidsRegistry(Vector(spec.copy(entities = spec.entities ++ spec.entities))),
      BidsRegistry(Vector(spec.copy(entities = Vector(EntityRule(EntityKey.Subject, true, Some("[")))))))
    invalid.foreach(r => assert(BidsContext.from("invalid", r).isLeft))
    assert(BidsContext.from("", context.registry).isLeft)
    assert(BidsContext.from("invalid", context.registry, Some("latest")).isLeft)
    assert(BidsContext.from("invalid", BidsRegistry(Vector.empty)).isLeft)

  test("relationship batch seam refuses metadata resolved under another context"):
    val paths = Vector("sub-01/func/sub-01_task-rest_bold.nii")
    val manifest = BidsManifest.fromRelativePaths(paths)
    val other = BidsManifest.fromRelativePaths(paths, context = context)
    val metadata = BidsMetadataResolver(other, Map.empty)
    assert(BidsFieldmapResolver.resolve(manifest, metadata).issues.exists(_.isError))
    val resolved = value(metadata.resolve(BidsPath(paths.head)))
    assert(BidsFieldmapResolver.fromResolved(manifest, Map(resolved.target -> resolved)).issues.exists(_.isError))

  test("default convenience constructors agree with explicit default context"):
    val paths = Vector("sub-01/anat/sub-01_T1w.nii.gz", "sub-01/func/sub-01_task-rest_bold.nii.gz")
    assertEquals(BidsManifest.fromRelativePathsChecked(paths), BidsManifest.fromRelativePathsChecked(paths, context = BidsContext.Default))
    paths.foreach(p => assertEquals(BidsName.parse(BidsPath(p).fileName), BidsName.parse(BidsPath(p).fileName, BidsContext.Default)))
