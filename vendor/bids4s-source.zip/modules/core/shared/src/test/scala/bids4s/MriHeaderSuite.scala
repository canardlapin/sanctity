package bids4s

class MriHeaderSuite extends munit.FunSuite:
  private def real(bytes: Array[Byte], version: Int, offset: Int, value: Double, little: Boolean): Unit =
    NiftiTestBytes.integer(bytes, offset, if version == 1 then 4 else 8,
      if version == 1 then java.lang.Float.floatToRawIntBits(value.toFloat).toLong else java.lang.Double.doubleToRawLongBits(value), little)
  private def fixture(version: Int = 1, little: Boolean = true): Array[Byte] =
    val b = NiftiTestBytes.header(version, little)
    (0 to 4).foreach(i => real(b, version, (if version == 1 then 76 else 104) + i * (if version == 1 then 4 else 8), if i == 4 then 2000 else 2, little))
    real(b, version, if version == 1 then 76 else 104, -1, little)
    NiftiTestBytes.integer(b, if version == 1 then 123 else 500, if version == 1 then 1 else 4, 18, little)
    NiftiTestBytes.integer(b, if version == 1 then 252 else 344, if version == 1 then 2 else 4, 1, little)
    NiftiTestBytes.integer(b, if version == 1 then 254 else 348, if version == 1 then 2 else 4, 2, little)
    real(b, version, if version == 1 then 268 else 376, 11, little)
    (0 to 2).foreach(i => real(b, version, (if version == 1 then 280 else 400) + i * 5 * (if version == 1 then 4 else 8), 2, little))
    b
  private def parsed(b: Array[Byte]) = NiftiHeaderFacts.parse(b).toOption.get
  private val metadata: JsonValue.Obj = JsonValue.Obj(Map("RepetitionTime" -> JsonValue.Num(2)))
  private def check(b: Array[Byte], fields: JsonValue.Obj = metadata, suffix: String = "bold") = MriHeaderConsistency.check(parsed(b), suffix, fields)

  test("both NIfTI versions and byte orders preserve units, spacings and independent coded transforms"):
    for v <- Vector(1, 2); little <- Vector(true, false) do
      val h = parsed(fixture(v, little))
      assertEquals(h.pixelDimensions.take(5), Vector(-1.0, 2.0, 2.0, 2.0, 2000.0))
      assertEquals(h.qformCode, 1)
      assertEquals(h.sformCode, 2)
      assertEquals(h.qoffset, Vector(11.0, 0.0, 0.0))
      assertEquals(h.sformRows, Vector(Vector(2.0, 0.0, 0.0, 0.0), Vector(0.0, 2.0, 0.0, 0.0), Vector(0.0, 0.0, 2.0, 0.0)))
      assertEquals(MriHeaderConsistency.temporalSpacingSeconds(h), Some(2.0))
      assertEquals(MriHeaderConsistency.check(h, "bold", metadata), Vector.empty)

  test("TR comparison converts supported units and tolerates floating point rounding"):
    for (units, spacing) <- Vector(10 -> 2.0, 18 -> 2000.0, 26 -> 2000000.0) do
      val b = fixture()
      b(123) = units.toByte
      real(b, 1, 92, spacing, true)
      assertEquals(check(b), Vector.empty)
    assertEquals(check(fixture(), JsonValue.Obj(Map("RepetitionTime" -> JsonValue.Num(2.000001)))), Vector.empty)

  test("TR discrepancies warn without silently editing values or rejecting corrections"):
    val issues = check(fixture(), JsonValue.Obj(Map("RepetitionTime" -> JsonValue.Num(1.5))))
    assertEquals(issues.map(_.code), Vector(MriHeaderIssueCode.RepetitionTimeMismatch))
    assert(!issues.head.isError)

  test("variable timing never acquires a uniform TR from the header"):
    val fields: JsonValue.Obj = JsonValue.Obj(Map("VolumeTiming" -> JsonValue.Arr(Vector(JsonValue.Num(0), JsonValue.Num(3)))))
    val b = fixture(); real(b, 1, 92, Double.NaN, true)
    assertEquals(check(b, fields), Vector.empty)

  test("unknown timing and transforms are explicit warnings; uncoded bytes are not interpreted as transforms"):
    val b = fixture(); b(123) = 2; b(252) = 0; b(254) = 0
    real(b, 1, 256, Double.NaN, true); real(b, 1, 280, Double.NaN, true)
    assertEquals(check(b).map(_.code).toSet, Set(MriHeaderIssueCode.TransformUnavailable, MriHeaderIssueCode.TimingUnavailable))
    assert(check(b).forall(!_.isError))

  test("invalid voxel sizes and coded transforms are structural errors"):
    val b = fixture(); real(b, 1, 80, 0, true); real(b, 1, 256, 2, true); real(b, 1, 280, 0, true)
    assertEquals(check(b).filter(_.isError).map(_.code).toSet,
      Set(MriHeaderIssueCode.VoxelSize, MriHeaderIssueCode.Quaternion, MriHeaderIssueCode.Sform))

  test("negative and unknown unit/transform codes cannot masquerade as valid geometry"):
    val b = fixture(); b(123) = 127
    NiftiTestBytes.integer(b, 252, 2, -1, true)
    assert(check(b).exists(i => i.code == MriHeaderIssueCode.TransformCode && i.isError))
    assert(check(b).exists(i => i.code == MriHeaderIssueCode.Units && i.isError))

  test("static images reject non-singleton time axes; volume data may retain four dimensions"):
    assert(check(fixture(), suffix = "T1w").exists(_.code == MriHeaderIssueCode.Dimensions))
    assert(!check(fixture(), suffix = "epi").exists(_.code == MriHeaderIssueCode.Dimensions))


  test("singleton and static images do not acquire a time axis from unused pixdim values"):
    val b = fixture()
    NiftiTestBytes.integer(b, 48, 2, 1, true)
    assertEquals(MriHeaderConsistency.temporalSpacingSeconds(parsed(b)), None)
    val issues = check(b)
    assert(issues.exists(i => i.code == MriHeaderIssueCode.TimingUnavailable && !i.isError))
