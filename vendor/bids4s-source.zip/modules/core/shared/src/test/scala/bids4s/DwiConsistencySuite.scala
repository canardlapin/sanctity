package bids4s

class DwiConsistencySuite extends munit.FunSuite:
  private def values(s: String) = BValues.parse(s).fold(e => fail(e.toString), identity)
  private def vectors(s: String) = BVectors.parse(s).fold(e => fail(e.toString), identity)
  private def header(dimensions: Vector[Long] = Vector(2, 3, 4, 2)) =
    NiftiHeaderFacts.parse(NiftiTestBytes.header(dimensions = dimensions)).fold(e => fail(e.toString), identity)

  test("finite decimal gradients preserve columns and accept scientific notation, tabs and CRLF"):
    assertEquals(values(" +0\t1e3\r\n").values, Vector(0.0, 1000.0))
    assertEquals(vectors("0\t1\r\n0 0\r\n0 .0\r\n").values, Vector(GradientVector(0, 0, 0), GradientVector(1, 0, 0)))

  test("gradient rows are required and never silently transposed, flattened or padded"):
    Vector("", "0\n1000", "0 1000\n\n2000").foreach(s => assert(BValues.parse(s).isLeft))
    Vector("", "0 1\n0 0", "0 1\n0\n0 0", "0 0 0\n1 0 0\n0 1 0\n0 0 1").foreach(s => assert(BVectors.parse(s).isLeft))

  test("nonfinite, nondecimal, oversized and malformed numbers have row/column diagnostics"):
    Vector("NaN", "Infinity", "-Infinity", "1e999", "1e-9999", "-1e-9999", "0x1p0", "1,2", "n/a", "1" * 129).foreach { token =>
      val error = BVectors.parse(s"0 $token\n0 0\n0 0").left.toOption.get.head
      assertEquals(error.code, DwiIssueCode.Number)
      assertEquals(error.row, Some(1))
      assertEquals(error.column, Some(2))
    }

  test("negative b-values are rejected independently of vector checks"):
    assertEquals(BValues.parse("0 -10").left.toOption.get.head.code, DwiIssueCode.NegativeBValue)

  test("text and count budgets bound parsing and diagnostic volume"):
    assert(BValues.parse(" " * (GradientText.MaxCharacters + 1)).left.toOption.get.exists(_.code == DwiIssueCode.LimitExceeded))
    assert(BValues.parse(Vector.fill(GradientText.MaxVolumes + 1)("0").mkString(" ")).left.toOption.get.exists(_.code == DwiIssueCode.LimitExceeded))
    assertEquals(BValues.parse(Vector.fill(100)("bad").mkString(" ")).left.toOption.get.size, GradientText.MaxIssues)

  test("both count mismatches accumulate against NIfTI volume count"):
    val issues = DwiConsistency.check(header(), values("0"), vectors("0 1 0\n0 0 1\n0 0 0"))
    assertEquals(issues.map(_.code), Vector(DwiIssueCode.BvalCount, DwiIssueCode.BvecCount))

  test("low-b permits zero or unit vectors; diffusion-weighted volumes require unit vectors"):
    assertEquals(DwiConsistency.check(header(), values("0 1000"), vectors("0 1\n0 0\n0 0")), Vector.empty)
    assertEquals(DwiConsistency.check(header(), values("50 1000"), vectors("0 1\n0 0\n0 0")), Vector.empty)
    assertEquals(DwiConsistency.check(header(), values("0 1000"), vectors("1 1\n0 0\n0 0")), Vector.empty)
    val errors = DwiConsistency.check(header(), values("51 1000"), vectors("0 0\n0 0\n0 0"))
    assertEquals(errors.map(_.column), Vector(Some(1), Some(2)))

  test("norm policy tolerates rounding but rejects invalid and overflowing norms without normalization"):
    assertEquals(DwiConsistency.check(header(), values("0 1000"), vectors("0 1.005\n0 0\n0 0")), Vector.empty)
    Vector("1.02", "1e308").foreach { n =>
      assert(DwiConsistency.check(header(), values("0 1000"), vectors(s"0 $n\n0 0\n0 0")).exists(_.code == DwiIssueCode.VectorNorm))
    }

  test("3D has one volume and higher-dimensional DWI is explicitly unsupported"):
    assertEquals(DwiConsistency.check(header(Vector(2, 3, 4)), values("1000"), vectors("1\n0\n0")), Vector.empty)
    assertEquals(DwiConsistency.check(header(Vector(2, 3, 4, 2, 1)), values("0 1000"),
      vectors("0 1\n0 0\n0 0")).map(_.code), Vector(DwiIssueCode.UnsupportedDimensions))

object NiftiTestBytes:
  def integer(bytes: Array[Byte], offset: Int, width: Int, value: Long, little: Boolean): Unit =
    (0 until width).foreach { i => bytes(offset + (if little then i else width - 1 - i)) = ((value >>> (i * 8)) & 255).toByte }

  def header(version: Int = 1, little: Boolean = true, dimensions: Vector[Long] = Vector(2, 3, 4, 2)): Array[Byte] =
    val bytes = Array.fill[Byte](if version == 1 then 348 else 540)(0)
    integer(bytes, 0, 4, bytes.length.toLong, little)
    val (base, width) = if version == 1 then (40, 2) else (16, 8)
    integer(bytes, base, width, dimensions.size.toLong, little)
    dimensions.zipWithIndex.foreach((d, i) => integer(bytes, base + (i + 1) * width, width, d, little))
    integer(bytes, if version == 1 then 70 else 12, 2, 16, little)
    integer(bytes, if version == 1 then 72 else 14, 2, 32, little)
    integer(bytes, if version == 1 then 108 else 168, if version == 1 then 4 else 8,
      if version == 1 then 0x43b00000L else 544L, little)
    val magic = if version == 1 then Vector(110, 43, 49, 0) else Vector(110, 43, 50, 0, 13, 10, 26, 10)
    magic.zipWithIndex.foreach((b, i) => bytes((if version == 1 then 344 else 4) + i) = b.toByte)
    bytes

class NiftiHeaderFactsSuite extends munit.FunSuite:
  import NiftiTestBytes.*
  private def parsed(b: Array[Byte]) = NiftiHeaderFacts.parse(b).fold(e => fail(e.toString), identity)
  private def failure(b: Array[Byte]) = NiftiHeaderFacts.parse(b).left.toOption.get

  test("NIfTI-1 and NIfTI-2 decode in both byte orders with exact dimensions and offsets"):
    for v <- Vector(1, 2); little <- Vector(true, false) do
      val bytes = header(v, little)
      val h = parsed(bytes)
      assertEquals(h.version, v)
      assertEquals(h.byteOrder, if little then NiftiByteOrder.LittleEndian else NiftiByteOrder.BigEndian)
      assertEquals(h.dimensions, Vector(2L, 3L, 4L, 2L))
      assertEquals(h.dataOffset, if v == 1 then 352L else 544L)
      assertEquals(h.minimumFileBytes, h.dataOffset + 192)
      assertEquals(NiftiHeaderFacts.headerSize(bytes.take(4)), Right(bytes.length))

  test("truncated size/header fields and foreign signatures are typed failures"):
    Vector(Array.emptyByteArray, Array[Byte](1, 2, 3), Array.fill[Byte](540)(0),
      header().take(347), header(2).take(539)).foreach(b => assertEquals(failure(b).code, DwiIssueCode.Header))

  test("Analyze and paired-file magic do not masquerade as supported single-file NIfTI"):
    val paired = header()
    paired(345) = 'i'.toByte
    assertEquals(failure(paired).code, DwiIssueCode.Header)
    val corrupt = header(2)
    corrupt(8) = 0
    assertEquals(failure(corrupt).code, DwiIssueCode.Header)

  test("invalid rank and nonpositive active dimensions are rejected"):
    Vector(0L, 8L).foreach { rank =>
      val b = header()
      integer(b, 40, 2, rank, true)
      assertEquals(failure(b).code, DwiIssueCode.Dimensions)
    }
    Vector(0L, -1L).foreach(n => assertEquals(failure(header(dimensions = Vector(2, 3, n))).code, DwiIssueCode.Dimensions))

  test("array size arithmetic cannot overflow or allocate by untrusted dimensions"):
    assertEquals(failure(header(2, dimensions = Vector(Long.MaxValue, 2, 2))).code, DwiIssueCode.Dimensions)
    assertEquals(parsed(header(2, dimensions = Vector(1000000, 1000, 1))).minimumFileBytes, 4000000544L)

  test("scalar datatype and bit depth must agree"):
    val bad = header()
    integer(bad, 72, 2, 16, true)
    assertEquals(failure(bad).code, DwiIssueCode.Datatype)
    integer(bad, 70, 2, 32, true)
    assertEquals(failure(bad).code, DwiIssueCode.Datatype)

  test("voxel offsets must be finite integral positions after the header"):
    Vector(0L, 0x7fc00000L, 0x43b04000L).foreach { offset =>
      val b = header()
      integer(b, 108, 4, offset, true)
      assertEquals(failure(b).code, DwiIssueCode.Offset)
    }
    val b = header(2)
    integer(b, 168, 8, -1L, true)
    assertEquals(failure(b).code, DwiIssueCode.Offset)
