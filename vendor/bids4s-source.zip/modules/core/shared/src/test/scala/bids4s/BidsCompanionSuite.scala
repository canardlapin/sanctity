package bids4s

class BidsCompanionSuite extends munit.FunSuite:
  private val dwi = "sub-01/ses-A/dwi/sub-01_ses-A_run-01_dwi.nii.gz"
  private val bold = "sub-01/ses-A/func/sub-01_ses-A_task-memory_run-01_bold.nii.gz"
  private def result(target: String, kind: BidsCompanionKind, companions: String*): BidsCompanionResolution =
    BidsCompanionResolver(BidsManifest.fromRelativePaths(Vector(target) ++ companions))
      .resolve(BidsPath(target), kind).toOption.get
  private def selected(r: BidsCompanionResolution): String = r.outcome match
    case BidsCompanionOutcome.Selected(c) => c.path.value
    case other => fail(other.toString)

  test("DWI gradient selection retains root-to-local evidence and selects only the lowest file"):
    val local = "sub-01/ses-A/dwi/sub-01_ses-A_run-01_dwi.bval"
    val r = result(dwi, BidsCompanionKind.Bval, "dwi.bval", "sub-01/sub-01_dwi.bval", local)
    assertEquals(selected(r), local)
    assertEquals(r.applicable.map(_.path.value), Vector("dwi.bval", "sub-01/sub-01_dwi.bval", local))
    assertEquals(r.applicable.last.matchedEntities("run"), "01")

  test("bval and bvec use independent applicability and may be inherited at different levels"):
    assertEquals(selected(result(dwi, BidsCompanionKind.Bvec, "dwi.bvec", "sub-01/sub-01_dwi.bval")), "dwi.bvec")
    assertEquals(selected(result(dwi, BidsCompanionKind.Bval, "dwi.bvec", "sub-01/sub-01_dwi.bval")), "sub-01/sub-01_dwi.bval")

  test("same-level candidates are ambiguous even with different specificity and a lower override"):
    val r = result(dwi, BidsCompanionKind.Bval, "dwi.bval", "run-1_dwi.bval", "sub-01/sub-01_dwi.bval")
    assertEquals(r.outcome, BidsCompanionOutcome.Ambiguous(Vector(BidsPath("dwi.bval"), BidsPath("run-1_dwi.bval"))))

  test("events inherit across subjects and sessions using task and entity applicability"):
    val r = result(bold, BidsCompanionKind.Events, "task-memory_events.tsv", "task-other_events.tsv",
      "sub-02/sub-02_task-memory_events.tsv", "sub-01/ses-B/sub-01_ses-B_task-memory_events.tsv")
    assertEquals(selected(r), "task-memory_events.tsv")
    assertEquals(r.applicable.size, 1)

  test("event selection prefers a session-level table without merging rows"):
    val local = "sub-01/ses-A/sub-01_ses-A_task-memory_events.tsv"
    val r = result(bold, BidsCompanionKind.Events, "task-memory_events.tsv", local)
    assertEquals(selected(r), local)
    assertEquals(r.applicable.map(_.path.value), Vector("task-memory_events.tsv", local))

  test("a run events table applies to every echo without choosing an arbitrary echo"):
    val event = "sub-01/ses-A/func/sub-01_ses-A_task-memory_run-1_events.tsv"
    Vector("1", "2", "3").foreach { echo =>
      assertEquals(selected(result(bold.replace("_bold", s"_echo-${echo}_bold"), BidsCompanionKind.Events, event)), event)
    }

  test("run indices compare numerically while subject labels remain lexical"):
    val numeric = "sub-01/ses-A/func/sub-01_ses-A_task-memory_run-1_events.tsv"
    assertEquals(selected(result(bold, BidsCompanionKind.Events, numeric)), numeric)
    assertEquals(result(bold, BidsCompanionKind.Events, "sub-1_task-memory_events.tsv").outcome, BidsCompanionOutcome.Missing)

  test("candidates containing extra entities do not apply"):
    assertEquals(result(dwi, BidsCompanionKind.Bval, "acq-high_dwi.bval").outcome, BidsCompanionOutcome.Missing)

  test("a nested dataset cannot inherit raw gradients or events"):
    val target = "nested/" + dwi
    val r = result(target, BidsCompanionKind.Bval, "dwi.bval", "nested/dataset_description.json")
    assertEquals(r.datasetRoot, Some(BidsPath("nested")))
    assertEquals(r.outcome, BidsCompanionOutcome.Missing)

  test("declared derivative roots establish independent boundaries without descriptions"):
    val target = "derivatives/p/" + dwi
    val m = BidsManifest.fromRelativePaths(Vector(target, "dwi.bvec"))
    val resolver = BidsCompanionResolver(m, Vector(DerivativeRoot(BidsPath("derivatives/p"), PipelineName("p"))))
    assertEquals(resolver.resolve(BidsPath(target), BidsCompanionKind.Bvec).toOption.get.outcome, BidsCompanionOutcome.Missing)

  test("sibling directories cannot donate a companion"):
    assertEquals(result(dwi, BidsCompanionKind.Bval, "sub-01/ses-A/fmap/sub-01_ses-A_dwi.bval").outcome, BidsCompanionOutcome.Missing)

  test("absence is distinct from unsupported target and unsafe input"):
    assertEquals(result(dwi, BidsCompanionKind.Bval).outcome, BidsCompanionOutcome.Missing)
    assert(result(bold, BidsCompanionKind.Bval).outcome.isInstanceOf[BidsCompanionOutcome.Unsupported])
    val resolver = BidsCompanionResolver(BidsManifest.fromRelativePaths(Vector(dwi)))
    assert(resolver.resolve(BidsPath("../escape.nii"), BidsCompanionKind.Bval).isLeft)
    assert(resolver.resolve(BidsPath(bold), BidsCompanionKind.Events).toOption.get.outcome.isInstanceOf[BidsCompanionOutcome.Unsupported])

  test("bounded candidate scans fail explicitly rather than returning a partial selection"):
    val m = BidsManifest.fromRelativePaths(Vector(dwi, "dwi.bval", "sub-01/sub-01_dwi.bval"))
    val r = BidsCompanionResolver(m, candidateLimit = 1).resolve(BidsPath(dwi), BidsCompanionKind.Bval).toOption.get
    assert(r.outcome.isInstanceOf[BidsCompanionOutcome.LimitExceeded])
    assertEquals(r.applicable, Vector.empty)

  test("inventory ordering and duplicate paths do not change outcomes or evidence"):
    val paths = Vector(dwi, "dwi.bval", "sub-01/sub-01_dwi.bval", "dwi.bval")
    def resolve(ps: Vector[String]) = BidsCompanionResolver(BidsManifest.fromRelativePaths(ps)).resolve(BidsPath(dwi), BidsCompanionKind.Bval)
    assertEquals(resolve(paths), resolve(paths.reverse))

  test("checked manifests accept inherited gradient and event companions"):
    val r = BidsManifest.fromRelativePathsChecked(Vector(dwi, bold, "sub-01/sub-01_dwi.bval",
      "sub-01/sub-01_dwi.bvec", "task-memory_events.tsv"))
    assert(!r.issues.exists(_.severity == BidsIssueSeverity.Error), r.issues.toString)
