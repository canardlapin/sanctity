package bids4s

class BidsPhasePairSuite extends munit.FunSuite:
  private val prefix = "sub-01/ses-cal/fmap/sub-01_ses-cal_acq-gre_run-01_"
  private val roles = Vector("phase1", "phase2", "magnitude1", "magnitude2")
  private val paths = roles.map(r => prefix + r + ".nii")
  private def sidecar(p: String): String = p.stripSuffix(".gz").stripSuffix(".nii") + ".json"
  private val documents: Map[String, JsonValue.Obj] = paths.map { p =>
    val obj: JsonValue.Obj = JsonValue.Obj(Map("EchoTime" -> JsonValue.Num(if p.endsWith("1.nii") then 0.006 else 0.00746)))
    sidecar(p) -> obj
  }.toMap
  private def report(images: Vector[String] = paths, docs: Map[String, JsonValue.Obj] = documents): BidsPhasePairReport =
    val manifest = BidsManifest.fromRelativePaths(images ++ docs.keys)
    val resolver = BidsMetadataResolver(manifest, docs.map((p, v) => BidsPath(p) -> v))
    val resolved = images.flatMap(p => resolver.resolve(BidsPath(p)).toOption.map(BidsPath(p) -> _)).toMap
    BidsPhasePairResolver.fromResolved(manifest, resolved)

  test("complete family retains exact members and all echo-time origins"):
    val r = report()
    assertEquals(r.issues, Vector.empty)
    assertEquals(r.groups.head.members.map(_.value), paths)
    assertEquals(r.groups.head.evidence.map(_.document.value).toSet, documents.keySet)

  roles.zip(paths).foreach { (role, path) =>
    test(s"missing $role blocks the family"):
      val r = report(paths.filterNot(_ == path))
      assert(r.issues.exists(_.code == BidsPhasePairIssueCode.MissingMember))
      assertEquals(r.groups, Vector.empty)
    test(s"duplicate compressed $role is ambiguous"):
      val r = report(paths :+ (path + ".gz"))
      assert(r.issues.exists(_.code == BidsPhasePairIssueCode.AmbiguousMember))
      assertEquals(r.groups, Vector.empty)
  }

  test("run padding matches while subject, session and acquisition labels do not"):
    val mag = paths(2)
    val padded = mag.replace("run-01", "run-1")
    assertEquals(report(paths.updated(2, padded), documents - sidecar(mag) + (sidecar(padded) -> documents(sidecar(mag)))).issues, Vector.empty)
    Vector("sub-01" -> "sub-1", "ses-cal" -> "ses-other", "acq-gre" -> "acq-other").foreach { (old, next) =>
      val r = report(paths.updated(2, mag.replace(old, next)))
      assert(r.issues.exists(_.code == BidsPhasePairIssueCode.MissingMember))
      assertEquals(r.groups, Vector.empty)
    }

  test("missing, nonpositive, equal, reversed and nonnumeric phase times fail"):
    Vector[JsonValue](JsonValue.Null, JsonValue.Num(0), JsonValue.Num(0.006), JsonValue.Num(0.005), JsonValue.Str("0.00746")).foreach { value =>
      val r = report(docs = documents.updated(sidecar(paths(1)), JsonValue.Obj(Map("EchoTime" -> value))))
      assert(r.issues.exists(_.code == BidsPhasePairIssueCode.EchoTimes))
      assertEquals(r.groups, Vector.empty)
    }

  test("optional magnitude times must agree when supplied"):
    assertEquals(report(docs = documents.updated(sidecar(paths(2)), JsonValue.Obj(Map.empty))).issues, Vector.empty)
    val r = report(docs = documents.updated(sidecar(paths(3)), JsonValue.Obj(Map("EchoTime" -> JsonValue.Num(0.008)))))
    assert(r.issues.exists(_.code == BidsPhasePairIssueCode.EchoTimes))
    assertEquals(r.groups, Vector.empty)

  test("identical-entity phasediff is ambiguous while another acquisition remains separate"):
    val mixed = report(paths :+ (prefix + "phasediff.nii"))
    assert(mixed.issues.exists(_.code == BidsPhasePairIssueCode.MixedRepresentation))
    assertEquals(mixed.groups, Vector.empty)
    assertEquals(report(paths :+ (prefix.replace("acq-gre", "acq-other") + "phasediff.nii")).groups, report().groups)

  test("missing metadata and wrong contexts fail explicitly"):
    val manifest = BidsManifest.fromRelativePaths(paths)
    assert(BidsPhasePairResolver.fromResolved(manifest, Map.empty).issues.exists(_.code == BidsPhasePairIssueCode.Metadata))
    val context = BidsContext.from("other", BidsRegistry.Builtin).toOption.get
    val other = BidsManifest.fromRelativePathsChecked(paths, context = context).value
    val value = BidsMetadataResolver(other, Map.empty).resolve(BidsPath(paths.head)).toOption.get
    assertEquals(BidsPhasePairResolver.fromResolved(manifest, Map(BidsPath(paths.head) -> value)).issues.head.code, BidsPhasePairIssueCode.Context)

  test("family output is deterministic under inventory and metadata ordering"):
    assertEquals(report(paths.reverse, documents.toVector.reverse.toMap), report())

  test("nested dataset members cannot fill a family in its parent dataset"):
    val r = report(paths.updated(3, "derivatives/other/" + paths(3)) :+ "derivatives/other/dataset_description.json")
    assert(r.issues.exists(_.code == BidsPhasePairIssueCode.MissingMember))
    assertEquals(r.groups, Vector.empty)
