package example

import bids4s.*

object FirstContact:
  val name =
    BidsName.parse("sub-01_task-rest_run-1_bold.nii.gz")

  val query =
    BidsQuery.exact(EntityKey.Subject, "01", scope = BidsScope.Raw)

  val filesWithRuns =
    BidsQuery.present(EntityKey.Run)

  val firstRun =
    BidsQuery.run(1)

  def explainMetadata(project: BidsProject, path: BidsPath): Either[BidsError, Vector[BidsMetadataValue]] =
    project.resolveMetadata(path).map(_.history("RepetitionTime"))

  def fieldmaps(project: BidsProject): BidsFieldmapReport =
    BidsFieldmapResolver.resolve(project.manifest, BidsMetadataResolver(project.manifest, project.sidecars, project.derivatives))

  def companions(project: BidsProject, path: BidsPath): Either[BidsError, BidsCompanionResolution] =
    BidsCompanionResolver(project.manifest, project.derivatives).resolve(path, BidsCompanionKind.Events)

  def gradientCheck(header: Array[Byte], bval: String, bvec: String): Either[String, Vector[DwiIssue]] =
    for
      h <- NiftiHeaderFacts.parse(header).left.map(_.message)
      b <- BValues.parse(bval).left.map(_.map(_.message).mkString("; "))
      v <- BVectors.parse(bvec).left.map(_.map(_.message).mkString("; "))
    yield DwiConsistency.check(h, b, v)

  def checkedEvents(text: String, count: Long, fields: Map[String, JsonValue]): Vector[EventIssue] =
    val table = CheckedEvents.assess(text)
    val timing = EventTiming.assess(Some(count), fields)
    table.issues ++ timing.issues ++ table.table.toVector.flatMap(EventTiming.compare(_, timing.context))

  def projectTable(text: String, names: Vector[String]): Either[String, String] =
    for
      checked <- CheckedTsv.parse(text).left.map(_.message)
      selected <- checked.table.select(names).left.map(_.message)
    yield CheckedTsv.render(selected)

  def configuredManifest(registry: BidsRegistry, paths: Vector[String]): Either[BidsError, BidsManifest] =
    BidsContext.from("consumer-v1", registry, Some("1.10.0"), "Consumer-qualified registry")
      .map(context => BidsManifest.fromRelativePathsChecked(paths, context = context).value)

  def phaseDifferenceFamilies(manifest: BidsManifest, resolved: Map[BidsPath, BidsMetadataResolution]): BidsPhaseDifferenceReport =
    BidsPhaseDifferenceResolver.fromResolved(manifest, resolved)

  def assessMriHeader(bytes: Array[Byte], suffix: String, metadata: JsonValue.Obj): Either[DwiIssue, Vector[MriHeaderIssue]] =
    NiftiHeaderFacts.parse(bytes).map(MriHeaderConsistency.check(_, suffix, metadata))

  def multiEchoFamilies(manifest: BidsManifest, resolved: Map[BidsPath, BidsMetadataResolution]): BidsMultiEchoReport =
    BidsMultiEchoResolver.fromResolved(manifest, resolved)

  def localStimuli(events: String, inventory: Set[BidsPath]): BidsStimulusReport =
    BidsStimulusResolver.resolve(events, inventory)
