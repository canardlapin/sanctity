package sanctity.app

import cats.effect.{ExitCode, IO}
import sanctity.postgres.PostgresDatabase

/** Explicit trusted schema entry point; serving never runs migrations. */
object MigrationCli extends ProtectedIOApp:
  def run(args: List[String]): IO[ExitCode] =
    val runtime = args match
      case Nil => Some(None)
      case "--runtime-role" :: role :: Nil => Some(Some(role))
      case _ => None
    if runtime.isEmpty then IO.println("usage: sanctity migrate [--runtime-role ROLE]").as(ExitCode.Error)
    else ServiceConfiguration.exit {
      ServiceConfiguration.database(sys.env).flatMap { config =>
        PostgresDatabase.open[IO](config).use(db => db.migrate *> runtime.flatten.fold(IO.unit)(db.grantRuntime)) *>
          IO.println("Catalog migrations verified and applied.")
      }
    }
