package sanctity.postgres

import munit.FunSuite
import sanctity.kernel.*

final class PolicyReceiptCompatibilitySuite extends FunSuite:
  import OrganizationCodecs.given
  private val legacy = """{"version":1,"value":{"sequence":7,"actor":"00000000-0000-0000-0000-000000000001","key":"old-organization-write","affected":[],"at":"2026-01-01T00:00:00Z"}}"""

  test("V008 organization receipts decode as local-only without a history rewrite") {
    val receipt=JsonCodecs.decode[OrganizationReceipt](legacy).toOption.get
    assertEquals(receipt.sequence,7L)
    assertEquals(receipt.durability,PolicyDurability.LocalOnly)
    val current=JsonCodecs.encode(receipt)
    assert(current.contains("\"durability\":\"LocalOnly\""))
    assertEquals(JsonCodecs.decode[OrganizationReceipt](current),Right(receipt))
  }

  test("unknown or purported independent durability cannot be decoded as local success") {
    Vector("Durable","Pending","future-version").foreach { state =>
      val forged=legacy.replace("\"sequence\":7",s"\"sequence\":7,\"durability\":\"$state\"")
      assert(JsonCodecs.decode[OrganizationReceipt](forged).isLeft)
    }
  }
