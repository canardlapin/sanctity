# Current authority and policy transactions

F03.2 joins the [reference rules](organization-reference.md) to PostgreSQL.
The contract is [ADR 004](decisions/004-policy-durability.md). This document
inventories the current implementation for O03.6; it does not qualify recovery.

Every repository authorization takes the recovery gate, then the installation
policy guard, then credential/dataset locks. Reads and scientific transactions
hold the shared policy guard until commit. Organization, grant and credential
mutations hold its exclusive lock. They use the database clock and current
principal eligibility, appointment lineage, placement, stewardship, exact grant
scope/actions/expiry and lifecycle state. Curator attribution supplies no power
in an initialized organization. Explicit migration supplies stewardship instead.

`PolicySql.load` constructs the shared model from relational rows. It currently
loads the complete policy state; this is an engineering correctness baseline,
not a bounded-query or institutional-scale qualification. F03.3 owns the public
disclosure projections and F03.4 owns continuous stream/worker admission.
Existing repository actions, receipt retries and import renewals already pass
through the transaction guard. The SQL matrix qualifies the trusted state/decision
adapter, not every public projection. The receipt-read entry point still also requires
legacy `Accept` authority, and candidate retrieval retains its legacy Propose-or-Accept
path. F03.3 must reconcile these read surfaces with the model's metadata/evidence rules
and uniform disclosure behavior while preserving private-source restrictions. An authorization admitted before a restrictive
transaction may finish first; subsequent admissions see the restriction.

## Supported mutation inventory

All initialized-catalog mutations below append `organization_event` and advance
`organization_policy` in the same transaction. Non-organization commands leave
its `request` column null, so the organization retry reader never decodes them
as organization commands. Policy events are not scientific outbox messages.

| Entry point / event kind | Policy effects and retained intent | Retry/admission boundary |
| --- | --- | --- |
| Organization bootstrap / `OrganizationGenesis` | Legacy principal and dataset attribution, exact grants including existing revocations, credential status without secrets, migration report, complete organization after-images | Explicit operator and preview digest; repeated bootstrap returns the same report |
| `CreateLab`, `RenameLab`, `CreateProject`, `RenameProject` | Changed lab/project records, initial admin membership or steward participation | Actor, request key, complete command, expected generations, before/after records |
| `AddMember`, `EndMember`, `AddParticipant`, `EndParticipant` | Appointment identity, named membership basis, role/status/expiry, generations | Current operator/organization admission; original appointment IDs remain ended on rejoining |
| `PlaceNewDataset` | Dataset identity/custodian/attributed curator, initial placement and explicit stewardship | Deterministic creation ID and payload-bound organization retry |
| `AddSteward`, `EndSteward`, `SetInheritance` | Stewardship or placement records; confirmed inheritance impact in request | Current command authority and expected generations |
| `ArchiveProject`, `ArchiveLab` | Current archive status and generations | Live-work fences; reads and restrictive grant revocation remain possible |
| `DisablePrincipal` | Principal before/after state, IDs of newly revoked credentials and timestamp, owned import lease IDs/tokens/expiry invalidated atomically | Cached API contexts are rechecked; later receipt, grant, acceptance and lease admission fail |
| `GrantIssued` | Exact grant issuer/recipient/scope/actions, creation/expiry, basis IDs, generation; complete new local principal record if the legacy grant API introduces one | Stable grant ID binds the entire intent; changed or revoked intent conflicts; current issuer and recipient eligibility rechecked |
| `GrantRevoked` | Grant before/after images, next generation and revocation time | Repeat revocation is a no-op only after current authority is rechecked; works on archived parents |
| `CredentialIssued` | Credential ID, principal, label, issuance/expiry; no bearer secret or token digest | Explicit database operator capability; random issuance ID, one-time secret disclosure |
| `CredentialRevoked` | Credential ID/principal and revocation timestamp | Explicit operator; repeat revocation remains a no-op |

Credential operator events retain both the configured installation operator
identity and actual database login. These are local engineering operator
identities, not proof of institutional identity. API credentials authenticate;
they do not confer any dataset permission. A newly introduced local principal
is likewise not an approved institutional or guest identity.

Grant timestamps use PostgreSQL microsecond precision; finer input is refused rather
than silently changing a payload-bound retry. Expiry is checked against the current
database clock. It requires no timer
mutation/event and must never be reset during replay. Membership-derived grants
retain their original dependency IDs; independent grants survive the issuer's
later departure. Only exact historical actions survive migration: metadata
permission does not silently acquire discovery, content or evidence permission.

The V009 eligibility and lifecycle columns provide trusted read-model inputs
and fail closed on unknown encodings. Public guest sponsorship, identity binding,
browser session, quarantine/withdrawal/retention/hold administration are **not
implemented here**. F04/O04 must introduce governed commands, events and tests
through the same boundary before those capabilities can be enabled. SQL fixture
writes in the matrix tests do not constitute those administration features.
Legacy recovery invalidation remains confined to uninitialized catalogs;
organization recovery is still closed pending O03.6–O03.8.

## Local event and future witness boundary

`PolicySql.commit` is the common transaction boundary. It captures installation,
writer epoch, event ID, prior head, proposed revision, actor, database actor,
command kind, machine reason, request identity/digest, exact changes and local receipt.
Expected generations and target IDs are retained in the organization request and
before/after records. Current APIs accept no separate human approval references;
the event records an empty approval list, never an inferred institutional approval. It computes
canonical sorted-key local JSON and a versioned digest chain, performs the
policy effects and appends the event before the catalog transaction commits.
An append failure rolls back the effects. Organization bootstrap/creation can
stage new rows within this same uncommitted transaction; no staged policy is
externally visible or acknowledged before the event commits.

Existing `organization-local-v1` events remain immutable. New events use
`policy-local-v2` and the `sanctity.policy-local.v2` digest domain, chaining from
the existing head. O03.6 must recognize both versions during enrollment and
retain their identities and exact historical bytes. Enrollment must capture a
complete current checkpoint, including legacy defaults and restrictions; an
empty witness cannot legitimize an older catalog. Enrollment must include existing
eligibility/lifecycle input columns. Unsupported nondefault state must close enrollment,
never be silently replaced with `Local` or `Available`.

The local JSON representation is not a claimed RFC 8785/Ed25519 transport
implementation. O03.6 must implement the ADR 004 signed wire encoding, bounded
PREPARE before local commit, COMMIT/ABORT resolution, pending/outcome-unknown
responses, writer fencing and acknowledgment reconciliation at this boundary.
It must bind the exact intent and local event identity, including command
payload/expected generations and before/after images. No independent journal
may infer policy from the scientific outbox or construct another history.

The schema and organization receipt type allow only `LocalOnly`. There are no
prepare/commit certificates and no independent durability mode. A successful
local mutation says nothing about surviving loss of the catalog or computer.
The [standalone witness](policy-witness.md) is qualified as a component in O03.6.1; it is
not yet connected to this SQL boundary. O03.6.2 owns that integration, and O03.6.3
owns the combined failure matrix. The parent O03.6 stays open throughout.
Credential issuance currently has no client-selected retry key; a lost secret
response requires operator inspection/revocation and fresh issuance. O03.6 must
resolve its internal event ID before acknowledging independent durability.

## Runtime database boundary

The runtime can append grant events and advance the local policy head, but
cannot edit or delete historical events. Row security limits its inserts to
`GrantIssued`/`GrantRevoked`; operator organization/credential events require
the schema-owner/operator connection. Runtime grants do not include principal
updates, organization administration, credential issuance/revocation, lifecycle
changes, bootstrap fields, writer epoch, durability mode or recovery opening.
The runtime remains a trusted application service with grant-write capability;
this is not a claim of protection against a compromised service or schema owner.
