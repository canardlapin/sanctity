# Sanctity service distribution

The internal development distribution runs the API and browser console, catalog
migrations and trusted operator commands from JARs. Runtime requirements are Java
21 or newer, a POSIX shell (including `dirname`), PostgreSQL and writable managed
storage. Java 21 is the currently tested runtime; newer Java versions require
qualification. No Scala, sbt, Python or source checkout is required to run it.
The current qualification uses PostgreSQL 17. Startup validates private storage,
database credentials and the explicit origin before opening a listener. Configuration,
proxy and supervision templates are included; runtime/migration database-role separation
and full upgrade qualification remain subsequent O01 work.

## Build and identity

Build prerequisites: Java 21, sbt 1.10.5, Python 3.9+ and network access or populated
dependency caches. From the repository root:

```sh
python3 scripts/package-service.py --output target/service-release
python3 scripts/check-service-package.py target/service-release/sanctity-0.1.0-SNAPSHOT.zip --output target/service-smoke
```

Choose new output directories for subsequent runs. The build cleans first-party
outputs, uses sbt's resolved service classpath, packages the exact JAR closure, and
checks the vendored bids4s source against its SHA-256 pin. Source overrides are
rejected. `manifest.json` records application, Scala, sbt, upstream and dependency
versions, hashes, reported licenses and embedded notices. `metadata/source.json`
identifies the actual build inputs, including uncommitted files; a Git revision alone
is insufficient. Source paths are repository-relative; no cache paths or environment
secrets are shipped. The source inventory includes processing code because the
existing scientific BuildIdentity uses it, but its executable module is excluded.

The adjacent `.sha256` file identifies the ZIP; obtain that digest through a trusted
release channel before installation. The manifest identifies every packaged payload
file. It is an integrity inventory, not a signature or runtime tamper-prevention
mechanism. Keep the installed distribution read-only to the service account.
ZIP timestamps, ordering and permissions are fixed; packaging identical JAR inputs
produces identical bytes. This does not claim bit-identical compiler output across
different machines/JDKs. Retain the exact source snapshot and build inputs with any
release promoted to staging.

Sanctity currently has no declared repository license; its inventory records
`NOASSERTION`. Dependency licenses and original JAR notices are retained without
alteration; bids4s's Apache-2.0 license is included. This is an internal development
artifact, not a declaration of licensing terms or a public release.

## Install and run

Verify the trusted ZIP digest, unpack into a new versioned directory and preserve
the executable bit on `bin/sanctity` (set `chmod 755 bin/sanctity` if the unzip tool
does not preserve it). The launcher supports paths with spaces and honors JAVA_HOME.
From the unpacked directory:

```sh
bin/sanctity --version
bin/sanctity --help
```

Supply `SANCTITY_JDBC_URL`, `SANCTITY_DB_USER` and exactly one of
`SANCTITY_DB_PASSWORD_FILE` (preferred) or `SANCTITY_DB_PASSWORD`. Secret files must
be regular mode-0600 files owned by the service user in a mode-0700 directory; one
terminal newline is permitted. File and storage paths must be absolute canonical
paths with no symlink alias or `..` component. Resolve the containing directory with
`realpath` before configuring it, including macOS `/var` or `/tmp` aliases. Secrets
must be outside the blob root. No configuration file is evaluated as shell code.

The supported JDBC form is `jdbc:postgresql://HOST:PORT/DATABASE`, optionally with
one `sslmode` parameter (`disable`, `require`, `verify-ca` or `verify-full`). Credentials,
arbitrary driver parameters, URL userinfo and fragments are rejected. Remote databases
need an independently configured trusted TLS connection; `require` alone does not
verify the server identity. The demonstrated local profile uses loopback PostgreSQL.
`SANCTITY_DB_SCHEMA` defaults to `sanctity`; `SANCTITY_DB_POOL_SIZE` defaults to 4
and permits 2–32 connections. Configuration checks do not infer deployment capacity.

Create `SANCTITY_STORAGE` explicitly, owned by the service user and mode 0700.
Startup refuses missing, read-only, public, aliased or unsafe roots; it creates private
`objects`/`staging` directories if absent and performs a removable write/flush probe.
Existing child directories must also be private and owned by the service user.
The root cannot contain the working directory, the user's home or credential file.
Only the service account may change this tree; these checks do not protect against
that account maliciously replacing its own files. Do not point storage at source data,
database files or an existing unrelated directory. The launcher sets umask 077.

`SANCTITY_HTTP_PORT` defaults to 8080 (range 1–65535). The default
`SANCTITY_DEPLOYMENT_MODE=loopback` accepts only `http://127.0.0.1:PORT` as its
public origin. For a TLS proxy, explicitly select `proxy` and set
`SANCTITY_PUBLIC_ORIGIN=https://YOUR-HOST` (optional port; no path/trailing slash,
userinfo, query or fragment). The listener always binds 127.0.0.1. Requests must
have exactly the configured Host and, when present, Origin. Cross-site browser
requests are denied. Forwarding headers are stripped and cannot change authority,
identity or the configured origin. Local processes remain within the host trust
boundary; proxy mode does not authenticate a proxy process.

The distribution's `deployment/` directory contains environment, nginx TLS, systemd
and macOS launchd examples (repository sources: [deployment](deployment/)). Replace
their example paths and identities, protect configuration/logs, validate the installed
supervisor/proxy configuration, and independently check certificates and network
exposure before use. These are templates, not a claim that Linux supervision or an
institutional TLS endpoint has been qualified. No supervisor is installed automatically.
Do not put credentials in command arguments, shell history or checked-in files.

```sh
bin/sanctity migrate
bin/sanctity serve
```

The origin binds loopback only. The browser console is at `/` and API at `/v1`.
External access requires the deployment's TLS reverse proxy. At this stage `serve`
and the trusted operator commands still invoke idempotent migration checks and
require their existing database privileges. The new explicit `migrate` entry point
does not yet establish least-privilege separation; O01.3 owns that change.

SIGTERM stops admission and gives existing HTTP responses up to
`SANCTITY_SHUTDOWN_SECONDS` (default 10, range 1–120) to finish, then cancels stalled
responses and releases their resources before closing the database pool. Give the
supervisor at least ten additional seconds (the templates use 20 for the default).
Forced termination cannot drain work: transactional publication and durable operation
leases still govern retry; a client losing the response must check the operation's
recorded outcome rather than assume failure or blindly create another request.
The server does not currently run a background import worker. Existing broad resource
limits and future background-worker shutdown remain O02.3/W01 responsibilities.

Startup failures and operator entry-point failures report fixed categories without
JDBC URLs, filesystem paths, secret values or nested exception causes. HTTP failures
similarly omit raw exceptions and forwarded values. This minimal error boundary does
not supply O02.1's planned request IDs, health endpoints or operational diagnostics.

## Trusted operator commands

These commands exercise privileged database authority; they are not public
authentication shortcuts. PRINCIPAL, CUSTODIAN and DATASET are stable identifiers.

```text
bin/sanctity repository create PRINCIPAL CUSTODIAN
bin/sanctity repository import PRINCIPAL DATASET SOURCE STORAGE KEY
bin/sanctity repository issue-credential PRINCIPAL SECONDS LABEL NEW_FILE
bin/sanctity repository revoke-credential CREDENTIAL_ID
bin/sanctity recovery capture-policy NEW_FILE
bin/sanctity recovery reconcile POLICY TRUSTED_DIGEST STORAGE
```

Credential issuance writes a new mode-0600 file and does not print its secret. Native
intake is a trusted local-directory operation. Recovery capture contains sensitive
policy: use a protected directory. Reconciliation needs independently trusted current
policy; possession of a digest beside an old backup does not establish freshness.
Independent durable policy recovery remains O03.

The distribution includes the existing API, console assets, SQL migrations, native
BIDS intake and recovery mechanisms. It excludes development demos, test libraries,
DICOM/XNAT adapters and optional numerical processing recipes. Those can be added
through explicitly qualified distributions later. The source-development `app/runMain`
commands remain available through the app's dependency on the service module.

## Verification boundaries

The smoke harness needs Python and Docker on the **test host**, starts a disposable
pinned PostgreSQL container, unpacks to an isolated directory, and launches Java with
a restricted PATH and no application sources. It checks migration twice, private
credential issuance/revocation, API authentication, console resources, native intake,
byte retrieval and policy capture. It retains redacted evidence and always stops its
service/container. It also rejects invalid settings and occupied ports, checks
Host/Origin enforcement and raw-log canaries, and verifies exact accepted state and
revocation after real SIGTERM/SIGKILL restarts. Service tests separately exercise
active-response draining and cancellation at the configured shutdown deadline.
Its PostgreSQL password is synthetic and restricted to this disposable
test. This is artifact qualification on the current host, not operator-led clean-host
installation, independent disaster recovery, institutional load or pilot acceptance.
