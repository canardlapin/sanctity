package sanctity.app

import cats.effect.{ExitCode, IO}
import sanctity.postgres.PostgresDatabase

/** Explicit trusted schema entry point; runtime privilege separation follows in O01.3. */
object MigrationCli extends ProtectedIOApp:
  def run(args: List[String]): IO[ExitCode] =
    if args.nonEmpty then IO.println("usage: sanctity migrate").as(ExitCode.Error)
    else ServiceConfiguration.exit {
      ServiceConfiguration.database(sys.env).flatMap { config =>
        PostgresDatabase.open[IO](config).use(_.migrate) *>
          IO.println("Catalog migrations verified and applied.")
      }
    }
