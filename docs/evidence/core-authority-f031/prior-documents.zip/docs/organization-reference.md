# Organization reference model

F02.1 implements ADR 001–003's organization records and atomic reference transitions.
F02.2 persists that contract in PostgreSQL V008 through the same decision function.
The governed service now authorizes explicit dataset stewards and exact independent
grants; historical curator attribution supplies no access bypass after bootstrap.

`Organization.scala` defines typed IDs; checked Unicode display text and generations;
principals, labs, projects, memberships, participations, placement, explicit stewardship
and navigation-link records. Display names are not identifiers. Membership-derived
participations name the exact membership ID; ended IDs are never reused.

`ReferenceOrganizationCatalog` accepts an explicit trusted principal/dataset inventory
and installation-operator set. It supports lab/project creation and naming, membership
and participation appointment/ending, initial placement of a registered empty dataset,
explicit stewardship appointment/ending, confirmed role inheritance, archival/unarchive
and emergency principal disablement. Initial placement creates explicit creator
stewardship and defaults to `ExplicitOnly`.

Each mutation checks the current actor and all required record generations in one
`Ref.modify`, commits its audit and idempotency result atomically, and leaves state
unchanged on failure. A retry reauthorizes the actor before returning its original
receipt; a reused key with different intent conflicts. Project generations also track
participation and membership-derived authority changes. Role-inheritance confirmation
compares both generation and current eligible recipients/roles, including expiry.

Ordinary transitions cannot remove the last eligible lab admin, project steward or
explicit dataset steward. Emergency disablement overrides those appointments while
retaining attribution; `recoveryNeeds(now)` identifies affected resources, including
natural expiry. No expiry is extended to avoid a recovery need. Lab administration
never implies project stewardship, and project stewardship never implies explicit
dataset stewardship. No principal, lab, project, placement or appointment is deleted.

Archival refuses active work. The reference adapter records distinct lease tokens,
so an old worker's release cannot clear another worker's fence. New work cannot be
registered on an archived project. Archive preserves appointments and separately
checked reads; new participation, placement and inheritance changes are refused.
A lab can archive only after its projects, and an archived parent must reopen first.

The snapshot/lease adapter methods are trusted in-process support, not public endpoints.
They deliberately expose complete state to contract tests and future storage adapters;
F03/F05 must filter every public read. The reference implementation scans maps and is
not evidence of bounded institutional-scale database work.

## PostgreSQL cutover and current boundary

V008 extends the existing principal registry and adds labs, projects, memberships,
participation, placement, stewardship and navigation links with generated query keys,
foreign keys, generation/status constraints and lookup indexes. Scientific tables retain
original IDs and attribution; grants retain exact actions, scope and revocation.
Nullable issuer/expiry and explicit independent provenance prepare subsequent policy work.

Schema migration does not silently assign an operator. Stop old servers and workers,
then generate a private preview with `migrate --organization-preview OPERATOR NEW_FILE`.
Review the mapping and pass its printed digest to `--organization-bootstrap OPERATOR DIGEST`.
The inventory digest binds the legacy state. Changed input refuses cutover; the reviewed
mapping, genesis event and initialized flag commit in one transaction. Exact retries
return the stored report. A dedicated migration lab has the nominated operator as admin;
projects group legacy custody/curator pairs. Each dataset is `ExplicitOnly` and gets an
explicit legacy-curator steward. Lab administration grants no dataset read rights.
No identity verification is inferred from these imported principal identifiers.

The server requires completed bootstrap. Uninitialized library mode exists only for
legacy maintenance/fixture staging. Legacy `repository create` is refused after bootstrap;
the trusted `PostgresOrganizationCatalog.createDataset` atomically creates the scientific
record, private placement, explicit stewardship and event/receipt. Public creation and
administration commands remain F02.3. Organization mutations currently require the
operator database connection as well as current application authority. Runtime receives
read/lock privileges for this state, not bootstrap or organization-administration writes.

Organization changes exclusively lock one policy row; scientific authorization, import
lease acquisition and publication share it before taking dataset/credential locks.
Transitions use database time and the reference decision function. Event, record changes,
generations and exact retry receipt commit together. Archival checks actual live import
leases and nonterminal processing runs; archived projects remain readable under current
rights and refuse new writes. Disablement invalidates credentials/import leases in that
same transaction and denies cached principal contexts without changing attribution.

Events reserve installation/epoch/hash-chain and certificate fields, with an explicit
`LocalOnly` durability state. Genesis records imported principals, mappings, grants and
credential lifecycle metadata without bearer secrets. This is **not** an independently
durable policy journal: F03 must include every grant/credential/lifecycle transition and
O03.2 must implement [ADR004](decisions/004-policy-durability.md)'s witness protocol.
Legacy snapshot capture/reconcile refuses organization-enabled catalogs; it cannot reopen
a restore while omitting the new authority records. Source-independent recovery remains open.

This first adapter loads complete organization state and retry history for decisions and
hashes the full legacy inventory for preview. Query indexes do not establish bounded
institutional work; H04 remains open. `ProjectMembers` can be recorded by the trusted
model, but role-derived dataset access is not enabled until F03. Unsupported inherited
rights remain denied; explicit grants continue to work. Navigation links convey no rights.

Remaining integration has explicit owners:
- **F02.3:** governed application/API commands, complete placement/move approvals,
  atomic stewardship-transfer commands, bootstrap/recovery and public error mapping.
- **F03:** full action/grant/provenance policy, data-read enforcement, current credentials,
  restricted evidence and policy-journal ordering. The governed runtime already removes
  the curator shortcut; full role/action/provenance coverage remains open.
- **F04:** verified login identities and guest sponsorship/expiry; a reference fixture's
  local principal is not evidence of a verified institutional person.
- **F05/W02:** filtered navigation links and release-bound work/notes; links confer no rights.

The [F02.1 receipt](evidence/institutional-pilot/F02.1/receipt.json) retains the tested
state, concurrency, expiry, denial and historical-identity invariants.

The [F02.2 receipt](evidence/institutional-pilot/F02.2/receipt.json) records the database,
package and retained historical-corpus qualification for this migration.
