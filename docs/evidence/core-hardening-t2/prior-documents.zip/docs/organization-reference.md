# Organization reference model

F02.1 implements ADR 001–003's basic organization records and atomic reference
transitions. It is an in-memory contract for subsequent persistence and API work.
It does not change the running service's dataset authorization rules.

`Organization.scala` defines typed IDs; checked Unicode display text and generations;
principals, labs, projects, memberships, participations, placement, explicit stewardship
and navigation-link records. Display names are not identifiers. Membership-derived
participations name the exact membership ID; ended IDs are never reused.

`ReferenceOrganizationCatalog` accepts an explicit trusted principal/dataset inventory
and installation-operator set. It supports lab/project creation and naming, membership
and participation appointment/ending, initial placement of a registered empty dataset,
explicit stewardship appointment/ending, confirmed role inheritance, archival/unarchive
and emergency principal disablement. Initial placement creates explicit creator
stewardship and defaults to `ExplicitOnly`.

Each mutation checks the current actor and all required record generations in one
`Ref.modify`, commits its audit and idempotency result atomically, and leaves state
unchanged on failure. A retry reauthorizes the actor before returning its original
receipt; a reused key with different intent conflicts. Project generations also track
participation and membership-derived authority changes. Role-inheritance confirmation
compares both generation and current eligible recipients/roles, including expiry.

Ordinary transitions cannot remove the last eligible lab admin, project steward or
explicit dataset steward. Emergency disablement overrides those appointments while
retaining attribution; `recoveryNeeds(now)` identifies affected resources, including
natural expiry. No expiry is extended to avoid a recovery need. Lab administration
never implies project stewardship, and project stewardship never implies explicit
dataset stewardship. No principal, lab, project, placement or appointment is deleted.

Archival refuses active work. The reference adapter records distinct lease tokens,
so an old worker's release cannot clear another worker's fence. New work cannot be
registered on an archived project. Archive preserves appointments and separately
checked reads; new participation, placement and inheritance changes are refused.
A lab can archive only after its projects, and an archived parent must reopen first.

The snapshot/lease adapter methods are trusted in-process support, not public endpoints.
They deliberately expose complete state to contract tests and future storage adapters;
F03/F05 must filter every public read. The reference implementation scans maps and is
not evidence of bounded institutional-scale database work.

Remaining integration has explicit owners:

- **F02.2:** extend the existing PostgreSQL principal registry, persist these records,
  join placement/scientific creation and lease checks in the same transaction, and
  migrate accepted legacy datasets without changing historical identity or access.
- **F02.3:** governed application/API commands, complete placement/move approvals,
  atomic stewardship-transfer commands, bootstrap/recovery and public error mapping.
- **F03:** full action/grant/provenance policy, data-read enforcement, current credentials,
  restricted evidence and policy-journal ordering. The existing runtime curator shortcut
  has not been removed by this reference-only change.
- **F04:** verified login identities and guest sponsorship/expiry; a reference fixture's
  local principal is not evidence of a verified institutional person.
- **F05/W02:** filtered navigation links and release-bound work/notes; links confer no rights.

The [F02.1 receipt](evidence/institutional-pilot/F02.1/receipt.json) retains the tested
state, concurrency, expiry, denial and historical-identity invariants.
